/* ShopSage MV3 service worker：
 * 关键修复：采购/店铺类后端调用直接在 service worker 里用存储的 Bearer fetch，不再开 purchase.html 控制页标签；
 * automation.html 只保留给「开始持续跑」的循环（用户主动点才开）。这样刷新 1688/拼多多 页不会再自动冒出一堆标签。 */

function base() { return "https://www.shopsage.cc"; }
async function getToken() {
  const s = await chrome.storage.local.get(["backendUrl", "accessToken", "tokenAt", "refreshToken"]);
  const b = (s.backendUrl || base()).replace(/\/+$/, "") || base();
  let token = s.accessToken || "";
  const stale = !token || (Date.now() - Number(s.tokenAt || 0) > 12 * 60 * 1000);
  if (stale && s.refreshToken) {
    try {
      const rr = await fetch(b + "/api/auth/refresh", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken: s.refreshToken }) });
      const rj = await rr.json().catch(() => ({}));
      const d = (rj && rj.data) ? rj.data : rj;
      if (d && d.accessToken) { token = d.accessToken; await chrome.storage.local.set({ accessToken: token, refreshToken: d.refreshToken || s.refreshToken, tokenAt: Date.now() }); }
    } catch (e) {}
  }
  return { b, token };
}
async function swFetch(path, init) {
  const { b, token } = await getToken();
  if (!token) throw new Error("未登录 ShopSage 账号");
  let r = await fetch(b + path, { method: (init && init.method) || "GET", credentials: "include", headers: Object.assign({ "Content-Type": "application/json", "x-app-locale": "zh", Authorization: "Bearer " + token }, (init && init.headers) || {}), body: init && init.body });
  if (r.status === 401) { // 再刷一次
    const s = await chrome.storage.local.get(["refreshToken"]);
    try {
      const rr = await fetch(b + "/api/auth/refresh", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken: (s && s.refreshToken) || "" }) });
      const rj = await rr.json().catch(() => ({})); const d = (rj && rj.data) ? rj.data : rj;
      if (d && d.accessToken) { await chrome.storage.local.set({ accessToken: d.accessToken, refreshToken: d.refreshToken || s.refreshToken, tokenAt: Date.now() });
        r = await fetch(b + path, { method: (init && init.method) || "GET", credentials: "include", headers: { "Content-Type": "application/json", "x-app-locale": "zh", Authorization: "Bearer " + d.accessToken }, body: init && init.body }); }
    } catch (e) {}
  }
  const data = await r.json().catch(() => ({}));
  if (r.status >= 400) throw new Error((data && (data.message || (data.data && data.data.message))) || ("后台返回 " + r.status));
  return (data && typeof data === "object" && "success" in data && "data" in data) ? data.data : data;
}

// ── 一键登录（票据换 token）放进 SW：常驻可收，不再依赖插件页面是否开着 ──
async function swHandoff(ticket) {
  const b = base();
  if (!ticket) throw new Error("缺少登录票据");
  const r = await fetch(b + "/api/v1/extension/handoff", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "x-app-locale": "zh" }, body: JSON.stringify({ ticket: String(ticket) }) });
  const j = await r.json().catch(() => ({}));
  const d = (j && j.data) ? j.data : j;
  if (r.status !== 200 || !d || !d.accessToken) throw new Error((d && (d.message || d.error)) || ("一键登录失败 " + r.status));
  await chrome.storage.local.set({ backendUrl: b, accessToken: d.accessToken, refreshToken: d.refreshToken || "", tokenAt: Date.now(), email: d.email || "", userName: d.userName || d.name || "" });
  try { const me = await fetch(b + "/api/auth/me", { headers: { Authorization: "Bearer " + d.accessToken }, credentials: "include" }); if (me.status === 401) throw new Error("换到的令牌无效"); } catch (e) {}
  return { email: d.email || "" };
}

async function handlePurchase(op, p) {
  if (op === "ping") return { ok: true, ready: true };
  if (op === "bind") return { ok: true, data: await swFetch("/api/purchase/bind?poId=" + encodeURIComponent(String(p.poId || "")), { method: "GET" }) };
  if (op === "report") {
    const body = { externalOrderNo: (p.externalOrderNo || "") || undefined, domesticTrackingNo: (p.domesticTrackingNo || p.trackingNo || "") || undefined, domesticCarrier: (p.domesticCarrier || p.carrier || "") || undefined, trackingNo: (p.trackingNo || "") || undefined, carrier: (p.carrier || "") || undefined, paidCostCny: (p.paidCostCny == null || p.paidCostCny === "" || isNaN(Number(p.paidCostCny))) ? undefined : Number(p.paidCostCny), unitCostCny: (p.unitCostCny == null || p.unitCostCny === "" || isNaN(Number(p.unitCostCny))) ? undefined : Number(p.unitCostCny), cnTitle: (p.cnTitle || "") || undefined, quantity: (p.quantity == null || p.quantity === "" || isNaN(Number(p.quantity))) ? undefined : Number(p.quantity) };
    return { ok: true, data: await swFetch("/api/purchase/" + encodeURIComponent(String(p.poId || "")) + "/report", { method: "POST", body: JSON.stringify(body) }) };
  }
  if (op === "pending") return { ok: true, data: await swFetch("/api/purchase/pending?hours=" + encodeURIComponent(Number(p.hours) || 24), { method: "GET" }) };
  if (op === "forwarders") return { ok: true, data: await swFetch("/api/purchase/forwarders", { method: "GET" }) };
  if (op === "skuLink") return { ok: true, data: await swFetch("/api/purchase/sku-link", { method: "POST", body: JSON.stringify(p) }) };
  if (op === "shops") return { ok: true, data: await swFetch("/api/shops", { method: "GET" }) };
  throw new Error("未知 op " + op);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;

  // 采购/店铺接口：SW 直接 fetch，不开任何控制页标签
  if (message.type === "SS_PURCHASE_API") {
    handlePurchase(message.op, message.payload || {}).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  // 内容脚本中继的一键登录票据（绕开 externally_connectable，双通道之一）
  if (message.type === "SS_HANDOFF") {
    swHandoff(message.ticket).then((r) => sendResponse({ ok: true, email: r.email })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  if (message.type === "OPEN_LIBRARY") {
    chrome.tabs.create({ url: chrome.runtime.getURL("library.html") });
    return;
  }

  // 自动化控制页：只在用户点「开始持续跑」等主动操作时才拉起（按 URL 复用，绝不重复开）
  if (message.type === "SS_AUTO_OPEN_CTRL") {
    (async () => {
      const url = chrome.runtime.getURL("automation/automation.html");
      try { const f = await chrome.tabs.query({ url }); if (f && f.length) return sendResponse({ ok: true, reused: true }); } catch (e) {}
      try { await chrome.tabs.create({ url, active: false }); sendResponse({ ok: true, opened: true }); } catch (e) { sendResponse({ ok: false }); }
    })();
    return true;
  }

  if (message.type === "injectFile") {
    chrome.scripting.executeScript({ target: { tabId: message.tabId }, files: [message.file] })
      .then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
});

// 官网中转页经 externally_connectable 直投票据：SW 常驻接收，插件页面没开也能一键登录
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  const okSender = sender && sender.url && /^https:\/\/([a-z0-9-]+\.)?shopsage\.cc\//.test(sender.url);
  if (!okSender || !message || message.type !== "shopsage-handoff" || !message.ticket) {
    sendResponse({ ok: false, error: "来源或消息不符合" });
    return true;
  }
  swHandoff(message.ticket).then((r) => sendResponse({ ok: true, email: r.email })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
  return true;
});
