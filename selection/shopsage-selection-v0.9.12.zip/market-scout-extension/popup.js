/* ShopSage 选品助手 · 弹窗
 * 2026-11-08：取数改走 capture.js（与页面注入层同一份逻辑，不再在这里各写一套选择器）；
 * 市场/成本/利润交给 market-ui.js + rules.js。 */
const $ = id => document.getElementById(id);
let currentProduct = null, tabUrl = '';

function setStatus(m, t = '') { const e = $('status'); e.textContent = m; e.className = `status ${t}`; }

function showResult(d) {
  const text = typeof d === 'string' ? d : (d.result || d.analysis || d.output || JSON.stringify(d, null, 2));
  $('resultBody').textContent = text;
  const m = text.match(/(值得测试|谨慎测试|暂不建议|建议测试)/);
  $('verdict').textContent = m ? m[0] : '分析完成';
  $('result').classList.remove('hidden');
}

async function getSettings() {
  return chrome.storage.local.get({ backendUrl: "", accessToken: "", email: "", estimatedCredits: 10 });
}

/** 弹窗里正在采集的这一件：整页内容（SKU 表/图组/属性/物流）随商品一起进 payload。 */
function productPayload() {
  const d = currentProduct || {};
  return { ...d, currency: d.currency || 'CNY', content: d.content || null };
}

/** 统一的后台请求：带官网签发的 Bearer（实现在 auth.js，popup/选品库/设置页共用一份）。 */
async function backendFetch(path, init) {
  return window.SSAuth.backendFetch(path, init);
}

/** 对客只说人话：内部状态码（NEED_LOGIN 这类）一律翻译成可操作的中文。 */
function failText(prefix, e) {
  return prefix + window.SSAuth.friendlyError(e && e.message ? e.message : String(e));
}

function renderPriceNote(p) {
  const el = $('priceNote');
  if (!el) return;
  if (!p) { el.textContent = ''; return; }
  el.textContent = (p.priceSource || '') + (p.priceNeedsReview ? ' · 请核对采购价' : '');
  el.className = 'price-note' + (p.priceNeedsReview ? ' warn' : '');
}

/** 在当前标签页里跑 capture.js 并取回商品列表。 */
async function captureFromTab(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['capture.js'] });
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => (window.MS_CAPTURE ? window.MS_CAPTURE() : [])
  });
  return Array.isArray(result) ? result : [];
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) throw Error('没有可读取的当前标签页。');
  const host = new URL(tab.url).hostname;
  if (!/(^|\.)(1688\.com|pinduoduo\.com|yangkeduo\.com)$/.test(host)) throw Error('当前页面不是 1688 或拼多多。');
  return tab;
}

async function collectCurrentPage() {
  const button = $('scrapePage');
  button.disabled = true;
  setStatus('正在读取当前列表页商品…');
  try {
    const tab = await activeTab();
    const products = await captureFromTab(tab.id);
    if (!products?.length) throw Error('这页没识别到商品卡片。可能是列表还没加载完，或页面结构已变——请把网址反馈给 ShopSage。');
    const state = await chrome.storage.local.get({ products: [] });
    const items = Array.isArray(state.products) ? state.products : [];
    const known = new Set(items.map(x => x.url));
    let added = 0;
    for (const p of products) if (!known.has(p.url)) { items.unshift(p); known.add(p.url); added++; }
    await chrome.storage.local.set({ products: items.slice(0, 500) });
    setStatus(`本页识别 ${products.length} 件，新增 ${added} 件。采购价以页面可见价为准，请核对。`, 'success');
  } catch (e) { setStatus(e.message || '采集失败。', 'error'); }
  finally { button.disabled = false; }
}

async function scrape() {
  setStatus('正在读取当前商品页面…');
  try {
    const tab = await activeTab();
    tabUrl = tab.url;
    const isDetail = /\/offer\/\d+/.test(new URL(tab.url).pathname)
      || (/goods\.html|\/goods\/|detail/i.test(new URL(tab.url).pathname) && new URL(tab.url).searchParams.get('goods_id'));
    if (!isDetail) throw Error('这是商品列表页。请用商品卡片上的「采集商品」，或点「采集当前列表页商品」批量采集。');

    const list = await captureFromTab(tab.id);
    const d = list[0];
    if (!d) throw Error('详情页没能解析出商品，请刷新后再试。');
    currentProduct = { ...d, currency: 'CNY', source: d.platform, capturedAt: new Date().toISOString() };
    $('title').value = d.title;
    $('purchasePrice').value = d.price ?? '';
    if (d.image) { $('image').src = d.image; $('image').alt = d.title; }
    $('platform').textContent = d.platform;
    $('source').innerHTML = '<span class="dot active"></span>已连接商品页面 · ' + d.platform;
    renderPriceNote(d);
    window.MSMarket.refresh(true);
    setStatus(d.title ? `已按「${d.capturePath || '详情页'}」采集，请核对采购价与标题。` : '页面已读取，但未识别出商品标题，请手动填写。', 'success');
  } catch (e) { setStatus(e.message || '采集失败，请刷新商品页后重试。', 'error'); }
}

async function syncProduct() {
  const s = await getSettings();
  if (!s.accessToken) return setStatus("请先用 ShopSage 账号登录（与官网同一个账号）。", "error");
  const b = $('sync'); b.disabled = true;
  setStatus('正在同步商品到采集箱…');
  try {
    const p = productPayload();
    /* 与选品库同一道闸门：条目归属与当前登录账号不一致就不上传（2026-11-12 生产实证补的洞） */
    const nowEmail = window.SSAuth && window.SSAuth.currentEmail ? await window.SSAuth.currentEmail() : '';
    const own = window.SSAuth.ownerGuard(p && p.ownerEmail, nowEmail);
    if (!own.ok) {
      setStatus(own.reason === 'not_logged_in' ? '还没登录 ShopSage：请先用官网账号登录。'
        : '这条商品是在另一个账号（' + own.owner + '）下采集的，不会传进当前账号的采集箱。', 'error');
      b.disabled = false;
      return;
    }
    const sourceContent = p.content && !p.content.__msDiag ? p.content : null;
    /* 诊断包不进底稿，但要单独回报（contentDiag）——后端只写日志不落库，
       这样线上还能读到「页面到底给了什么结构」，不至于又变成瞎猜（2026-11-09 教训）。 */
    const contentDiag = p.content && p.content.__msDiag ? { goodsId: p.content.diag && p.content.diag.goodsId, reason: (p.content.diag && (p.content.diag.error || p.content.diag.note)) || 'no_data_packet', stage: (p.content.diag && p.content.diag.stage) || 'hook', url: (p.content.diag && p.content.diag.url) || '', sniff: (p.content.diag && p.content.diag.sniff) || null, hasContext: !!(p.content.diag && p.content.diag.hasContext), contextKeys: (p.content.diag && p.content.diag.contextKeys) || null, ts: (p.content.diag && p.content.diag.ts) || null } : null;
    const list = (v, n) => Array.isArray(v) ? v.slice(0, n) : [];
    const rows = (v, n, sku) => list(v, n).map(x => {
      if (!x || typeof x !== 'object') return { value: String(x || '').slice(0, 300) };
      return sku
        ? { skuId: String(x.skuId || '').slice(0, 80), spec: String(x.spec || x.specsText || '').slice(0, 300), price: x.price ?? null, stock: x.stock ?? x.quantity ?? null }
        : { pid: String(x.pid || '').slice(0, 80), name: String(x.name || x.prop || x.label || x.key || '').slice(0, 160), value: String(x.value || x.text || '').slice(0, 500), values: list(x.values, 20).map(y => typeof y === 'object' ? { vid: y.vid, name: String(y.name || y.value || '').slice(0, 120) } : String(y).slice(0, 120)) };
    });
    /* 与 library.js 同一份口径：阶梯档位 + 探针必须随整页内容一起上传，
       之前 popup 这条路径的白名单同样漏了 priceRange（2026-11-11 生产实测）。 */
    const ladder = list((sourceContent && sourceContent.priceRange) || [], 12).map(x => (x && typeof x === 'object' && Number(x.price) > 0)
      ? { price: Number(x.price), beginAmount: x.beginAmount ?? null, endAmount: x.endAmount ?? null, from: String(x.from || '').slice(0, 60) } : null).filter(Boolean);
    const content = sourceContent ? {
      priceRange: ladder.length ? ladder : null,
      priceRangeProbe: sourceContent.priceRangeProbe && typeof sourceContent.priceRangeProbe === 'object' ? sourceContent.priceRangeProbe : null,
      priceNote: String(sourceContent.priceNote || '').slice(0, 200) || null,
      host: String(sourceContent.host || '').slice(0, 20) || null,
      source: String(sourceContent.source || '').slice(0, 200) || null,
      saleNum: typeof sourceContent.saleNum === 'number' ? sourceContent.saleNum : null,
      topCategoryId: sourceContent.topCategoryId ? String(sourceContent.topCategoryId).slice(0, 40) : null,
      categorySource: String(sourceContent.categorySource || '').slice(0, 300) || null,
      detailImages: list(sourceContent.detailImages, 30).map(x => String(x || '').slice(0, 700)).filter(Boolean),
      cautionText: String(sourceContent.cautionText || '').slice(0, 300) || null,
      title: String(sourceContent.title || '').slice(0, 500), seller: String(sourceContent.seller || '').slice(0, 300),
      category: String(sourceContent.category || '').slice(0, 300),
      categoryId: sourceContent.categoryId ? String(sourceContent.categoryId).slice(0, 40) : null,
      offerId: sourceContent.offerId ? String(sourceContent.offerId).slice(0, 40) : null,
      images: (Array.isArray(sourceContent.images) ? sourceContent.images.slice(0, 30) : []).map(x => String(x || '').slice(0, 700)).filter(Boolean),
      video: sourceContent.video && (sourceContent.video.url || sourceContent.video.videoId) ? { url: String(sourceContent.video.url || '').slice(0, 700) || null, cover: String(sourceContent.video.cover || '').slice(0, 700) || null, title: String(sourceContent.video.title || '').slice(0, 200) || null, videoId: String(sourceContent.video.videoId || '').slice(0, 40) } : null,
      weight: sourceContent.weight && (sourceContent.weight.kg != null || sourceContent.weight.gram != null) ? { kg: sourceContent.weight.kg ?? null, gram: sourceContent.weight.gram ?? null, lengthCm: sourceContent.weight.lengthCm ?? null, widthCm: sourceContent.weight.widthCm ?? null, heightCm: sourceContent.weight.heightCm ?? null, source: String(sourceContent.weight.source || '').slice(0, 120) } : null,
      logistics: sourceContent.logistics ? { postFee: sourceContent.logistics.postFee ?? null, minWeight: sourceContent.logistics.minWeight ?? null, official: sourceContent.logistics.official ?? null, note: String(sourceContent.logistics.note || '').slice(0, 200) || null, source: String(sourceContent.logistics.source || '').slice(0, 120) } : null,
      certifications: list(sourceContent.certifications, 20).map(x => ({ name: String((x && x.name) || '').slice(0, 200), url: String((x && x.url) || '').slice(0, 700) })),
      props: rows(sourceContent.props, 80, false), skuProps: rows(sourceContent.skuProps, 40, false), skus: rows(sourceContent.skus, 70, true),
      descriptionHtml: String(sourceContent.descriptionHtml || '').slice(0, 16000),
      description: String(sourceContent.description || sourceContent.visibleText || '').slice(0, 8000),
      detailUrl: sourceContent.detailUrl ? String(sourceContent.detailUrl).slice(0, 700) : null,
      layout: sourceContent.layout ? String(sourceContent.layout).slice(0, 60) : null,
      capturedAt: String(sourceContent.capturedAt || '').slice(0, 80)
    } : null;
    /* 空壳绝不当 DOC：标题都没有、图片/SKU/属性/描述全空的包，宁可不写底稿 */
    const docIsReal = !!content && !!content.title && (content.images.length || content.skus.length || content.props.length || content.descriptionHtml.length > 40);
    delete p.content;
    delete p.contentStatus;
    const d = await backendFetch('/api/extension/products', {
      method: 'POST',
      // content 必须放 body 顶层——后端 ExtensionProductPayload.content 读顶层，挂在 product 里后端永远读到 undefined（2026-11-09 生产钉死）
      body: JSON.stringify({ product: p, source: p.platform, market: window.MSMarket.requestMarket(), costs: window.MSMarket.requestCosts(), content: docIsReal ? content : null, contentDiag })
    });
    const counts = docIsReal ? `图${content.images.length}·规格${content.skus.length}·属性${content.props.length}${content.video ? '·有视频' : ''}${content.categoryId ? '·类目ID' : ''}` : '';
    setStatus(`已进采集箱${d.id ? ` · 编号 ${d.id}` : ''}，去后台「AI商品选品 → 采集箱」看。${docIsReal ? ` 整页内容：DOC·${JSON.stringify(content).length}B（${counts}）` : ' 这次只进了商品基本信息，整页内容没抓到——再点一次「采集到选品库」后同步，或把这条反馈给 ShopSage。'}`, 'success');
  } catch (e) { setStatus(failText('同步失败：', e), 'error'); }
  finally { b.disabled = false; }
}

async function analyze() {
  const p = requestPayload();
  if (!p.product.title) return setStatus('先采集商品，或手动填写商品标题。', 'error');
  if (!p.product.price) return setStatus('请填写商品采购价，才能测算利润。', 'error');
  const s = await getSettings();
  if (!s.accessToken) return setStatus('AI 分析走 ShopSage 服务端：请先用 ShopSage 账号登录。', 'error');
  const b = $('analyze'); b.disabled = true;
  setStatus('服务端正在分析（分析由 ShopSage 代跑，按点数结算）…');
  try {
    // 先同步拿 id，再让服务端分析，报告能在后台采集箱里留档
    const synced = await backendFetch('/api/extension/products', {
      method: 'POST',
      body: JSON.stringify({ product: p.product, source: p.product.platform, market: p.market, costs: p.costs })
    });
    const done = await backendFetch('/api/extension/analyze', {
      method: 'POST',
      body: JSON.stringify({ id: synced.id })
    });
    const report = done?.analysisResult?.report || '';
    showResult({ result: report || '分析完成，但服务端没有返回报告内容。' });
    setStatus('分析完成 · 报告已存到后台采集箱。', 'success');
  } catch (e) { setStatus(failText('分析失败：', e), 'error'); }
  finally { b.disabled = false; }
}

document.addEventListener('DOMContentLoaded', async () => {
  window.MSMarket.init({});
  $('scrape').onclick = scrape;
  $('scrapePage').onclick = collectCurrentPage;
  $('library').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('library.html') });
  $('sync').onclick = syncProduct;
  $('analyze').onclick = analyze;
  $('copyUrl').onclick = async () => {
    if (!tabUrl) { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabUrl = t?.url || ''; }
    await navigator.clipboard.writeText(tabUrl);
    setStatus('已复制当前页面链接。', 'success');
  };
  $('purchasePrice').addEventListener('input', () => renderPriceNote(currentProduct));
  /* 登录做到最前端：没登录只见登录框，登录成功才出正文并自动采集 */
  const connected = await window.SSAuth.mountGate({ onConnected: () => { void scrape(); } });
  if (connected) await scrape();
});
