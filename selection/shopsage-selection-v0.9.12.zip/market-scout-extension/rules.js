/**
 * ShopSage 选品规则库（浏览器插件侧只读副本）
 *
 * 来源（单一事实源仍是 ShopSage 后端，本文件是它的导出快照，改后端要同步这里）：
 *   services/api/src/cost/platform-markets.ts            PLATFORM_MARKETS      lastVerifiedAt 2026-10-18
 *   services/api/src/business-context/marketplace-country-fees.registry.ts
 *                                                         MARKETPLACE_FEES      lastVerified 2026-10-19 / 10-20 / 10-22
 *                                                         CNY_FX_REFERENCE      2026-10-19
 *   services/api/src/market-research/currency-reference.ts
 *                                                         REFERENCE_FX_PER_CNY  asOf 2026-10-12 (open.er-api.com)
 *   services/api/src/cost/shipping-rules.ts               CB_FIRST_WEIGHT       2026-10-19
 *   services/api/src/products/market-first-selection.service.ts
 *                                                         computeProfitEstimate 判定阈值 30% / 15%
 *
 * 红线（照抄后端口径，不许违反）：
 *   缺就说缺，绝不冒充。算不出来的字段一律返回 null + reason，绝不回落成 0 或拍脑袋默认值。
 */
(function (root) {
  'use strict';

  var SNAPSHOT_DATE = '2026-11-08';

  /* ── 1. 平台 → 已开通市场（PLATFORM_MARKETS）────────────────────────────
     access: cross_border 可跨境直发 / local_only 仅本土店 / invite_only 邀请制 */
  var PLATFORMS = [
    { key: 'SHOPEE', name: 'Shopee', supported: true },
    { key: 'TIKTOK_SHOP', name: 'TikTok Shop', supported: true },
    { key: 'LAZADA', name: 'Lazada', supported: true },
    { key: 'OZON', name: 'Ozon', supported: true },
    { key: 'OTHER', name: '其他平台（规则库未收录）', supported: false }
  ];

  var MARKETS = {
    SHOPEE: [
      { code: 'TW', name: '中国台湾', currency: 'TWD', access: 'cross_border', band: '约 14%' },
      { code: 'MY', name: '马来西亚', currency: 'MYR', access: 'cross_border', band: '约 18%' },
      { code: 'SG', name: '新加坡', currency: 'SGD', access: 'cross_border', band: '约 16%' },
      { code: 'TH', name: '泰国', currency: 'THB', access: 'cross_border', band: '约 18–20%' },
      { code: 'VN', name: '越南', currency: 'VND', access: 'cross_border', band: '约 15%' },
      { code: 'PH', name: '菲律宾', currency: 'PHP', access: 'cross_border', band: '约 12%' },
      { code: 'BR', name: '巴西', currency: 'BRL', access: 'cross_border', band: '约 16%' },
      { code: 'MX', name: '墨西哥', currency: 'MXN', access: 'cross_border', band: '约 16%' },
      { code: 'ID', name: '印度尼西亚', currency: 'IDR', access: 'local_only', band: '以本土店后台为准' },
      { code: 'BN', name: '文莱', currency: 'BND', access: 'invite_only', band: '定向' },
      { code: 'AR', name: '阿根廷', currency: 'ARS', access: 'invite_only', band: '定向' }
    ],
    TIKTOK_SHOP: [
      { code: 'TH', name: '泰国', currency: 'THB', access: 'cross_border', band: '按类目' },
      { code: 'MY', name: '马来西亚', currency: 'MYR', access: 'cross_border', band: '按类目' },
      { code: 'VN', name: '越南', currency: 'VND', access: 'cross_border', band: '按类目' },
      { code: 'PH', name: '菲律宾', currency: 'PHP', access: 'cross_border', band: '按类目' },
      { code: 'SG', name: '新加坡', currency: 'SGD', access: 'cross_border', band: '按类目' },
      { code: 'ID', name: '印度尼西亚', currency: 'IDR', access: 'cross_border', band: '按类目' },
      { code: 'US', name: '美国', currency: 'USD', access: 'cross_border', band: '最高约 8%（POP 约 6%）' },
      { code: 'GB', name: '英国', currency: 'GBP', access: 'cross_border', band: '约 9%' },
      { code: 'ES', name: '西班牙', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'IE', name: '爱尔兰', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'DE', name: '德国', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'FR', name: '法国', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'IT', name: '意大利', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'PL', name: '波兰', currency: 'PLN', access: 'cross_border', band: '约 9%' },
      { code: 'NL', name: '荷兰', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'BE', name: '比利时', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'AT', name: '奥地利', currency: 'EUR', access: 'cross_border', band: '约 9%' },
      { code: 'MX', name: '墨西哥', currency: 'MXN', access: 'cross_border', band: '按类目' },
      { code: 'BR', name: '巴西', currency: 'BRL', access: 'cross_border', band: '按类目' },
      { code: 'SA', name: '沙特阿拉伯', currency: 'SAR', access: 'local_only', band: '按类目' },
      { code: 'JP', name: '日本', currency: 'JPY', access: 'local_only', band: '按类目（2026-03 起仅本土公司）' }
    ],
    LAZADA: [
      { code: 'TH', name: '泰国', currency: 'THB', access: 'cross_border', band: '按类目' },
      { code: 'MY', name: '马来西亚', currency: 'MYR', access: 'cross_border', band: '按类目' },
      { code: 'ID', name: '印度尼西亚', currency: 'IDR', access: 'cross_border', band: '按类目' },
      { code: 'PH', name: '菲律宾', currency: 'PHP', access: 'cross_border', band: '按类目' },
      { code: 'VN', name: '越南', currency: 'VND', access: 'cross_border', band: '按类目' },
      { code: 'SG', name: '新加坡', currency: 'SGD', access: 'cross_border', band: '按类目' }
    ],
    OZON: [
      { code: 'RU', name: '俄罗斯', currency: 'RUB', access: 'cross_border', band: '按类目' }
    ],
    OTHER: []
  };

  /* 费率表用 UK，市场表用 GB —— 对齐后端同一实体 */
  var COUNTRY_ALIAS = { UK: 'GB', GB: 'UK' };

  /* ── 2. 平台 × 国家 综合费率（MARKETPLACE_FEES.typicalTotalPct）────────
     L = 本土/通配行，X = 跨境店行；null = 表里没有，绝不编。
     quality: CONFIRMED 已核实 / ESTIMATED 估算 / MISSING 缺 */
  var FEES = {
    'SHOPEE/TW': { L: 0.15, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'SHOPEE/MY': { L: 0.12, X: 0.24, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-22' },
    'SHOPEE/SG': { L: 0.21, X: 0.225, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-22' },
    'SHOPEE/TH': { L: 0.20, X: 0.225, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-22' },
    'SHOPEE/VN': { L: 0.12, X: 0.20, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-20' },
    'SHOPEE/PH': { L: 0.09, X: 0.145, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'SHOPEE/BR': { L: 0.20, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'SHOPEE/ID': { L: 0.13, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-22' },
    'SHOPEE/MX': { L: null, X: null, quality: 'MISSING', conf: 'LOW', v: '2026-10-19', note: '官方未公开可核实费率' },

    'TIKTOK_SHOP/TH': { L: 0.092, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/VN': { L: 0.21, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/ID': { L: 0.10, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/MY': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/PH': { L: 0.07, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/SG': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/US': { L: 0.089, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/UK': { L: 0.09, X: null, quality: 'CONFIRMED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/DE': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/FR': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/IT': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/ES': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/IE': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'HIGH', v: '2026-10-19' },
    'TIKTOK_SHOP/AT': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/BE': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/NL': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/PL': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'TIKTOK_SHOP/MX': { L: 0.14, X: null, quality: 'ESTIMATED', conf: 'LOW', v: '2026-10-19', note: '单一来源，店内 rate card 核实前保守看待' },
    'TIKTOK_SHOP/BR': { L: 0.12, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },

    'LAZADA/TH': { L: 0.13, X: 0.175, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-20' },
    'LAZADA/MY': { L: 0.115, X: 0.095, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-20' },
    'LAZADA/SG': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'LAZADA/PH': { L: 0.095, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'LAZADA/ID': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },
    'LAZADA/VN': { L: 0.09, X: null, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-19' },

    'OZON/RU': { L: 0.21, X: 0.10, quality: 'ESTIMATED', conf: 'MEDIUM', v: '2026-10-20' }
  };

  /* ── 3. 参考汇率：1 CNY = X 目标币 ─────────────────────────────────────
     A 组 = currency-reference.ts REFERENCE_FX_PER_CNY（er-api，asOf 2026-10-12）
     B 组 = registry CNY_FX_REFERENCE（静态待校准，补 A 组没有的币种）
     表里没有的币种一律 null，不猜。 */
  var FX = {
    USD: { perCny: 0.149125, tier: 'A', asOf: '2026-10-12' },
    THB: { perCny: 5.002878, tier: 'A', asOf: '2026-10-12' },
    MYR: { perCny: 0.607792, tier: 'A', asOf: '2026-10-12' },
    IDR: { perCny: 2673.796791, tier: 'A', asOf: '2026-10-12' },
    PHP: { perCny: 9.363296, tier: 'A', asOf: '2026-10-12' },
    VND: { perCny: 3861.003861, tier: 'A', asOf: '2026-10-12' },
    SGD: { perCny: 0.190909, tier: 'A', asOf: '2026-10-12' },
    RUB: { perCny: 12.690355, tier: 'A', asOf: '2026-10-12' },
    TWD: { perCny: 4.6, tier: 'B', asOf: '2026-10-19' },
    BRL: { perCny: 0.75, tier: 'B', asOf: '2026-10-19' },
    MXN: { perCny: 2.6, tier: 'B', asOf: '2026-10-19' },
    GBP: { perCny: 0.11, tier: 'B', asOf: '2026-10-19' },
    EUR: { perCny: 0.13, tier: 'B', asOf: '2026-10-19' },
    PLN: { perCny: 0.56, tier: 'B', asOf: '2026-10-19' }
  };

  /* ── 4. 跨境首重参考运费（shipping-rules.ts CB_FIRST_WEIGHT，CN→目标国 0-1kg）
     单位 = 目的地币种；全部 MARKET_REFERENCE / LOW 置信，仅供粗估。
     分档系数 ×1.0 / ×1.55 / ×2.6 来自后端 cbBands()。 */
  var SHIP_FIRST = {
    TH: { cost: 40, currency: 'THB' },
    MY: { cost: 12, currency: 'MYR' },
    ID: { cost: 30000, currency: 'IDR' },
    PH: { cost: 150, currency: 'PHP' },
    VN: { cost: 60000, currency: 'VND' },
    SG: { cost: 4, currency: 'SGD' },
    RU: { cost: 250, currency: 'RUB' },
    /* 2026-11-09 补齐（去收集的，来源与冲突都写明，置信低，商家可自行覆盖）：
       TW = Shopee 台湾 SLS：首重 0.5kg 卖家出 15 TWD + 续重每 0.5kg 30 TWD（全卖家出）
            → 0-1kg 卖家成本 = 45 TWD ≈ ¥9.8。来源：Shopee 卖家藏价实操（知乎 2025）。
       US = TikTok 美区官方价卡：起重 4.13 USD + 续重 0.14 USD/10g
            → 0-1kg ≈ 4.13 + 99×0.14 = 17.99 USD ≈ ¥128（按 1 USD=7.1 CNY）。
            ⚠ 与大数跨境「2kg 内 ¥45-60」冲突 2-3 倍，取官方价卡口径（偏保守报高）。 */
    TW: { cost: 45, currency: 'TWD' },
    US: { cost: 17.99, currency: 'USD' }
  };
  /* ── 海运 / 铁路 / 联运 全量预估表（2026-11-09 联网补齐，老板口径：我们只预估，商家可覆盖）─
     统一口径：中国 → 目的国「双清到门」散货单价，人民币 / 立方米；
     不含平台扣点，不含进口关税与增值税（那两块走扣点与其他成本，不重复计）。
     体积换重仍用 1 CBM ≈ 167kg（与后端 shipping-cost.engine 同一口径，对泡货偏保守）。
     每个数都能在 FREIGHT_SRC 里查到来源站点与报价日期；标 low 的格子界面会提示「建议询价」。 */
  var SEA_PER_CBM = {
    TH: 800, MY: 710, SG: 600, VN: 550, PH: 950, ID: 1950,      // 东南亚（ID 由 950 修正为 1950：原值约为行情一半）
    TW: 1000, JP: 1100,                                          // 近洋（TW 600→1000、JP 750→1100，按到门口径）
    US: 3000, GB: 3000, DE: 3100, FR: 3100, IT: 3100, ES: 3100,
    IE: 3100, AT: 3100, BE: 3100, NL: 3100, PL: 3100,            // 欧美基港中值
    SA: 1600, MX: 4800, BR: 2300,                                // SA 3400→1600、BR 4800→2300（原值约为行情两倍）
    BN: 1200, AR: 1000, RU: 1000                                 // 本次补齐的三国
  };
  /* 纯铁路：只收真实存在铁路通道的市场。中老泰、凭祥—同登两条是 2026 年常态化开行的班列。 */
  var RAIL_PER_CBM = {
    DE: 6800, FR: 6800, IT: 6800, ES: 6800, IE: 6800, AT: 6800,
    BE: 6800, NL: 6800, PL: 6800, GB: 6800,                      // 中欧班列（门到门双清口径；站到站拼箱公开价仅 1300–1700）
    RU: 5800,                                                     // 俄线以铁路为主
    TH: 1450, VN: 450                                             // 中老泰全铁班列 / 中越铁路（凭祥—同登—河内）
  };
  /* 联运：第一程海运 + 目的国境内铁路。不是纯铁路，界面必须写清，否则商家会误读。 */
  var RAILSEA_PER_CBM = {
    US: 1300,   // 海运到洛杉矶/长滩 → IPI 内陆铁路；美西 950–1200、美东 1300–1600，取中高
    SA: 1600,   // 海运到吉达/达曼 → 沙特铁路陆桥进利雅得
    MX: 870     // 海运到曼萨尼约 → Ferromex 铁路+公路到墨西哥城（含内陆铁路段口径）
  };
  /* 物理上没有铁路通道的市场（岛国 / 跨大洋，无对华货运铁路）。这些格子一律不给「铁路价」，
     界面上直接说明无通道，而不是塞一个编出来的数字。 */
  var NO_RAIL = ['TW', 'JP', 'ID', 'PH', 'BN', 'BR', 'AR'];
  /* 铁路通道确实存在、但公开渠道查不到成交单价的——标「待询价」，不硬造数字。 */
  var RAIL_PENDING = ['MY', 'SG'];
  var LCL_MIN = { sea: 300, rail: 500, railsea: 500 };            // 拼箱最低一票
  var KG_PER_CBM = 167;

  /** 单价来源台账（界面上的「口径与来源」直接读这张表，可回溯到站点与报价日期）。 */
  var FREIGHT_SRC = {
    BN: { sea: '长和运 EMC 直拼 O/F $29/CBM + 共创物流/供应商网到门区间（2026-10）· 中置信' },
    AR: { sea: '厦门牧邦 $110–180/CBM、迪士国际 FCL 折算印证（2026-11-03）· 中置信' },
    RU: { sea: 'ChenXin 海参崴 $50–80/CBM、tonlexing 圣彼得堡线 $80–180/CBM（2026-05/07）· 中置信（按莫斯科线取高值）' },
    ID: { sea: '海派周报 东莞/义乌仓 ¥1900–2000/CBM（2026-07-28）· 高置信' },
    BR: { sea: 'AllBestShipping LCL $80–150/CBM、DTFU 全包 DAP $130–350/CBM（2026 Q3）· 高置信' },
    US: { sea: 'Great Hensen 全包到门不含税 ≈$475/CBM、rateseek 纯海运 $55–80/CBM（2026-11-02）· 高置信' },
    TH: { sea: '恒盛通 DDP 580–900 元/CBM（2026-07-07）· 高置信', rail: '锦秀/恒盛通 中老泰全铁门到门 1400–1450 元/CBM（2026-03-04 报价）· 高置信' },
    VN: { rail: '青岛/西安 11467 中越铁路门到门 400–500 元/CBM、整箱折算 289–354（2026-09-06）· 高置信' },
    MY: { rail: '中老泰马全铁已开行（国铁 2024-05）但无公开元/CBM 成交单价 → 待询价' },
    SG: { rail: '经马来西亚铁路短驳、无中国始发终到新加坡的在售班列 → 待询价' },
    SA: { sea: '海运拼箱双清 1400–1800 元/CBM（2026-10/11）· 中置信', railsea: '义乌西→乐清湾港→吉达 18 天（ESL 红海线 2026-11-02）· 中置信' },
    MX: { railsea: '海运至曼萨尼约 + Ferromex 内陆铁路 ≈$120/CBM 含铁路段（2026-09-22）· 中置信' },
    JP: { sea: '海运拼箱 880–2000 元/CBM（MBM $135/CBM 2024-09）· 中置信' },
    PH: { sea: '菲律宾专线拼箱 780–1100 元/CBM、马尼拉 LCL ¥750–1000（2026-09）· 中置信' },
    TW: { sea: '百运/递四方 800–1500 元/CBM（2026-11-01）· 中置信' },
    US_railsea: { railsea: '美森正班美西 11–18 天 + IPI 铁路美东 7–10 天（2026-09/10）· 高置信' }
  };

  /** 某市场可用的运输方式（给界面下拉用）。无铁路通道的市场不列铁路，改在来源里说明原因。 */
  function shippingModes(country) {
    var c = normCountry(country);
    var modes = [{ key: 'official', label: '官方物流（空运小包）' }];
    if (SEA_PER_CBM[c] != null) modes.push({ key: 'sea', label: '海运（散货拼箱·预估）' });
    if (RAIL_PER_CBM[c] != null) modes.push({ key: 'rail', label: '铁路班列（预估）' });
    if (RAILSEA_PER_CBM[c] != null) modes.push({ key: 'railsea', label: '联运（海运+目的国铁路）' });
    return modes;
  }

  /** 无铁路通道 / 待询价的说明文案（界面摆在来源折叠里，不占正文）。 */
  function railNote(country) {
    var c = normCountry(country);
    if (RAIL_PER_CBM[c] != null || RAILSEA_PER_CBM[c] != null) return null;
    if (NO_RAIL.indexOf(c) >= 0) return '该市场无对华铁路通道（岛国或跨大洋，物理上没有铁路路径），只给海运与官方口径';
    if (RAIL_PENDING.indexOf(c) >= 0) return '铁路通道存在，但公开渠道查不到成交单价 → 待询价，不硬造数字';
    return '规则库未收录该市场的铁路参考价';
  }

  /**
   * 按运输方式算运费（人民币）。
   *  official → 首重锚点 × 分档系数（原有逻辑，有来源的用来源，缺的如实返回 null）
   *  sea/rail/railsea → 单价 ¥/CBM 折算成 ¥/kg（÷167 体积换重），再乘档位上限重量。
   *    注意：拼箱「最低一票」是按整票收费的门槛，不是单件商品的成本，
   *    所以只写进来源说明，不参与计算——否则所有国家都会被压成同一个 ¥300，比较就失去意义。
   */
  function shippingByMode(country, weightBand, mode) {
    var code = normCountry(country);
    if (mode === 'sea' || mode === 'rail' || mode === 'railsea') {
      var perCbm = (mode === 'sea' ? SEA_PER_CBM[code] : mode === 'rail' ? RAIL_PER_CBM[code] : RAILSEA_PER_CBM[code]);
      if (perCbm == null) {
        var why = railNote(code);
        var modeName = mode === 'sea' ? '海运' : mode === 'rail' ? '铁路' : '联运';
        return {
          costCny: null,
          reason: modeName + '暂无 ' + (code || '该市场') + ' 的参考价（不代算）' + (mode !== 'sea' && why ? '：' + why : ''),
          source: '—'
        };
      }
      var band = WEIGHT_BANDS.find(function (b) { return b.key === weightBand; }) || WEIGHT_BANDS[0];
      /* 档位上限重量从 key（'2-5'）取，不要拿 label 去 Number()——
         Number('5 kg（首重）') 是 NaN，旧写法会让 0–1 与 2–5 档算出同一个价。 */
      var kg = Number(String(band.key).split('-')[1]) || Number(band.max) || 1;
      var perKg = perCbm / KG_PER_CBM;
      var cost = kg * perKg;
      var modeName = mode === 'sea' ? '海运' : mode === 'rail' ? '铁路' : '联运（海运+目的国铁路）';
      var src = (FREIGHT_SRC[code] && FREIGHT_SRC[code][mode]) || '';
      return {
        costCny: Math.round(cost * 100) / 100,
        band: band.label, perKgCny: Math.round(perKg * 100) / 100,
        quality: 'MARKET_ESTIMATE', confidence: 'LOW', verified: SNAPSHOT_DATE,
        source: modeName + ' ¥' + perCbm + '/CBM ÷ ' + KG_PER_CBM + 'kg ≈ ¥' + Math.round(perKg*100)/100 + '/kg × ' + kg + 'kg = ¥' + Math.round(cost*100)/100
                + '（双清到门预估；拼箱整票最低 ¥' + LCL_MIN[mode] + '，按票不按件）'
                + (src ? '｜来源：' + src : ''),
        note: '纯预估口径，仅用于选品比较；实际以货代报价为准'
      };
    }
    return shippingCny(code, weightBand);
  }

  var WEIGHT_BANDS = [
    { key: '0-1', label: '0–1 kg（首重）', mult: 1.0 },
    { key: '1-2', label: '1–2 kg', mult: 1.55 },
    { key: '2-5', label: '2–5 kg', mult: 2.6 }
  ];

  /* 其他成本缓冲（退货/广告/仓储），占售价的百分比。
     对齐 computeProfitEstimate 里 priceMin*0.10 的兜底口径。 */
  var OTHER_BUFFER_PCT = 10;

  /* ── 工具 ─────────────────────────────────────────────────────────── */
  function normCountry(c) { return String(c || '').toUpperCase().trim(); }

  function marketOf(platform, country) {
    var code = normCountry(country);
    return (MARKETS[platform] || []).find(function (m) { return m.code === code; }) || null;
  }

  /** 中文国家名 / 代码 / 常见别名 → {code,name,currency}；查不到返回 null。 */
  function resolveCountry(platform, text) {
    var t = String(text || '').trim();
    if (!t) return null;
    var up = t.toUpperCase();
    var list = MARKETS[platform] || [];
    return list.find(function (m) { return m.code === up || m.name === t; })
      || (MARKETS.SHOPEE || []).find(function (m) { return m.code === up || m.name === t; })
      || (MARKETS.TIKTOK_SHOP || []).find(function (m) { return m.code === up || m.name === t; })
      || (MARKETS.LAZADA || []).find(function (m) { return m.code === up || m.name === t; })
      || (MARKETS.OZON || []).find(function (m) { return m.code === up || m.name === t; })
      || null;
  }

  /** 汇率：1 CNY = X 目标币；未知返回 null（绝不猜）。 */
  function fxPerCny(currency) {
    var c = String(currency || '').toUpperCase();
    if (c === 'CNY') return { perCny: 1, tier: 'BASE', asOf: SNAPSHOT_DATE };
    return FX[c] || null;
  }

  /**
   * 综合费率（%）。复刻后端保守规则：店型未知时，本土行与跨境行取「更高」的那条
   * （宁可压低利润，绝不虚高）。表里没有 → null + reason。
   */
  function feeRate(platform, country, sellerType) {
    var code = normCountry(country);
    var row = FEES[platform + '/' + code] || FEES[platform + '/' + (COUNTRY_ALIAS[code] || '')] || null;
    if (!row || row.quality === 'MISSING') {
      return { pct: null, quality: 'MISSING', reason: '规则库未收录该平台×该国家的费率，请手工填写（不代算）', source: '—' };
    }
    var st = String(sellerType || '').toUpperCase();
    var picked, basis;
    if (st === 'CROSS_BORDER' && row.X != null) { picked = row.X; basis = '跨境店行'; }
    else if (st === 'LOCAL' && row.L != null) { picked = row.L; basis = '本土店行'; }
    else if (row.L == null && row.X != null) { picked = row.X; basis = '跨境店行'; }
    else if (row.X == null && row.L != null) { picked = row.L; basis = '本土/通配行'; }
    else { picked = Math.max(row.L, row.X); basis = row.X > row.L ? '店型未知→取本土/跨境较高者（保守）' : '本土/通配行'; }
    return {
      pct: Math.round(picked * 10000) / 100,
      quality: row.quality, confidence: row.conf, verified: row.v, basis: basis,
      source: 'MARKETPLACE_FEES ' + row.v, note: row.note || ''
    };
  }

  /**
   * 跨境运费（人民币）。首重锚点 × 分档系数 → 目的地币种 → 按参考汇率折回 CNY。
   * 国家不在表里 / 汇率缺 → null + reason。
   */
  function shippingCny(country, weightBand) {
    var code = normCountry(country);
    var base = SHIP_FIRST[code];
    if (!base) {
      var guide = (code && ['GB','DE','FR','IT','ES','IE','AT','BE','NL','PL'].indexOf(code) >= 0)
        ? '欧洲线按公斤连续计费且叠加 VAT，官方未公布统一首重表——请在卖家中心「运费试算」按你的重量档查一次填进来，填一次以后就固定用你填的。'
        : (code && ['MX','BR','SA','JP','BN','AR'].indexOf(code) >= 0)
        ? '该市场为本土/邀请制或拉美远线，公开渠道查不到可引的首重表——请用真实运价单覆盖。'
        : '请在卖家中心「运费试算」查一次填进来。';
      return { costCny: null, reason: '规则库未收录 CN→' + (code || '该国家') + ' 的跨境首重参考价（不代算）。' + guide, source: '—' };
    }
    var band = WEIGHT_BANDS.find(function (b) { return b.key === weightBand; }) || WEIGHT_BANDS[0];
    var fx = fxPerCny(base.currency);
    if (!fx) {
      return { costCny: null, reason: '缺 ' + base.currency + ' 参考汇率，无法折算运费（不代算）', source: '—' };
    }
    var local = base.cost * band.mult;
    return {
      costCny: Math.round((local / fx.perCny) * 100) / 100,
      localAmount: Math.round(local * 100) / 100,
      localCurrency: base.currency,
      band: band.label,
      quality: 'MARKET_REFERENCE', confidence: 'LOW', verified: '2026-10-19',
      source: 'CB_FIRST_WEIGHT 2026-10-19 ×' + band.mult + ' + FX ' + fx.asOf,
      note: '空运首重+续重口径的粗估，仅供选品估算；精确值须用真实运价单覆盖'
    };
  }

  /**
   * 利润测算。任何一项缺 → 该项标 missing，整体结论降级为「信息不足」，绝不硬出数。
   * 入参：purchaseCny 采购价、targetPrice 目标售价（targetCurrency）、
   *       shippingCny 运费、feePct 综合费率%、otherPct 其他成本%
   */
  function profit(o) {
    var missing = [], out = { missing: missing };
    var fx = fxPerCny(o.targetCurrency || 'CNY');
    if (!fx) { missing.push('汇率(' + o.targetCurrency + ')'); out.verdict = '信息不足'; return out; }
    out.fx = fx;

    var need = [
      ['采购价', o.purchaseCny, 0],
      ['目标售价', o.targetPrice, 0.000001],
      ['运费', o.shippingCny, 0],
      ['综合费率', o.feePct, 0]
    ];
    need.forEach(function (n) { if (!Number.isFinite(Number(n[1])) || Number(n[1]) < n[2]) missing.push(n[0]); });
    if (missing.length) { out.verdict = '信息不足'; return out; }

    var revenueCny = o.targetPrice / fx.perCny;
    var feeRate = Number(o.feePct) / 100;
    var otherRate = (o.otherPct == null || !Number.isFinite(Number(o.otherPct)) ? OTHER_BUFFER_PCT : Number(o.otherPct)) / 100;
    var feeCny = revenueCny * feeRate;
    var otherCny = revenueCny * otherRate;
    var costCny = o.purchaseCny + o.shippingCny + feeCny + otherCny;
    var profitCny = revenueCny - costCny;

    out.revenueCny = r2(revenueCny);
    out.feeCny = r2(feeCny);
    out.otherCny = r2(otherCny);
    out.totalCostCny = r2(costCny);
    out.profitCny = r2(profitCny);
    out.marginPct = revenueCny > 0 ? r1(profitCny / revenueCny * 100) : null;
    out.roiPct = (o.purchaseCny + o.shippingCny) > 0 ? r1(profitCny / (o.purchaseCny + o.shippingCny) * 100) : null;
    out.breakEvenPrice = r2(((o.purchaseCny + o.shippingCny) / (1 - feeRate - otherRate)) * fx.perCny);

    /* 判定阈值照抄 market-first-selection.service.ts：≥30% 值得测试，≥15% 谨慎测试 */
    var m = out.marginPct;
    out.verdict = m == null ? '信息不足' : (m >= 30 ? '值得测试' : (m >= 15 ? '谨慎测试' : '暂不建议'));
    out.threshold = '毛利率 ≥30% 值得测试 / ≥15% 谨慎测试（ShopSage 选品引擎口径）';
    return out;
  }

  /** 反推：按目标毛利率应该卖多少钱（目的地币种）。 */
  function suggestPrice(o) {
    var fx = fxPerCny(o.targetCurrency || 'CNY');
    if (!fx || !(o.purchaseCny > 0) || !(o.shippingCny > 0)) return null;
    var feeRate = (o.feePct || 0) / 100;
    var otherRate = (o.otherPct == null || !Number.isFinite(Number(o.otherPct)) ? OTHER_BUFFER_PCT : Number(o.otherPct)) / 100;
    var target = (o.targetMarginPct == null ? 30 : o.targetMarginPct) / 100;
    var denom = 1 - feeRate - otherRate - target;
    if (denom <= 0) return null;
    return r2(((o.purchaseCny + o.shippingCny) / denom) * fx.perCny);
  }

  /**
   * 一次算齐：平台+国家 → 币种、费率、运费、建议售价。
   * 用户填过的字段（override）永远优先于规则库。
   */
  function resolve(input) {
    var platform = input.platform, countryText = input.country;
    var market = resolveCountry(platform, countryText);
    var code = market ? market.code : normCountry(countryText);
    var currency = input.currency || (market ? market.currency : null);
    var fee = feeRate(platform, code, input.sellerType);
    var ship = shippingByMode(code, input.weightBand, input.transportMode || 'official');
    return {
      platform: platform,
      platformSupported: (PLATFORMS.find(function (p) { return p.key === platform; }) || {}).supported === true,
      market: market,
      country: code,
      countryName: market ? market.name : (countryText || ''),
      access: market ? market.access : null,
      currency: currency,
      currencyKnown: !!fxPerCny(currency),
      fee: fee,
      shipping: ship,
      otherBufferPct: OTHER_BUFFER_PCT,
      bandNote: market && market.band ? ('规则库佣金区间：' + market.band) : ''
    };
  }

  function r2(n) { return Number.isFinite(n) ? Math.round(n * 100) / 100 : null; }
  function r1(n) { return Number.isFinite(n) ? Math.round(n * 10) / 10 : null; }

  root.SS_RULES = {
    shippingModes: shippingModes,
    shippingByMode: shippingByMode,
    railNote: railNote,
    SNAPSHOT_DATE: SNAPSHOT_DATE,
    PLATFORMS: PLATFORMS,
    MARKETS: MARKETS,
    WEIGHT_BANDS: WEIGHT_BANDS,
    CURRENCIES: Object.keys(FX),
    resolveCountry: resolveCountry,
    marketOf: marketOf,
    fxPerCny: fxPerCny,
    feeRate: feeRate,
    shippingCny: shippingCny,
    profit: profit,
    suggestPrice: suggestPrice,
    resolve: resolve
  };
})(typeof window !== 'undefined' ? window : this);
