/**
 * ShopSage 选品助手 · 页面采集层（content script 与 popup 注入共用）
 *
 * 为什么要有这个文件（2026-11-08 实测根因）：
 *   旧版拼多多采集只认 `document.querySelectorAll('a[href]')`，再用 goods_id 正则过滤。
 *   实测 mobile.yangkeduo.com/search_result.html 整页 DOM 里 goods_id 只出现 1 次，
 *   且那 1 次在内联 <script> 的 `window._SSR_` 数据块里；商品卡片全是 div + JS 跳转，
 *   没有任何带 goods_id 的 <a>。所以旧逻辑在拼多多上恒等于 0 张卡片 —— 不是选择器写窄了，
 *   是这条路径根本不存在。
 *
 * 新策略（妙手那类插件的取数思路：拿页面自己的结构化数据，不猜 DOM）：
 *   1. 主路径：从内联 <script> 文本里抠出 `window._SSR_` / `__NEXT_DATA__` / `__INITIAL_STATE__`
 *      这类服务端注水数据块，递归找出带 goods_id + 标题的对象。
 *      —— 注意 content script 跑在 ISOLATED world，读不到页面的 window._SSR_ 变量本体，
 *         但 <script> 元素的 textContent 是两个世界共享的 DOM，所以抠文本可行、零注入零通信。
 *   2. 桥接 DOM：用标题文本反查卡片元素，把按钮挂上去，并从卡片可见文字里读「人民币元」价，
 *      避免直接信数据块里的整数价（拼多多接口价单位是「分」，388 = ¥3.88）。
 *   3. 兜底：保留旧的 <a href> 规则（万一页面结构回滚）+ 卡片文字扫描。
 */
(function (root) {
  'use strict';

  var clean = function (v) { return String(v == null ? '' : v).replace(/[\s​]+/g, ' ').trim(); };
  var num = function (v) { var n = Number(v); return Number.isFinite(n) ? n : null; };

  /* 从任意文本里抠第一个 ¥/￥ 价格（单位：元）。
   * 实测坑：拼多多把整数和小数拆成两个节点（"¥421" + ".9"），中间还可能夹换行，
   * 老写法 [¥￥]\s*(\d+(?:[.,]\d{1,2})?) 只会拿到 421，把 ¥421.9 读成 ¥421。
   * 现在允许小数部分被空白隔开单独跟在后面。 */
  function priceFromText(text) {
    var t = clean(text).replace(/(\d),(\d{3})(?!\d)/g, '$1$2');   // 先去千分位，免得 ¥1,299.00 读成 1.29
    var m = t.match(/[¥￥]\s*(\d+)(?:\s*[.,]\s*(\d{1,2}))?/);
    if (m) return m[2] != null ? Number(m[1] + '.' + m[2]) : Number(m[1]);
    m = t.match(/(\d+(?:[.,]\d{1,2})?)\s*元/);
    return m ? num(m[1].replace(/,/g, '.')) : null;
  }

  /* 抠出 text 中 startIdx 处 '{' 的配平 JSON 片段（认字符串与转义） */
  function balancedObject(text, startIdx) {
    var i = text.indexOf('{', startIdx);
    if (i < 0) return null;
    var depth = 0, inStr = false, esc = false;
    for (var j = i; j < text.length; j++) {
      var c = text.charAt(j);
      if (inStr) {
        if (esc) { esc = false; }
        else if (c === '\\') { esc = true; }
        else if (c === '"') { inStr = false; }
        continue;
      }
      if (c === '"') inStr = true;
      else if (c === '{') depth++;
      else if (c === '}') { depth--; if (depth === 0) return text.slice(i, j + 1); }
    }
    return null;
  }

  /* 读 JSON 字符串字面量（从 openQuote 下标开始），返回 {value, end} */
  function readJsonString(text, openQuote) {
    var out = '', esc = false;
    for (var j = openQuote + 1; j < text.length; j++) {
      var c = text.charAt(j);
      if (esc) {
        out += (c === 'n' ? '\n' : c === 't' ? '\t' : c === 'u' ? text.substr(j + 1, 4) : c);
        esc = false; continue;
      }
      if (c === '\\') { esc = true; continue; }
      if (c === '"') return { value: out, end: j };
      out += c;
    }
    return null;
  }

  var SSR_MARKERS = ['window._SSR_', '__NEXT_DATA__', '__INITIAL_STATE__', 'window.rawData', 'window.g_initialProps'];
  var lastParseErrors = [];

  /** 从页面内联脚本里抽出所有注水数据对象（解析失败返回 []，不抛）。 */
  function readInjectedBlobs() {
    var blobs = [];
    lastParseErrors = [];
    var scripts = [].slice.call(document.querySelectorAll('script:not([src])'));
    scripts.forEach(function (s) {
      var text = s.textContent || '';
      if (text.length < 40) return;
      SSR_MARKERS.forEach(function (marker) {
        var at = text.indexOf(marker);
        while (at >= 0) {
          var frag = balancedObject(text, at + marker.length);
          if (frag) {
            try { blobs.push(JSON.parse(frag)); }
            catch (e) { lastParseErrors.push(marker + ' len=' + frag.length + ' err=' + e.message); }
          } else {
            lastParseErrors.push(marker + ' 找不到配平对象');
          }
          at = text.indexOf(marker, at + marker.length);
        }
      });
    });
    return blobs;
  }

  /** 结构化遍历：交给 goods-shape.js 的归一化键匹配（goods_id / goodsId / goodsID 全认）。 */
  function shapeFind(node) {
    if (root.MS_SHAPE && typeof root.MS_SHAPE.findItems === 'function') return root.MS_SHAPE.findItems(node);
    console.warn('[ShopSage] goods-shape.js 未加载，无法识别商品字段');
    return [];
  }

  /** 解析兜底：整块 JSON.parse 不了时，直接在脚本文本里按 goods_id 切片抠字段。
   *  窗口只向后取、并以「下一个 goods_id」为界——对象里 id 在前、字段在后，
   *  向前取会把上一个商品的字段错认给当前商品（实测会串号）。 */
  function sweepScriptTextForGoods(text) {
    var sink = [], re = /"goods_?id"\s*:\s*"?(\d{6,})"?/gi, hits = [], m;
    while ((m = re.exec(text))) hits.push({ id: m[1], at: m.index });
    for (var i = 0; i < hits.length && sink.length < 200; i++) {
      var from = hits[i].at;
      var to = (i + 1 < hits.length) ? hits[i + 1].at : Math.min(text.length, from + 2500);
      var win = text.slice(from, to);
      var title = fieldString(win, 'goods_name') || fieldString(win, 'goodsName') || fieldString(win, 'title');
      if (!title) continue;
      var pm = win.match(/"price"\s*:\s*"?(\d+(?:\.\d+)?)"?/i);
      sink.push({
        goodsId: hits[i].id,
        title: title.slice(0, 240),
        image: (fieldString(win, 'image_url') || fieldString(win, 'imageUrl') || fieldString(win, 'thumb_url') || '').replace(/^\/\//, 'https://'),
        rawPrice: pm ? num(pm[1]) : null,
        linkUrl: fieldString(win, 'link_url') || fieldString(win, 'linkUrl'),
        salesTip: fieldString(win, 'sales_tip') || fieldString(win, 'salesTip') || '',
        marketPrice: null
      });
    }
    return sink;
  }

  function fieldString(text, key) {
    var re = new RegExp('"' + key + '"\\s*:\\s*"');
    var m = re.exec(text);
    if (!m) return '';
    var r = readJsonString(text, m.index + m[0].length - 1);
    return r ? clean(r.value) : '';
  }

  function collectGoodsItems() {
    var items = [];
    readInjectedBlobs().forEach(function (blob) { items = items.concat(shapeFind(blob)); });
    if (!items.length) {
      [].slice.call(document.querySelectorAll('script:not([src])')).forEach(function (s) {
        var text = s.textContent || '';
        if (!/goods_?id/i.test(text)) return;
        items = items.concat(sweepScriptTextForGoods(text));
      });
    }
    var byId = new Map();
    items.forEach(function (it) { if (it.goodsId && it.title && !byId.has(it.goodsId)) byId.set(it.goodsId, it); });
    return Array.from(byId.values());
  }

  /* ── 拼多多：把数据块里的商品桥回 DOM 卡片 ─────────────────────────── */

  /** 标题探针候选：拼多多的【品牌】前缀常是独立元素，标题也可能被拆成多个文本节点，
   *  所以按「整段前缀 → 短前缀 → 去掉品牌前缀 → 中段」依次试。 */
  function titleProbes(title) {
    var t = clean(title);
    var noBrand = t.replace(/^【[^】]{1,20}】/, '');
    var probes = [t.slice(0, 12), t.slice(0, 6), noBrand.slice(0, 12), noBrand.slice(0, 6)];
    if (t.length > 24) probes.push(t.slice(12, 24));
    return probes.filter(function (p) { return p.length >= 4; });
  }

  function firstTextNodeWith(key) {
    // 必须在 acceptNode 里排除 <script>/<style>/<template> 里的文本：
    // 拼多多的数据块脚本本身就含全部商品标题，实测 TreeWalker 会先命中脚本里的文本节点，
    // 于是 20 件商品「都找到了卡片」——其实是同一个 <script>，价格全读成同一个数、按钮只挂上 1 个。
    var insideInert = function (el) {
      while (el && el.nodeType === 1) {
        var tag = el.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'TEMPLATE') return true;
        el = el.parentElement;
      }
      return false;
    };
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        if ((n.nodeValue || '').indexOf(key) < 0) return NodeFilter.FILTER_REJECT;
        if (insideInert(n.parentElement)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    return walker.nextNode();
  }

  /** 容器里是否已经混进别的商品标题 —— 混进去就说明这一层是列表容器，不是卡片。 */
  function hasOtherTitle(text, others, self) {
    for (var i = 0; i < others.length; i++) {
      var o = others[i];
      if (!o || o === self) continue;
      if (text.indexOf(o.slice(0, 10)) >= 0) return true;
    }
    return false;
  }

  /** 从图片 URL 里取一个足够独特的片段当钥匙（PDD 每张主图是独立 hash 文件名）。
   *  实测教训：靠标题文本找卡片不可靠 —— 拼多多把标题拆成多个文本节点，
   *  12 字前缀在 DOM 里根本不连续，结果 20 件商品一个卡片都定位不到。
   *  图片 URL 是每件商品独有的，反而稳。 */
  function imageKey(url) {
    var seg = String(url || '').split('?')[0].split('/').pop() || '';
    seg = seg.replace(/\.(jpg|jpeg|png|webp|gif)$/i, '').replace(/_.+$/, '');
    return seg.length >= 8 ? seg : '';
  }

  /** 从图片元素向上收出真正的卡片容器。 */
  function cardFromElement(start, item, others) {
    var el = start, lastGood = null;
    for (var up = 0; up < 9 && el && el !== document.body; up++, el = el.parentElement) {
      var box = el.getBoundingClientRect();
      if (box.width < 1 || box.height < 1) break;
      var txt = el.innerText || '';
      if (txt.length > 420) break;
      if (box.width < 110 || box.height < 150) continue;
      if (!el.querySelector('img')) continue;
      if (hasOtherTitle(txt, others || [], item.title)) break;
      lastGood = el;
      if (priceFromText(txt) != null) return el;
    }
    return lastGood;
  }

  function findCardByImage(item, others) {
    var key = imageKey(item.image);
    if (!key) return null;
    var imgs = [].slice.call(document.querySelectorAll('img'));
    for (var i = 0; i < imgs.length; i++) {
      var im = imgs[i];
      var src = im.currentSrc || im.src || im.getAttribute('data-src') || im.getAttribute('data-src') || '';
      if (src.indexOf(key) < 0) continue;
      var card = cardFromElement(im.parentElement, item, others);
      if (card) return card;
    }
    return null;
  }

  /**
   * 定位这一件商品自己的卡片：先按图片，再按标题文本兜底。
   * 宁可返回 null（不挂按钮、不读错价），也绝不回退到 <script> 或列表容器 ——
   * 那会让 20 件商品共用同一个价格。
   */
  function locateCard(item, others) {
    return findCardByImage(item, others) || findCardByTitle(item.title, others);
  }

  /** 标题文本兜底：拼多多会把标题拆成多个文本节点，所以按「整段前缀 → 短前缀 →
   *  去掉【品牌】前缀 → 中段」依次试；命中后同样走 cardFromElement 的尺寸/互斥校验。 */
  function findCardByTitle(title, others) {
    var probes = titleProbes(title);
    others = others || [];
    var fake = { title: title, image: '' };
    for (var pi = 0; pi < probes.length; pi++) {
      var hit = firstTextNodeWith(probes[pi]);
      if (!hit) continue;
      var card = cardFromElement(hit.parentElement, fake, others);
      if (card) return card;
    }
    return null;
  }

  /**
   * 价格口径：
   *   1) 数据块价（平台字段，单位分）是每件商品自己的确定值，作为主价；
   *   2) 卡片可见价单独记为 visiblePrice —— 拼多多列表页常显示券后/活动价，跟数据价不一样；
   *   3) 两者不一致时标 priceNeedsReview，把两个数都摆出来让人自己判，绝不取一个数冒充另一个。
   */
  function resolvePrice(cardEl, item) {
    // 只读 innerText，绝不回退 textContent —— textContent 会把 <script> 里 16 万字的 JSON 一起读进来
    var visible = cardEl ? priceFromText(cardEl.innerText) : null;
    var data = (item.rawPrice != null && item.rawPrice > 0)
      ? Math.round((root.MS_SHAPE ? root.MS_SHAPE.toYuan(item.rawPrice, null) : item.rawPrice / 100) * 100) / 100
      : null;

    if (data != null && visible != null && Math.abs(data - visible) < 0.02) {
      return { price: data, visiblePrice: visible, priceSource: '平台数据价，与页面可见价一致', priceNeedsReview: false };
    }
    if (data != null && visible != null) {
      return {
        price: data, visiblePrice: visible,
        priceSource: '平台数据价 ¥' + data + '；页面显示 ¥' + visible + '（疑为券后/活动价）—— 两个都留着，请核对用哪个',
        priceNeedsReview: true
      };
    }
    if (data != null) return { price: data, priceSource: '平台数据价（按分折元）· 未定位到卡片可见价', priceNeedsReview: true };
    if (visible != null) return { price: visible, priceSource: '仅页面可见价（数据块没给价）', priceNeedsReview: true };
    return { price: null, priceSource: '未取到价格', priceNeedsReview: true };
  }

  function pddCanonical(item) {
    if (item.linkUrl) {
      try {
        var u = new URL(item.linkUrl, location.href);
        var gid = u.searchParams.get('goods_id') || item.goodsId;
        if (gid) return u.origin + u.pathname + '?goods_id=' + encodeURIComponent(gid);
      } catch (e) { /* 落到下面 */ }
    }
    if (item.goodsId) return location.origin + '/goods.html?goods_id=' + encodeURIComponent(item.goodsId);
    return '';
  }

  /* ── 1688（沿用已验证可用的选择器组，含新版 /zw/page.html 的 aplus-report） ── */
  var OFFER_1688 = '[data-complete-offer-id],[data-aplus-report*="object_type@offer"],.offer[data-tracker="offer"]';

  function offerIdOf1688(card) {
    var direct = card.getAttribute('data-complete-offer-id') || card.getAttribute('data-offer-id');
    if (/^\d{9,}$/.test(direct || '')) return direct;
    var report = card.getAttribute('data-aplus-report') || '';
    var m = report.match(/(?:object_id@|offerId[=:"']+)(\d{9,})/i);
    return m ? m[1] : null;
  }

  function collect1688() {
    var out = new Map();
    [].slice.call(document.querySelectorAll(OFFER_1688)).forEach(function (card) {
      var id = offerIdOf1688(card);
      if (!id || out.has(id)) return;
      var img = [].slice.call(card.querySelectorAll('img')).find(function (x) { return x.naturalWidth > 80 || x.width > 80; });
      var titleEl = card.querySelector('.offer-title,a[class*="offerCard"]');
      var title = clean((titleEl && titleEl.innerText ? titleEl.innerText.split('\n')[0] : '') || (img && img.alt) || clean(card.innerText).split('\n')[0]).slice(0, 240);
      if (!title) return;
      var price = priceFromText(card.innerText);
      out.set(id, mkProduct({
        title: title, price: price, priceSource: price == null ? '未取到价格' : '页面可见价',
        priceNeedsReview: price == null, image: img ? (img.currentSrc || img.src) : '',
        url: 'https://detail.1688.com/offer/' + id + '.html', platform: '1688',
        specs: '', salesTip: ''
      }));
    });
    return Array.from(out.values());
  }

  /* ── 拼多多列表页 ── */
  function collectPddList() {
    var goods = collectGoodsItems();
    var otherTitles = goods.map(function (g) { return g.title; });
    var out = new Map();

    goods.forEach(function (item) {
      var url = pddCanonical(item);
      if (!url || out.has(url)) return;
      var cardEl = locateCard(item, otherTitles);
      var p = resolvePrice(cardEl, item);
      out.set(url, mkProduct({
        title: item.title, price: p.price, visiblePrice: p.visiblePrice,
        priceSource: p.priceSource, priceNeedsReview: p.priceNeedsReview,
        image: item.image, url: url, platform: '拼多多', specs: '', salesTip: item.salesTip,
        capturePath: '数据块' + (cardEl ? ' + DOM 卡片桥接' : '（未定位到卡片元素，按钮未挂载）')
      }));
    });

    /* 兜底：旧 <a href> 规则，页面结构回滚时仍能采 */
    if (!out.size) {
      [].slice.call(document.querySelectorAll('a[href]')).forEach(function (a) {
        var u; try { u = new URL(a.href, location.href); } catch (e) { return; }
        var gid = u.searchParams.get('goods_id') || u.searchParams.get('goodsId') || (u.pathname.match(/\/goods\/(\d+)/) || [])[1];
        if (!gid || !/goods|detail/i.test(u.pathname)) return;
        var url = u.origin + u.pathname + '?goods_id=' + encodeURIComponent(gid);
        if (out.has(url)) return;
        var card = upCard(a);
        var title = clean((a.innerText || '').split('\n')[0] || (card && card.innerText ? clean(card.innerText).split('\n')[0] : '')).slice(0, 240);
        if (!title) return;
        var p = resolvePrice(card, { rawPrice: null });
        out.set(url, mkProduct({
          title: title, price: p.price, priceSource: p.priceSource + '（链接规则兜底）', priceNeedsReview: p.priceNeedsReview,
          image: card ? imgSrc(card) : '', url: url, platform: '拼多多', specs: '', salesTip: '', capturePath: '链接规则兜底'
        }));
      });
    }
    return Array.from(out.values());
  }

  function upCard(anchor) {
    var el = anchor;
    for (var d = 0; d < 7 && el; d++, el = el.parentElement) {
      if (el.querySelector('img') && priceFromText(el.innerText) != null) return el;
    }
    return anchor.parentElement;
  }
  function imgSrc(card) {
    var img = [].slice.call(card.querySelectorAll('img')).find(function (x) { return x.naturalWidth > 80 || x.width > 80; });
    return img ? (img.currentSrc || img.src || '') : '';
  }

  /* ── 详情页 ── */
  function collectDetail() {
    var is1688 = /(^|\.)1688\.com$/.test(location.hostname);
    var meta = function (name) {
      var el = document.querySelector('meta[property="' + name + '"],meta[name="' + name + '"]');
      return (el && el.content) || '';
    };
    var title = clean((document.querySelector('[class*="od-title" i], [class*="offer-title" i], [class*="title-text" i]') && document.querySelector('[class*="od-title" i], [class*="offer-title" i], [class*="title-text" i]').innerText) || meta('og:title') || (document.querySelector('h1') && document.querySelector('h1').innerText) || document.title).slice(0, 240);
    var image = meta('og:image') || (document.querySelector('img[src]') ? document.querySelector('img[src]').src : '');
    var visiblePrice = null, priceSource = '';
    var price = priceFromText((document.querySelector('[class*="price" i]') || {}).textContent)
      || priceFromText(document.body.innerText.slice(0, 4000));
    if (price != null) { visiblePrice = price; priceSource = '详情页可见价'; }
    var url = location.href, platform = is1688 ? '1688' : '拼多多', salesTip = '';

    if (!is1688) {
      var goods = collectGoodsItems();
      var gid = new URL(location.href).searchParams.get('goods_id') || new URL(location.href).searchParams.get('goodsId');
      var mine = goods.find(function (g) { return g.goodsId === gid; }) || goods[0];
      if (mine) {
        if (!title || title.length < 6) title = mine.title;
        if (!image) image = mine.image;
        salesTip = mine.salesTip;
        var p = resolvePrice(null, mine);          // 详情页没有列表卡片，数据块价当主价
        if (p.price != null) { price = p.price; }
        if (p.priceSource) priceSource = p.priceSource;
        if (gid) url = location.origin + '/goods.html?goods_id=' + encodeURIComponent(gid);
      }
    } else {
      var m = location.pathname.match(/\/offer\/(\d+)\.html/i);
      if (m) url = 'https://detail.1688.com/offer/' + m[1] + '.html';
      // 详情页顶部区域以公司名为 h1/标题时不得误认为商品名；优先拿页面中可见商品标题。
      var company = clean(document.querySelector('[class*="company" i] [class*="name" i], [class*="shop" i] [class*="name" i]')?.innerText || '');
      var seller = company || clean(document.querySelector('[class*="company" i], [class*="shop" i]')?.innerText || '').split('\n')[0];
      var productTitle = clean(document.querySelector('[class*="od-title" i], [class*="offer-title" i], [class*="title-text" i]')?.innerText || '');
      if (productTitle && productTitle !== company && !/有限公司|公司$|旗舰店$|专营店$/.test(productTitle)) title = productTitle.slice(0, 240);
      if (/有限公司|公司$|旗舰店$|专营店$/.test(title) && productTitle && !/有限公司|公司$/.test(productTitle)) title = productTitle.slice(0, 240);
      if (seller) window.__MS_DETAIL_SELLER__ = seller.slice(0, 160);
    }

    return [mkProduct({
      title: title, price: price, visiblePrice: visiblePrice,
      priceSource: priceSource || (price == null ? '未取到价格' : '详情页可见价'),
      priceNeedsReview: true, image: image, url: url, platform: platform,
      specs: clean((document.body.innerText.match(/(?:规格|颜色|尺寸|型号)[：:][^。\n]{0,100}/) || [''])[0]),
      salesTip: salesTip, capturePath: '详情页'
    })];
  }

  function domDetailFallback() {
    const titleNode = document.querySelector('[class*="od-title" i], [class*="offer-title" i], [class*="title-text" i], [class*="title" i][class*="detail" i]');
    const title = clean(titleNode?.innerText || document.querySelector('h1')?.innerText || document.querySelector('meta[property="og:title"]')?.content || '');
    const sellerNode = document.querySelector('[class*="company" i] [class*="name" i], [class*="shop" i] [class*="name" i], [class*="company" i], [class*="shop" i]');
    const seller = clean(sellerNode?.innerText || '').split('\n')[0];
    const isProductTitle = value => value && !/有限公司|公司$|旗舰店$|专营店$|商行$/.test(value);
    const imageRoot = document.querySelector('[class*="od-gallery" i], [class*="gallery" i], [class*="preview" i], [class*="offer-img" i]') || document;
    const images = Array.from(imageRoot.querySelectorAll('img'))
      .map(img => img.currentSrc || img.src || img.getAttribute('data-src') || '')
      .filter(src => /^https?:/i.test(src) && /alicdn|1688/i.test(src))
      .filter((src, index, all) => all.indexOf(src) === index)
      .slice(0, 40);
    const attrRoot = document.querySelector('[class*="attribute" i], [class*="offer-attr" i], [class*="product-attr" i]');
    const attributes = attrRoot ? Array.from(attrRoot.querySelectorAll('tr, li, dl'))
      .map(node => clean(node.innerText)).filter(Boolean).slice(0, 80) : [];
    const skuNodes = Array.from(document.querySelectorAll('[class*="sku-item" i], [class*="skuItem"], [class*="spec-item" i], [class*="prop-item" i]'))
      .map(node => ({ node, text: clean(node.innerText) }))
      .filter(x => x.text && x.text.length < 180 && x.node.getBoundingClientRect().width > 0)
      .slice(0, 200);
    const skuProps = skuNodes.length ? [{ name: '页面规格', values: Array.from(new Set(skuNodes.map(x => x.text))).slice(0, 100) }] : [];
    const skus = skuNodes.map(x => ({ spec: x.text, price: priceFromText(x.text), stock: null }));
    const descRoot = document.querySelector('#desc-lazyload-container, #detail, [class*="description" i], [class*="detail-content" i]');
    const descriptionHtml = String(descRoot?.innerHTML || '').slice(0, 200000);
    return {
      host: '1688', title: isProductTitle(title) ? title.slice(0, 240) : '', seller,
      images, skuProps, skus, props: attributes,
      logistics: null, category: '', descriptionHtml,
      captureStatus: 'DOM_FALLBACK',
      raw: JSON.stringify({ title, seller, attributes, skuText: skuNodes.map(x => x.text), visibleText: clean(document.body?.innerText || '').slice(0, 12000) }).slice(0, 30000),
    };
  }

  function mkProduct(f) {
    return {
      id: (root.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2),
      title: f.title || '',
      price: f.price == null ? null : f.price,
      visiblePrice: f.visiblePrice == null ? null : f.visiblePrice,
      priceNeedsReview: !!f.priceNeedsReview,
      priceSource: f.priceSource || '',
      currency: 'CNY',
      image: f.image || '',
      url: f.url || '',
      platform: f.platform || '未知',
      source: f.platform || '未知',
      specs: f.specs || '',
      salesTip: f.salesTip || '',
      capturePath: f.capturePath || '',
      capturedAt: new Date().toISOString()
    };
  }

  /** 统一入口：返回当前页可采集的商品数组。 */
  function capture() {
    var host = location.hostname;
    var arr;
    if (/(^|\.)1688\.com$/.test(host)) {
      arr = /\/offer\/\d+/.test(location.pathname) ? collectDetail() : collect1688();
    } else if (/(^|\.)(pinduoduo|yangkeduo)\.com$/.test(host)) {
      arr = /goods\.html|\/goods\/|detail/i.test(location.pathname) && new URL(location.href).searchParams.get('goods_id')
        ? collectDetail() : collectPddList();
    } else {
      arr = [];
    }
    /* 详情页整页内容（SKU 表/图组/属性/物流）挂到唯一商品上——妙手式编辑器的数据底座 */
    try {
      if (/offer\/\d+|goods\.html|\/goods\/|detail/i.test(location.pathname + location.search)) {
        var c = null;
        try { if (window.MS_CONTENT) c = window.MS_CONTENT.forUrl(location.href); } catch (eC) { c = null; }
        if (!c && arr && arr[0] && /(^|\.)1688\.com$/.test(location.hostname)) c = domDetailFallback();
        if ((!c || c.__msDiag) && arr && arr[0] && /(^|\.)1688\.com$/.test(location.hostname)) {
          var domFallback = domDetailFallback();
          if (domFallback.title || domFallback.images.length || domFallback.descriptionHtml) c = domFallback;
        }
        if (!c && arr && arr[0]) {
          // 整页内容没拿到：把 page-hook 写在 DOM 上的诊断随采集带走（跨世界桥，消息通道会丢）
          var diagRaw = null;
          try { diagRaw = document.documentElement.getAttribute('data-ms-diag'); } catch (eD) { diagRaw = null; }
          var diag = null;
          try { diag = diagRaw ? JSON.parse(diagRaw) : null; } catch (eJ) { diag = null; }
          c = { __msDiag: true, diag: diag || { note: diagRaw ? 'diag_parse_failed' : 'hook_not_running', url: String(location.href).slice(0, 160), ts: Date.now() } };
        }
        if (c && arr && arr[0]) {
          arr[0].content = c;
          if (c.host === '1688') {
            if (c.title && !/有限公司|公司$|旗舰店$|专营店$/.test(c.title)) arr[0].title = c.title;
            if (c.seller) arr[0].seller = c.seller;
            if ((!arr[0].image || /company|shop/i.test(arr[0].image)) && c.images?.[0]) arr[0].image = c.images[0];
          }
        }
      }
    } catch (e) { /* noop */ }
    return arr;
  }

  root.MS_CAPTURE = capture;
  /** 带卡片元素版：content.js 要靠这个把按钮挂到「这一件商品自己的卡片」上。
   *  必须把全部标题一起传进去做互斥判断，否则会像实测那样 20 件都拿到同一个列表容器。 */
  root.MS_CAPTURE_WITH_CARDS = function () {
    var products = capture() || [];
    var titles = products.map(function (p) { return p.title; });
    return products.map(function (p) {
      var card = null;
      try { card = /(^|\.)(pinduoduo|yangkeduo)\.com$/.test(location.hostname) ? locateCard({ title: p.title, image: p.image }, titles) : null; }
      catch (e) { card = null; }
      return { product: p, card: card };
    });
  };
  root.MS_OFFER_CARDS_1688 = function () {
    var map = new Map();
    document.querySelectorAll('[data-complete-offer-id],[data-aplus-report*="object_type@offer"],.offer[data-tracker="offer"]').forEach(function (card) {
      var id = offerIdOf1688(card);
      if (id) map.set('https://detail.1688.com/offer/' + id + '.html', card);
    });
    return map;
  };
  root.MS_FIND_CARD_BY_TITLE = findCardByTitle;
  root.MS_PRICE_FROM_TEXT = priceFromText;
})(typeof window !== 'undefined' ? window : this);
