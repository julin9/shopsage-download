/**
 * ShopSage 选品助手 · 详情页数据包归一化（0.9.8，2026-11-09 用真实页面样本钉死结构）
 *
 * 为什么单独一个文件：这套映射必须能拿真实页面样本离线跑测试，不能只靠"在页面上试运气"。
 *
 * 2026-11-09 用 CDP 直连真实详情页测出来的事实（不是猜的）：
 *   · 数据包挂在 window.context，共 70,175 字节，结构 = context.result.data.<模块名>.fields
 *   · 内联脚本 #20 是 `window.context=(function(){...})(...)` 的 IIFE —— 对它做 JSON.parse /
 *     平衡括号提取永远失败（实测报 "Expected property name ... @script#20"），这条路彻底废掉。
 *   · window.offer_details 不是数据包，它是详情描述 HTML（实测 1,737 字节、含 10 个 <img>）。
 *   · 模块与字段（实测样本 offer 1085755976709）：
 *       productTitle .title / .shopInfo.authCompanyName / .saleNum
 *       gallery      .offerImgList（8 张主图）/ .video{videoUrl,coverUrl,videoId} /
 *                    .CpvEnhance.decisionCpv+normalCpv（材质/品牌/规格/主要下游平台/销售地区…）
 *       mainPrice    .finalPriceModel.tradeWithoutPromotion.skuMapOriginal[]（specAttrs/price/canBookCount/skuId）
 *                    .priceModel.currentPrices[]（price/beginAmount）
 *       description  .leafCategoryId（实测 122110003）/ .detailUrl（天猫 CDN 详情 HTML）
 *       productPackInfo .unitWeight（0.06 kg）/ .pieceWeightScale.pieceWeightScaleInfo[].weight（60 g）
 *       shippingServices .postFeeValue / .minWeight / .officialLogistics / .logistics
 *       productWarning   .cautionText / .officialDocInfos[]（这个商品是空数组 → 如实 0，不编）
 *
 * 铁律：接口/页面上没有的字段一律给 null 或空数组，绝不编；每个区块都带上来源说明，
 *       让后台能区分「页面确实没有」和「没采到」。
 */
(function (root) {
  'use strict';

  const clean = (v) => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  /** 页面里 specAttrs/属性值带 HTML 实体（实测「奥利奥&gt;90*65CM」），不解开就直接写进对客界面 */
  const ENTITIES = { '&gt': '>', '&lt': '<', '&quot': '"', '&apos': "'", '&nbsp': ' ', '&amp': '&' };
  const unentity = (v) => String(v == null ? '' : v).replace(/&(gt|lt|quot|apos|nbsp|amp);?/gi, (m, k) => ENTITIES['&' + k.toLowerCase()] != null ? ENTITIES['&' + k.toLowerCase()] : m);
  /**
   * 详情描述清洗：实测有的页面 window.offer_details.content 是干净 HTML，
   * 有的页面直接把整条 `var offer_details={"content":"…"}` 语句塞进来（还带双重转义）。
   * 一律剥掉 JS 外壳、解开转义，只留 HTML；剥不出来就如实留空，不编描述。
   */
  function cleanDescriptionHtml(raw) {
    let s = String(raw == null ? '' : raw);
    if (!s) return '';
    const m = s.match(/^\s*var\s+[\w$]+\s*=\s*(\{[\s\S]*\})\s*;?\s*$/);
    if (m) {
      try {
        const parsed = JSON.parse(m[1].replace(/\\&quot;/g, '"'));
        s = String((parsed && parsed.content) || '');
      } catch (e) {
        const inner = m[1].match(/"content"\s*:\s*"([\s\S]*)"\s*}\s*;?\s*$/);
        s = inner ? inner[1].replace(/\\n/g, '\n').replace(/\\u003C/gi, '<').replace(/\\u003E/gi, '>').replace(/\\"/g, '"').replace(/\\&quot;/g, '"') : '';
      }
    }
    return s.replace(/\\&quot;/g, '"').replace(/&quot;\//g, '"').slice(0, 200000);
  }
  const num = (v) => {
    if (v == null || v === '') return null;
    const n = Number(typeof v === 'string' ? v.replace(/[^\d.\-]/g, '') : v);
    return Number.isFinite(n) ? n : null;
  };
  const urls = (list, max) => (Array.isArray(list) ? list : [])
    .map((x) => (typeof x === 'string' ? x : (x && (x.url || x.image || x.imgUrl || x.src)) || ''))
    .filter((x) => /^https?:\/\//.test(x) || x.startsWith('//'))
    .map((x) => (x.startsWith('//') ? 'https:' + x : x))
    .slice(0, max || 40);

  /** 模块取值：新版是 {fields:{...}}，旧版直接是对象 */
  function fieldsOf(mod) {
    if (!mod || typeof mod !== 'object') return {};
    return mod.fields && typeof mod.fields === 'object' ? mod.fields : mod;
  }

  /** CpvEnhance 的 decisionCpv + normalCpv 拉平成 [{name, values[]}]（去重、按原顺序） */
  function flattenCpv(cpv) {
    if (!cpv || typeof cpv !== 'object') return [];
    const out = [];
    const seen = new Set();
    for (const group of [cpv.decisionCpv, cpv.normalCpv]) {
      (Array.isArray(group) ? group : []).forEach((p) => {
        const name = unentity(clean(p && p.name));
        if (!name || seen.has(name)) return;
        seen.add(name);
        const values = Array.isArray(p.values) ? p.values.map((v) => unentity(clean(typeof v === 'string' ? v : (v && v.name) || ''))).filter(Boolean).slice(0, 40) : [unentity(clean(p.value || ''))].filter(Boolean);
        out.push({ name, values });
      });
    }
    return out.slice(0, 80);
  }

  /** SKU 表：mainPrice.finalPriceModel.tradeWithoutPromotion.skuMapOriginal（实测 3 条） */
  function skusFromPrice(priceFields) {
    const f = priceFields || {};
    const lists = [
      f.finalPriceModel && f.finalPriceModel.tradeWithoutPromotion && f.finalPriceModel.tradeWithoutPromotion.skuMapOriginal,
      f.finalPriceModel && f.finalPriceModel.skuMapOriginal,
      f.skuMapOriginal,
    ];
    for (const arr of lists) {
      if (!Array.isArray(arr) || !arr.length) continue;
      return arr.slice(0, 300).map((s) => ({
        skuId: s.skuId != null ? String(s.skuId) : '',
        specId: clean(s.specId).slice(0, 64),
        spec: unentity(clean(s.specAttrs || s.spec || s.specName)) || null,
        price: num(s.price != null ? s.price : s.discountPrice),
        stock: num(s.canBookCount != null ? s.canBookCount : s.quantity),
      }));
    }
    return [];
  }

  /**
   * 价格阶梯（同一商品按采购量分档的单价）。
   *
   * 2026-11-11 生产实测把根因钉死了（不是键名猜错）：
   *   · 新版页面确实命中过阶梯 —— 库里那两条 1688 商品 priceNote=「页面价格阶梯（window.context 官方数据）」，
   *     而这个字符串只有在 priceRange 非空、ladder[0].price 是数字时才会写进去；
   *   · 但 sourceSnapshot.priceRange 全是 null —— 因为插件同步时的字段白名单（library.js / popup.js）
   *     根本没带 priceRange，整段在上传环节被丢掉。
   *   · SKU 级进价的真实来源已由同一批线上数据证实：mainPrice.fields
   *     .finalPriceModel.tradeWithoutPromotion.skuMapOriginal[]（specAttrs/price/canBookCount/skuId）。
   * 所以这里每一档都带上 from（页面里真实的键路径），再把「页面实际给了哪些数组键、
   * 每个数组第一条元素的真实字段名」做成 probe 一起交出去 —— 以后阶梯对不对是看得见的，不靠猜。
   */
  function priceLadder(priceFields) {
    const f = priceFields || {};
    const twp = (f.finalPriceModel && f.finalPriceModel.tradeWithoutPromotion) || {};
    const buckets = [
      /* 2026-11-11 线上探针实测（offer 自嗨解闷躲藏罩猫电动猫咪捕猎罩，priceDisplayType=skuPrice）：
         同一个 mainPrice 里同时给了两套价——currentPrices 是【现价，可能含促销】（7.7/16.8），
         originalPricesWithoutPromotion 是【非促销原价】（11/24，与 40 个 SKU 的进价区间完全对齐）。
         之前不分口径地把它们并成一列，插件取第一档当采购价，于是把促销价 7.7 写成了成本
         —— 促销价不是采购价，这里给每档标 kind，让服务端能按「非促销原价」这条轴算成本。 */
      { path: 'priceModel.currentPrices', arr: f.priceModel && f.priceModel.currentPrices, kind: 'current' },
      { path: 'priceModel.currentPricesWithOnePiece', arr: f.priceModel && f.priceModel.currentPricesWithOnePiece, kind: 'current' },
      { path: 'priceModel.originalPrices', arr: f.priceModel && f.priceModel.originalPrices, kind: 'original' },
      { path: 'finalPriceModel.tradeWithoutPromotion.offerPriceRanges', arr: twp.offerPriceRanges, kind: 'original' },
      { path: 'originalPricesWithoutPromotion', arr: f.originalPricesWithoutPromotion, kind: 'original' },
    ];
    const out = [];
    for (const b of buckets) {
      if (!Array.isArray(b.arr)) continue;
      b.arr.forEach((p) => {
        const price = num(p.price != null ? p.price : p.discountPrice);
        // 0 价、负价、缺价一律不算档位：库里宁可阶梯为空并写明没采到，也绝不出现「¥0 起」的假档位
        if (price == null || !(price > 0)) return;
        if (out.some((x) => x.price === price && x.beginAmount === num(p.beginAmount) && x.kind === b.kind)) return;
        out.push({
          price,
          beginAmount: num(p.beginAmount),
          endAmount: p.endAmount != null ? num(p.endAmount) : (p.endingAmount != null ? num(p.endingAmount) : null),
          kind: b.kind,
          from: b.path,
        });
      });
    }
    // 按起订量升序，第一档就是「按起订量买」的价（页面数组顺序不可信）
    out.sort((a, b) => (a.beginAmount == null ? 0 : a.beginAmount) - (b.beginAmount == null ? 0 : b.beginAmount));
    return out.length ? out.slice(0, 12) : null;
  }

  /**
   * 阶梯探针：页面上真实存在哪些价格数组、每个数组第一条的字段名到底是什么。
   * 只读结构、限深度限条数，绝不整包回传（体积红线）。阶梯没采到时，靠这个看真相而不是改代码猜。
   */
  function ladderProbe(priceFields) {
    try {
      const f = priceFields || {};
      const twp = (f.finalPriceModel && f.finalPriceModel.tradeWithoutPromotion) || {};
      const pm = (f.priceModel && typeof f.priceModel === 'object') ? f.priceModel : {};
      const scan = (obj, prefix) => (obj && typeof obj === 'object' ? Object.keys(obj) : [])
        .map((k) => ({ key: prefix + k, value: obj[k] }))
        .filter((x) => Array.isArray(x.value) && x.value.length)
        .slice(0, 12)
        .map((x) => ({
          path: x.key.slice(0, 70),
          length: Math.min(x.value.length, 999),
          firstRowKeys: (x.value[0] && typeof x.value[0] === 'object')
            ? Object.keys(x.value[0]).slice(0, 14).map((s) => String(s).slice(0, 30))
            : [typeof x.value[0]],
        }));
      return {
        priceModelArrays: scan(pm, 'priceModel.'),
        tradeWithoutPromotionArrays: scan(twp, 'finalPriceModel.tradeWithoutPromotion.'),
        mainPriceArrays: scan(Object.fromEntries(Object.entries(f).filter(([, v]) => Array.isArray(v))), ''),
        skuTradeSupported: twp.OfferIsSkuTradeSupported === undefined ? null : !!twp.OfferIsSkuTradeSupported,
        priceDisplayType: pm.priceDisplayType ? String(pm.priceDisplayType).slice(0, 40) : null,
      };
    } catch (e) { return null; }
  }


  /** 单 SKU 有没有价，是页面口径，不是我们漏采——把口径写清楚，界面就能诚实说明 */
  function priceNoteOf(priceFields) {
    const f = priceFields || {};
    const twp = (f.finalPriceModel && f.finalPriceModel.tradeWithoutPromotion) || {};
    if (twp.OfferIsSkuTradeSupported === false) return '页面按区间价售卖，未给单个规格的采购价（不是没采到）';
    if (f.priceModel && f.priceModel.priceDisplayType) return '页面价格口径：' + String(f.priceModel.priceDisplayType);
    return null;
  }

  /** 旧版页面兜底：data 的 key 是随机串、值里带 @ali/tdmod-* 模块名（2026-11-09 之前实测的那套） */
  function legacyModules(data) {
    const out = {};
    Object.values(data || {}).forEach((mod) => {
      if (!mod || typeof mod !== 'object') return;
      const name = String(mod.name || mod.moduleName || '');
      if (name.includes('attribute')) out.props = mod;
      else if (name.includes('logistics')) out.logistics = mod;
      else if (name.includes('description')) out.desc = mod;
    });
    return out;
  }

  /** 主入口：window.context → 编辑器要的整页内容文档 */
  function from1688Context(ctx, extra) {
    const result = ctx && ctx.result ? ctx.result : null;
    const data = result && result.data ? result.data : null;
    if (!data || typeof data !== 'object') return null;
    const title = fieldsOf(data.productTitle);
    const gallery = fieldsOf(data.gallery);
    const price = fieldsOf(data.mainPrice);
    const desc = fieldsOf(data.description);
    const pack = fieldsOf(data.productPackInfo);
    const ship = fieldsOf(data.shippingServices);
    const warn = fieldsOf(data.productWarning);
    const skus = skusFromPrice(price);
    const props = flattenCpv(gallery.CpvEnhance);
    const packInfo = Array.isArray(pack.pieceWeightScale && pack.pieceWeightScale.pieceWeightScaleInfo) ? pack.pieceWeightScale.pieceWeightScaleInfo[0] : null;

    // 规格名：CpvEnhance 里 name==="规格" 的那条就是 SKU 规格选项（实测与 skuMapOriginal 一致）
    const specProp = props.find((p) => /规格|颜色|尺码/.test(p.name));
    const skuProps = specProp ? [{ name: specProp.name, values: specProp.values.slice(0, 40) }] : (skus.length ? [{ name: '规格', values: skus.map((s) => s.spec).filter(Boolean).slice(0, 40) }] : []);

    const sellerName = clean(title.shopInfo && (title.shopInfo.authCompanyName || title.shopInfo.companyName)) || null;
    const offerId = clean((extra && extra.offerId) || (gallery.offerId) || (result.global && result.global.offerId)) || null;

    const doc = {
      host: '1688',
      layout: 'context-modules',
      source: 'window.context（页面注水数据，实测 ' + Object.keys(data).length + ' 个模块）',
      offerId,
      title: clean(title.title) || null,
      seller: sellerName,
      saleNum: num(title.saleNum),
      // 主图组：gallery.offerImgList 优先，mainImage 兜底（实测两种都存在）
      images: urls(gallery.offerImgList && gallery.offerImgList.length ? gallery.offerImgList : gallery.mainImage, 30),
      video: gallery.video && (gallery.video.videoUrl || gallery.video.videoId)
        ? { url: clean(gallery.video.videoUrl) || null, cover: clean(gallery.video.coverUrl) || null, title: clean(gallery.video.title) || null, videoId: String(gallery.video.videoId || '') }
        : null,
      // 类目：只拿到叶子类目 ID（实测 122110003）。1688 页面没给中文类目名 → 如实 null，不编名字
      categoryId: desc.leafCategoryId != null ? String(desc.leafCategoryId) : null,
      /* 官方类目 ID：叶子 + 一级都存（实测 Root.fields.dataJson.tempModel 里有 topCategoryId/postCategoryId）。
         1688 页面不给类目中文名，名称必须走官方类目接口，这里绝不自己编一个名字。 */
      topCategoryId: (() => { try { return String(JSON.parse(data.Root.fields.dataJson).tempModel.topCategoryId) || null; } catch (e) { return null; } })(),
      categorySource: '1688 官方类目 ID（页面注水数据）；类目名称需 1688 开放平台类目接口，未配置 AppKey 时留空不编',
      category: null,
      props,
      skuProps,
      skus,
      /* 价格阶梯：实测两种形态都要吃——
         currentPrices（有单 SKU 价的 offer）与 currentPricesWithOnePiece + offerPriceRanges
         （区间价 offer，本例 28.80，SKU 级页面根本没给价）。
         每一档带 from（页面真实键路径）；probe 记录页面实际给了哪些价格数组和字段名，
         采不到时看 probe，不许靠改代码猜（2026-11-11 定口径）。 */
      priceRange: priceLadder(price),
      priceRangeProbe: ladderProbe(price),
      priceNote: priceNoteOf(price),
      weight: {
        kg: num(pack.unitWeight),
        gram: packInfo ? num(packInfo.weight) : null,
        lengthCm: packInfo ? num(packInfo.length) : null,
        widthCm: packInfo ? num(packInfo.width) : null,
        heightCm: packInfo ? num(packInfo.height) : null,
        source: 'productPackInfo（页面件重尺模块）',
      },
      logistics: ship && (ship.postFeeValue != null || ship.logistics != null) ? {
        postFee: num(ship.postFeeValue),
        minWeight: num(ship.minWeight),
        official: ship.officialLogistics == null ? null : !!ship.officialLogistics,
        note: clean(ship.text || ship.deliveryLimitText).slice(0, 200) || null,
        source: 'shippingServices（页面物流发货模块）',
      } : null,
      // 详情描述：offer_details.content 是页面内联的那段 HTML（实测两种形态都要剥 JS 外壳）；
      // description.detailUrl 是天猫 CDN 上的完整版，异步补抓，抓不到就只留内联这段，不编。
      descriptionHtml: cleanDescriptionHtml(extra && extra.offerDetails && extra.offerDetails.content),
      detailUrl: clean(desc.detailUrl) || null,
      // 认证/说明书：页面是空数组就如实空，绝不出「有认证」的假象
      certifications: Array.isArray(warn.officialDocInfos) ? warn.officialDocInfos.slice(0, 20).map((d) => ({ name: clean(d && (d.name || d.title || d.docName)), url: clean(d && (d.url || d.link)) || null })) : [],
      cautionText: clean(warn.cautionText) || null,
      capturedAt: new Date().toISOString(),
    };

    // 旧版页面兜底：属性/描述模块在 @ali/tdmod-* 里
    if (!doc.props.length || !doc.descriptionHtml) {
      const legacy = legacyModules(data);
      if (!doc.props.length && legacy.props) {
        const lp = Array.isArray(legacy.props.value && legacy.props.value.props) ? legacy.props.value.props : (Array.isArray(legacy.props.props) ? legacy.props.props : []);
        doc.props = lp.slice(0, 80).map((p) => ({ name: clean(p.name || p.prop || p.key), values: [clean(p.value || p.text || p.val)].filter(Boolean) })).filter((p) => p.name);
        if (doc.props.length) doc.layout = 'context-modules+legacy-props';
      }
      if (!doc.descriptionHtml && legacy.desc) {
        const html = String((legacy.desc.value && (legacy.desc.value.html || legacy.desc.value.content)) || '');
        if (html) doc.descriptionHtml = html.slice(0, 200000);
      }
    }
    return doc;
  }

  /** 这页到底是不是新版（有 result.data 且带模块 fields） */
  function looksLike1688Context(ctx) {
    try {
      const data = ctx && ctx.result && ctx.result.data;
      if (!data || typeof data !== 'object') return false;
      const keys = Object.keys(data);
      if (!keys.length) return false;
      return keys.some((k) => {
        const f = fieldsOf(data[k]);
        return f && (f.uiType || f.title || f.offerImgList || f.leafCategoryId);
      });
    } catch (e) { return false; }
  }

  /** 有没有真内容：给采集/同步两端判断「能不能当成整页底稿」用——空壳绝不当 DOC */
  function isRealDoc(doc) {
    if (!doc || typeof doc !== 'object') return false;
    return !!doc.title && ((doc.images && doc.images.length > 0) || (doc.skus && doc.skus.length > 0) || (doc.props && doc.props.length > 0) || !!doc.descriptionHtml);
  }

  const MS_NORMALIZE = { from1688Context, looksLike1688Context, isRealDoc, skusFromPrice, flattenCpv, priceLadder, ladderProbe };
  root.MS_NORMALIZE = MS_NORMALIZE;
  if (typeof module !== 'undefined' && module.exports) module.exports = MS_NORMALIZE;
})(typeof window !== 'undefined' ? window : globalThis);
