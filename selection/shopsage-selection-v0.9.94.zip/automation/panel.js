/* automation/panel.js — 注入 1688/拼多多 的「自动化」浮窗。可拖拽 / 缩放 / 最小化 / 最大化 / 关闭(留圆钮)。
 * 面板只是「遥控器+状态窗」：真正持续跑的循环在插件的 automation.html 控制页里，二者用消息互通。
 *   面板→控制页: chrome.runtime.sendMessage({type:'SS_AUTO_CTRL', action, cfg})
 *   控制页→面板: chrome.tabs.sendMessage 到本 1688 页 {type:'SS_AUTO_CONFIRM_REQ', items}（发布确认闸）
 * 发布确认只在面板里弹（不弹原生 confirm），控制页是隐藏后台 tab。 */
(() => {
  if (window.__ssAutoPanelBound) return;
  window.__ssAutoPanelBound = true;

  const KEY = "msAutoPanelUI";
  let el = null, panelEl = null, minimized = false, closed = false, lastCfg = {};

  const MARKETS = [["TH","泰国 THB"],["MY","马来 MYR"],["SG","新加坡 SGD"],["VN","越南 VND"],["PH","菲律宾 PHP"],["ID","印尼 IDR"]];

  function build() {
    const p = document.createElement("div");
    p.className = "ss-auto-panel";
    // logo 必须用 web_accessible 的小图（342KB 原图既重、又没在 WAR 白名单里 → 之前显示成碎图）
    const LOGO = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL) ? chrome.runtime.getURL("assets/shopsage-icon-64.png") : "";
    p.innerHTML = `
      <div class="ss-auto-hd">
        <span class="ss-auto-logo"><img src="${LOGO}" alt="ShopSage"></span>
        <span class="ttl">ShopSage 自动化</span>
        <button type="button" data-k="min" title="缩小/展开">–</button>
      </div>
      <div class="ss-auto-body">
        <div class="ss-auto-grid2">
          <div class="ss-auto-row"><label>项目 / 店铺</label><select class="shop"><option value="">加载中…</option></select></div>
          <div class="ss-auto-row"><label>目标市场</label><select class="market">${MARKETS.map(m=>`<option value="${m[0]}">${m[1]}</option>`).join("")}</select></div>
        </div>
        <div class="ss-auto-row"><label>类目关键词（一行/逗号一个，循环轮换）</label><textarea class="kw" placeholder="phone case&#10;宠物玩具"></textarea></div>
        <div class="ss-auto-grid2">
          <div class="ss-auto-row"><label>本次总目标数（跑够自动停）</label><input class="batch" type="number" min="1" max="200" value="20"></div>
          <div class="ss-auto-row"><label>间隔(ms)</label><input class="delay" type="number" min="1500" step="500" value="6000"></div>
        </div>
        <div class="ss-auto-grid2">
          <div class="ss-auto-row"><label>目标毛利率%</label><input class="margin" type="number" min="0" max="80" step="1" value="30"></div>
          <div class="ss-auto-row"><label>售价浮动%</label><input class="float" type="number" min="-50" max="200" step="5" value="0"></div>
        </div>
        <div class="ss-auto-grid2">
          <div class="ss-auto-row"><label>活动折扣%（标价=折后价÷(1−折扣)）</label><input class="discount" type="number" min="0" max="90" step="5" value="0"></div>
          <div class="ss-auto-row"><label class="muted" style="align-self:end">逐 SKU 各自套毛利反推，慢但准</label></div>
        </div>
        <div class="ss-auto-row"><label class="muted"><input class="draft" type="checkbox" checked style="width:auto;margin-right:6px">发布只建草稿 · 不送审（推荐）</label></div>
        <div class="ss-auto-row"><label class="muted"><input class="handsoff" type="checkbox" style="width:auto;margin-right:6px">发布免逐批确认（仅测试店）</label></div>
        <details class="ss-auto-row"><summary class="muted">发布默认设置（每店配一次 · 自动预填用）</summary>
          <div class="ss-auto-grid2" style="margin-top:6px">
            <div class="ss-auto-row"><label>库存默认</label><input class="pdStock" type="number" min="1" value="100"></div>
            <div class="ss-auto-row"><label>重量kg</label><input class="pdWeight" type="number" min="0" step="0.1" value="0.5"></div>
          </div>
          <div class="ss-auto-grid2">
            <div class="ss-auto-row"><label>长cm</label><input class="pdL" type="number" min="1" value="20"></div>
            <div class="ss-auto-row"><label>宽cm</label><input class="pdW" type="number" min="1" value="15"></div>
            <div class="ss-auto-row"><label>高cm</label><input class="pdH" type="number" min="1" value="10"></div>
          </div>
          <div class="ss-auto-row"><input class="pdBrand" type="text" placeholder="品牌（留空＝无品牌）" style="width:100%"></div>
          <button type="button" class="pdSave">保存发布默认</button>
        </details>
        <div class="ss-auto-acts">
          <button type="button" class="start primary">开始持续跑</button>
          <button type="button" class="pause">暂停</button>
          <button type="button" class="stop">停止</button>
          <button type="button" class="pubExisting">信息填好存后台(不发布)</button>
        </div>
        <div class="ss-auto-stat">轮次 0 · 已采 0 · 已同步 0 · 已发布 0</div>
        <div class="ss-auto-log"></div>
      </div>
      <div class="ss-auto-resize"></div>`;
    document.documentElement.appendChild(p);
    panelEl = p;
    el = (c) => p.querySelector(c);
    wireUI();
    restoreGeom();
    pollShops();
  }

  function wireUI() {
    // 拖拽
    const hd = el(".ss-auto-hd");
    hd.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      const r = panelEl.getBoundingClientRect(); const dx = e.clientX - r.left, dy = e.clientY - r.top;
      const mv = (ev) => { const rr = panelEl.getBoundingClientRect(); panelEl.style.left = Math.max(4, Math.min(ev.clientX - dx, window.innerWidth - rr.width - 6)) + "px"; panelEl.style.top = Math.max(4, Math.min(ev.clientY - dy, window.innerHeight - rr.height - 6)) + "px"; panelEl.style.bottom = "auto"; };
      const up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); saveGeom(); };
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); e.preventDefault();
    });
    // 缩放
    el(".ss-auto-resize").addEventListener("mousedown", (e) => {
      const r = panelEl.getBoundingClientRect(); const sx = e.clientX, sy = e.clientY, w = r.width, h = r.height;
      const mv = (ev) => { panelEl.style.width = Math.max(260, w + ev.clientX - sx) + "px"; panelEl.style.height = Math.max(150, h + ev.clientY - sy) + "px"; };
      const up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); saveGeom(); };
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); e.preventDefault(); e.stopPropagation();
    });
    // 头按钮
    hd.addEventListener("click", (e) => {
      const k = e.target.getAttribute("data-k");
      // 缩小 = 直接收成右下角一个小圆钮（不是小窗口）；点小球再展开
      if (k === "min") { panelEl.style.display = "none"; showLauncher(); saveGeom(); }
    });
    // 操作
    el(".start").onclick = () => { startLoop(true); };
    el(".pause").onclick = () => ctrl({ action: "pause" });
    el(".stop").onclick = () => ctrl({ action: "stop" });
    const pe = el(".pubExisting"); if (pe) pe.onclick = () => { const c = cfg(); ctrl({ action: "publishExisting", cfg: c }, (r) => { if (r && r.ok) log("已触发：把待评估信息填好存到官网后台（不自动发布，去采集箱逐个点「发布」上架）", "ok"); }); if (!window.__ssAutoPoll) window.__ssAutoPoll = setInterval(refreshStatus, 1500); };
    // 发布默认设置（店铺层A）：按当前店铺键存 chrome.storage，供 publishOne 自动预填
    const pdSave = el(".pdSave");
    if (pdSave) pdSave.onclick = () => {
      const shop = el(".shop").value || "_";
      const d = { stockQty: Number(el(".pdStock").value)||100, weightKg: Number(el(".pdWeight").value)||0.5, dims:{ l:Number(el(".pdL").value)||20, w:Number(el(".pdW").value)||15, h:Number(el(".pdH").value)||10 }, brand: (el(".pdBrand").value||"").trim() };
      try { chrome.storage.local.set({ ["ssAutoPubDefaults:"+shop]: d }, () => { log("发布默认已保存（店铺 "+String(shop).slice(0,8)+"）"); }); } catch(e){ log("保存发布默认失败："+e.message); }
    };
    const loadPd = () => { const shop=el(".shop").value||"_"; try{ chrome.storage.local.get("ssAutoPubDefaults:"+shop,(s)=>{ const d=s&&s["ssAutoPubDefaults:"+shop]; if(d){ if(el(".pdStock"))el(".pdStock").value=d.stockQty||100; if(el(".pdWeight"))el(".pdWeight").value=d.weightKg||0.5; if(el(".pdL"))el(".pdL").value=(d.dims&&d.dims.l)||20; if(el(".pdW"))el(".pdW").value=(d.dims&&d.dims.w)||15; if(el(".pdH"))el(".pdH").value=(d.dims&&d.dims.h)||10; if(el(".pdBrand"))el(".pdBrand").value=d.brand||""; } }); }catch(e){} };
    loadPd();
    const shopSel = el(".shop"); if (shopSel) shopSel.addEventListener("change", loadPd);
  }

  function cfg() { return { keywords: el(".kw").value.split(/[,\n;]+/).map(s=>s.trim()).filter(Boolean), shop: el(".shop").value, market: el(".market").value, totalTarget: Number(el(".batch").value)||20, batchSize: Number(el(".batch").value)||20, delay: Number(el(".delay").value)||6000, handsOff: el(".handsoff").checked, draftOnly: el(".draft") ? el(".draft").checked : true, targetMarginPct: Number(el(".margin").value), floatPct: Number(el(".float").value)||0, discountPct: Number(el(".discount").value)||0 }; }

  // 控制页是「隐藏 tab」，刚创建时它的 onMessage 监听还没注册；
  // 冷启动必须 ping 到通为止，否则首次 shops/start 会石沉大海（店铺一直「加载中…」的真因）。
  let ctrlReady = false;
  function rawSend(msg) {
    return new Promise((res) => {
      try { chrome.runtime.sendMessage(Object.assign({ type: "SS_AUTO_CTRL" }, msg), (r) => {
        res(chrome.runtime.lastError ? { ok: false, conn: chrome.runtime.lastError.message } : (r || { ok: false }));
      }); } catch (e) { res({ ok: false, conn: String(e) }); }
    });
  }
  function ensureController(then) {
    try {
      chrome.runtime.sendMessage({ type: "SS_AUTO_OPEN_CTRL" }, (r) => {
        if (chrome.runtime.lastError) { log("控制器打不开：" + chrome.runtime.lastError.message); return then && then(false); }
        then && then(!!(r && r.ok));
      });
    } catch (e) {
      // 扩展刚被更新/重载，本页残留的是旧脚本 → 上下文失效。优雅提示，不抛未捕获异常。
      log("扩展已更新，请刷新本页面后重试");
      then && then(false);
    }
  }
  async function waitController(trials) {
    if (ctrlReady) return true;
    for (let i = 0; i < (trials || 20); i++) {
      const p = await rawSend({ action: "ping" });
      if (p && p.ok) { ctrlReady = true; return true; }
      if (p && p.conn) await ensureController();
      await new Promise((r) => setTimeout(r, 700));
    }
    return false;
  }
  async function ctrl(msg, then) {
    const ready = await waitController();
    if (!ready) { log("控制器无响应（自动化控制页未就绪）"); return then && then({ ok: false, error: "ctrl-not-ready" }); }
    const r = await rawSend(msg);
    if (r && r.conn) { ctrlReady = false; log("控制器掉线，下轮自动重连"); }
    then && then(r);
  }

  function startLoop() {
    const c = cfg(); lastCfg = c;
    if (!c.keywords.length) return log("先填类目关键词");
    ctrl({ action: "start", cfg: c }, (r) => { if (r && r.ok) log("已发开始，持续跑中…"); else log("启动失败：" + ((r&&r.error)||"")); });
    if (!window.__ssAutoPoll) window.__ssAutoPoll = setInterval(refreshStatus, 1500);
  }
  function refreshStatus() { ctrl({ action: "status" }, (r) => { if (r && r.data) renderStatus(r.data); }); }

  function renderStatus(d) {
    el(".ss-auto-stat").textContent = `轮次 ${d.cycle||0} · 已采 ${d.nCollect||0} · 已同步 ${d.nSync||0} · 已发布 ${d.nPublish||0} · ${d.running ? "跑动中" : d.paused ? "已暂停" : "空闲"}${d.email ? ` · ${d.email}` : (d.hasSession ? " · 正在识别账号…" : " · 未登录")}`;
    if (d.log) { const lg = el(".ss-auto-log"); lg.textContent = d.log; lg.scrollTop = lg.scrollHeight; }
  }
  function log(m) { const lg = el(".ss-auto-log"); if(!lg) return; lg.textContent = `[${new Date().toLocaleTimeString()}] ${m}\n` + lg.textContent; }

  // 店铺：直接问 service worker（SS_PURCHASE_API op:shops），不拉起 automation.html 控制页
  async function pollShops(tries) {
    const sel = el(".shop");
    for (let i = 0; i < (tries || 8); i++) {
      const r = await new Promise((res) => { try { chrome.runtime.sendMessage({ type: "SS_PURCHASE_API", op: "shops" }, (resp) => res(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : (resp || { ok: false }))); } catch (e) { res({ ok: false, error: String(e) }); } });
      if (r && r.ok) {
        const d = r.data; const arr = Array.isArray(d) ? d : ((d && (d.shops || d.data || d.items || d.list)) || []);
        const raw = Array.isArray(arr) ? arr : [];
        const platOf = (s) => String(s.platform || s.shopPlatform || s.type || s.shopType || s.channel || s.provider || s.marketplace || '').toLowerCase();
        const all = raw.map((s, i2) => ({ id: String(s.id || s.shopId || s.shopCode || ("shop" + i2)), name: String(s.name || s.shopName || s.title || s.storeName || ("店铺" + (i2 + 1))), plat: platOf(s) }));
        // 诊断：把每个店铺识别到的平台打进面板日志，重载后读一次即可验证过滤选对店铺
        log('店铺平台识别：' + (all.length ? all.map(s => s.name + '=' + (s.plat || '?')).join(' , ') : '无'));
        const anyPlatKnown = all.some(s => s.plat);
        // A：发布链路只支持 TikTok Shop → 只列 TikTok；识别不到平台字段时退回全显示（绝不因猜错字段把 TikTok 也藏了）
        const shops = anyPlatKnown ? all.filter(s => /tiktok/.test(s.plat)) : all;
        if (all.length && anyPlatKnown && !shops.length) { sel.innerHTML = '<option value="">（账号下没有 TikTok Shop 店铺）</option>'; log('无 TikTok 店铺：发布链路只支持 TikTok Shop'); return; }
        if (shops.length) { sel.innerHTML = shops.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}${anyPlatKnown ? '' : '（未识别平台）'}</option>`).join(""); log((anyPlatKnown ? 'TikTok 店铺 ' : '店铺（未识别平台，全显示）') + shops.length + ' 个已载入'); }
        else sel.innerHTML = '<option value="">（账号下没有店铺）</option>';
        return;
      }
      sel.innerHTML = '<option value="">加载中…</option>';
      if (i === 3 || i === (tries || 8) - 1) log("店铺载入中/失败：" + String((r && r.error) || "无响应").slice(0, 90));
      await new Promise((x) => setTimeout(x, 1500));
    }
    sel.innerHTML = '<option value="">（店铺取不到，见日志）</option>';
  }

  // 发布确认：控制页 chrome.tabs.sendMessage 打到本 1688 页 → 这里弹面板内确认，返回 sendResponse
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "SS_AUTO_CONFIRM_REQ" && !closed) {
      const items = msg.items || [];
      const box = document.createElement("div"); box.className = "ss-auto-confirm";
      box.innerHTML = `<div class="box"><h4>放行这批发布到 TikTok？</h4>
        <div>${items.slice(0,8).map(p=>`· ${esc(p.title||"")}`).join("<br>")}</div>
        <div class="muted" style="font-size:11px;margin-top:6px">共 ${items.length} 条 · 市场 ${esc(msg.market||"")}</div>
        <div class="row"><button type="button" class="no">取消</button><button type="button" class="primary yes">确认发布</button></div></div>`;
      panelEl.appendChild(box);
      const decide = (v) => { box.remove(); sendResponse({ ok: v }); };
      box.querySelector(".yes").onclick = () => decide(true);
      box.querySelector(".no").onclick = () => decide(false);
      return true;
    }
  });

  function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}

  function showLauncher() { if (document.querySelector(".ss-auto-launcher")) return; const b = document.createElement("button"); b.className = "ss-auto-launcher"; b.textContent = "⚙"; b.title = "打开自动化"; b.onclick = () => { closed=false; panelEl.style.display=""; b.remove(); saveGeom(); }; document.documentElement.appendChild(b); }

  function saveGeom(){ try{ const r=panelEl.getBoundingClientRect(); chrome.storage.local.set({[KEY]:{left:panelEl.style.left,top:panelEl.style.top,width:panelEl.style.width,height:panelEl.style.height,big:panelEl.dataset.big,min:(panelEl.style.display==='none')}}); }catch(e){} }
  function restoreGeom(){ chrome.storage.local.get(KEY,(s)=>{ const g=s && s[KEY]; if(g&&g.left){ if(g.width)panelEl.style.width=g.width; if(g.height)panelEl.style.height=g.height; if(g.big)panelEl.dataset.big=g.big; clampIntoView(parseFloat(g.left)||4, parseFloat(g.top)||4); } if(!g || g.min!==false){ panelEl.style.display="none"; showLauncher(); } }); }
  // 把面板左上角钳制进当前视口，避免历史位置或窗口变小把它甩到屏幕外（用户反馈“跑到页面出去”）
  function clampIntoView(left, top){
    const r = panelEl.getBoundingClientRect(); const w = r.width || (parseFloat(panelEl.style.width)||340); const h = r.height || (parseFloat(panelEl.style.height)||460);
    const L = Math.max(4, Math.min(left, Math.max(4, window.innerWidth - w - 6)));
    const T = Math.max(4, Math.min(top, Math.max(4, window.innerHeight - h - 6)));
    panelEl.style.left = L + "px"; panelEl.style.top = T + "px"; panelEl.style.bottom = "auto"; panelEl.style.right = "auto";
  }
  try { window.addEventListener("resize", () => { const r = panelEl && panelEl.getBoundingClientRect(); if (r) clampIntoView(r.left, r.top); }); } catch (e) {}

  build();
})();
