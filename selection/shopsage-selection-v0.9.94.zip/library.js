const $ = id => document.getElementById(id);
let products = [], selectedId = null;
const selected = () => products.find(item => item.id === selectedId);
function status(message, error = false) { $('status').textContent = message; $('status').className = `status ${error ? 'error' : 'success'}`; }

/** 当前账号的桶键与未归属条数（2026-11-13 账号分区，老板 #1） */
let storeKey = '';
let unassignedCount = 0;

async function load() {
  const store = await window.MSStore.readAll();
  storeKey = store.key;
  unassignedCount = Array.isArray(store.unassigned) ? store.unassigned.length : 0;
  products = Array.isArray(store.mine) ? store.mine : [];
  if (!selected() && products.length) selectedId = products[0].id;
  render();
}

function render() {
  $('count').textContent = `${products.length} 个商品`;
  const root = $('items');
  root.replaceChildren();
  if (!products.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = '选品库为空。打开 1688 或拼多多商品列表，点击卡片上的“采集商品”。';
    root.appendChild(empty);
  }
  for (const item of products) {
    const card = document.createElement('article');
    card.className = `item ${item.id === selectedId ? 'active' : ''}`;
    card.tabIndex = 0;

    const image = document.createElement('img');
    image.src = item.content?.images?.[0] || item.image || '';
    image.alt = item.title || '商品图片';
    // 1688/拼多多的图床有防盗链：非本站 Referer 一律 403。插件页发请求不带 Referer 就能过
    //（2026-11-09 用线上真实商品 URL 实测：no-referer 200，shopsage.cc referer 403）。
    image.referrerPolicy = 'no-referrer';
    image.addEventListener('error', () => { image.style.visibility = 'hidden'; });

    const body = document.createElement('div'); body.className = 'item-body';
    const title = document.createElement('div'); title.className = 'item-title'; title.textContent = item.title || '未识别标题';

    /* 排版：第一行 平台徽章 + 销量；第二行 价格（大）+ 页面可见价提示。
       之前平台/价格/销量挤一行，窄卡上变成「拼多多¥78.98本店已拼1.4万」糊成一团。 */
    const meta = document.createElement('div'); meta.className = 'item-meta';
    const line1 = document.createElement('div'); line1.className = 'item-line';
    const plat = document.createElement('span'); plat.className = 'item-plat';
    plat.textContent = item.platform || '未知平台';
    line1.appendChild(plat);
    if (item.salesTip) {
      const sales = document.createElement('span'); sales.className = 'item-sales'; sales.textContent = item.salesTip;
      line1.appendChild(sales);
    }
    const line2 = document.createElement('div'); line2.className = 'item-line';
    const price = document.createElement('span'); price.className = 'item-price';
    price.textContent = item.price ? `¥${Number(item.price).toFixed(2)}` : '价格待核对';
    line2.appendChild(price);
    if (item.visiblePrice != null && item.price != null && Math.abs(Number(item.visiblePrice) - Number(item.price)) > 0.01) {
      const vp = document.createElement('span'); vp.className = 'item-visible';
      vp.textContent = `页面显示 ¥${Number(item.visiblePrice).toFixed(2)}`;
      line2.appendChild(vp);
    } else if (item.priceNeedsReview) {
      const rn = document.createElement('span'); rn.className = 'item-visible'; rn.textContent = '价格待核对';
      line2.appendChild(rn);
    }
    meta.append(line1, line2);
    body.append(title, meta);

    const actions = document.createElement('div'); actions.className = 'item-actions';
    const link = document.createElement('a');
    if (item.url && /^https?:\/\//i.test(String(item.url).trim())) { link.href = String(item.url).trim(); link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '查看原商品'; }
    else { link.textContent = '原链接缺失'; link.className = 'is-disabled'; }
    const remove = document.createElement('button');
    remove.textContent = '移除';
    remove.onclick = async event => {
      event.stopPropagation();
      products = products.filter(p => p.id !== item.id);
      await window.MSStore.writeBucket(storeKey, products);
      if (selectedId === item.id) selectedId = products[0]?.id || null;
      render();
    };
    actions.append(link, remove);
    card.append(image, body, actions);
    card.onclick = () => { selectedId = item.id; render(); };
    card.onkeydown = e => { if (e.key === 'Enter') { selectedId = item.id; render(); } };
    root.appendChild(card);
  }

  const item = selected();
  $('selectedName').textContent = item?.title || '请从左侧选择商品';
  $('purchasePrice').value = item?.price ?? '';
  // 精准重量预填（老板 #2）：采集读到的重量自动填入，没有就留空让用户手填，不再用 0-1kg 区间。
  if ($('weightG')) {
    const wg = item?.weight;
    const grams = wg ? (wg.gram != null ? Number(wg.gram) : (wg.kg != null ? Math.round(Number(wg.kg) * 1000) : null)) : null;
    $('weightG').value = grams != null && grams > 0 ? grams : '';
  }

  const note = $('captureNote');
  if (note) {
    note.textContent = item ? `${item.capturePath ? '采集路径：' + item.capturePath + ' · ' : ''}${item.priceSource || '价格来源未记录'}${item.priceNeedsReview ? ' · 请核对采购价' : ''}` : '';
    note.className = 'price-note' + (item?.priceNeedsReview ? ' warn' : '');
  }
  window.MSMarket?.refresh(true);
}

/**
 * 同步/分析前的归属闸门：条目是哪个账号采的，就只能由那个账号同步。
 * 老数据没有归属（0.9.12 之前采的）→ 允许同步，但如实提示建议重采补归属，不拦死。
 * 返回 { ok, message }；message 只在拒绝时有值。
 */
async function ownerCheckBeforeSync(item) {
  const nowEmail = window.SSAuth && window.SSAuth.currentEmail ? await window.SSAuth.currentEmail() : '';
  const g = window.SSAuth.ownerGuard(item && item.ownerEmail, nowEmail);
  // 没归属的旧数据一律拦下（以前放行，等于换账号还能把上一个账号的采到箱里写一遍）
  if (!g.ok && g.reason === 'unowned') {
    return { ok: false, message: '这条是旧版插件采的、没记归属账号，不能同步进任何账号的采集箱；请切回原页面重新采集一次（登录后采的会自动带上归属）。' };
  }
  if (!g.ok && g.reason === 'not_logged_in') return { ok: false, message: '还没登录 ShopSage：请先用官网账号登录。' };
  if (!g.ok) return { ok: false, message: '这条商品是在另一个账号（' + g.owner + '）下采集的，不会传进当前账号的采集箱——要同步请切回原账号。' };
  return { ok: true };
}

function payload() {
  const item = selected();
  if (!item) throw Error('请先采集并选择商品。');
  const price = Number($('purchasePrice').value);
  if (!(price > 0)) throw Error('请核对并填写采购价。');
  return {
    product: { ...item, price, currency: 'CNY' },
    market: window.MSMarket.requestMarket(),
    costs: window.MSMarket.requestCosts()
  };
}

// 商品详情可能包含数百个 SKU 和很长的 HTML；控制体积，避免触发 API 默认 JSON body 上限。
function compactContent(c) {
  if (!c || typeof c !== 'object' || c.__msDiag) return null;
  const list = (v, n) => Array.isArray(v) ? v.slice(0, n) : [];
  const rows = (v, n, sku) => list(v, n).map(x => {
    if (!x || typeof x !== 'object') return { value: String(x || '').slice(0, 300) };
    return sku
      ? { skuId: String(x.skuId || '').slice(0, 80), spec: String(x.spec || x.specsText || '').slice(0, 300), price: x.price ?? null, stock: x.stock ?? x.quantity ?? null }
      : { pid: String(x.pid || '').slice(0, 80), name: String(x.name || x.prop || x.label || x.key || '').slice(0, 160), value: String(x.value || x.text || '').slice(0, 500), values: list(x.values, 20).map(y => typeof y === 'object' ? { vid: y.vid, name: String(y.name || y.value || '').slice(0, 120) } : String(y).slice(0, 120)) };
  });
  /* 阶梯价：2026-11-11 生产实测的根因就在这份白名单里 —— 页面阶梯明明采到了
     （库里 priceNote=「页面价格阶梯（window.context 官方数据）」就是这个函数写进去的价带来的），
     但白名单没带 priceRange，整段在上传环节被丢掉，后端永远读到 null，
     利润只能拿「全部 SKU 里最低价」当成本。这里补上档位与探针，如实传页面给的东西。 */
  const ladder = list(c.priceRange, 12).map(x => (x && typeof x === 'object' && Number(x.price) > 0)
    ? { price: Number(x.price), beginAmount: x.beginAmount ?? null, endAmount: x.endAmount ?? null, from: String(x.from || '').slice(0, 60) } : null).filter(Boolean);
  return {
    priceRange: ladder.length ? ladder : null,
    priceRangeProbe: c.priceRangeProbe && typeof c.priceRangeProbe === 'object' ? c.priceRangeProbe : null,
    priceNote: String(c.priceNote || '').slice(0, 200) || null,
    host: String(c.host || '').slice(0, 20) || null,
    source: String(c.source || '').slice(0, 200) || null,
    saleNum: typeof c.saleNum === 'number' ? c.saleNum : null,
    /* 2026-11-13：拼多多/1688 这次补齐的字段必须一起进这份白名单，否则采到了也会在上传环节被抹掉
       （2026-11-11 的 priceRange 就是这么丢的，同一个坑不许踩第二次）。 */
    saleNumSource: String(c.saleNumSource || '').slice(0, 60) || null,
    commentCount: typeof c.commentCount === 'number' ? c.commentCount : null,
    titleSource: String(c.titleSource || '').slice(0, 60) || null,
    titleProbe: c.titleProbe && typeof c.titleProbe === 'object' ? c.titleProbe : null,
    topCategoryId: c.topCategoryId ? String(c.topCategoryId).slice(0, 40) : null,
    categorySource: String(c.categorySource || '').slice(0, 300) || null,
    detailImages: list(c.detailImages, 30).map(x => String(x || '').slice(0, 700)).filter(Boolean),
    cautionText: String(c.cautionText || '').slice(0, 300) || null,
    title: String(c.title || '').slice(0, 500), seller: String(c.seller || '').slice(0, 300),
    category: String(c.category || '').slice(0, 300),
    categoryId: c.categoryId ? String(c.categoryId).slice(0, 40) : null,
    offerId: c.offerId ? String(c.offerId).slice(0, 40) : null,
    images: list(c.images, 30).map(x => String(x || '').slice(0, 700)).filter(Boolean),
    video: c.video && (c.video.url || c.video.videoId) ? { url: String(c.video.url || '').slice(0, 700) || null, cover: String(c.video.cover || '').slice(0, 700) || null, title: String(c.video.title || '').slice(0, 200) || null, videoId: String(c.video.videoId || '').slice(0, 40) } : null,
    weight: c.weight && (c.weight.kg != null || c.weight.gram != null) ? { kg: c.weight.kg ?? null, gram: c.weight.gram ?? null, lengthCm: c.weight.lengthCm ?? null, widthCm: c.weight.widthCm ?? null, heightCm: c.weight.heightCm ?? null, source: String(c.weight.source || '').slice(0, 120) } : null,
    logistics: c.logistics ? { postFee: c.logistics.postFee ?? null, minWeight: c.logistics.minWeight ?? null, official: c.logistics.official ?? null, note: String(c.logistics.note || '').slice(0, 200) || null, source: String(c.logistics.source || '').slice(0, 120) } : null,
    certifications: list(c.certifications, 20).map(x => ({ name: String((x && x.name) || '').slice(0, 200), url: String((x && x.url) || '').slice(0, 700) })),
    props: rows(c.props, 80, false), skuProps: rows(c.skuProps, 40, false), skus: rows(c.skus, 70, true),
    descriptionHtml: String(c.descriptionHtml || '').slice(0, 16000),
    description: String(c.description || c.visibleText || '').slice(0, 8000),
    detailUrl: c.detailUrl ? String(c.detailUrl).slice(0, 700) : null,
    layout: c.layout ? String(c.layout).slice(0, 60) : null,
    capturedAt: String(c.capturedAt || '').slice(0, 80)
  };
}

/** 诊断包单独回报：后端只写日志、不进底稿列（空壳绝不能冒充「整页内容已采到」）。 */
function compactDiag(c) {
  if (!c || !c.__msDiag) return null;
  const d = c.diag || {};
  return { goodsId: d.goodsId ? String(d.goodsId).slice(0, 40) : null, reason: String(d.error || d.note || 'no_data_packet').slice(0, 160), stage: String(d.stage || 'hook').slice(0, 40), url: String(d.url || '').slice(0, 200), hasContext: !!d.hasContext, contextKeys: Array.isArray(d.contextKeys) ? d.contextKeys.slice(0, 40) : null, ts: d.ts || null };
}

/** 统一的后台请求：带官网签发的 Bearer，实现在 auth.js，与 popup 共用一份。 */
async function backendFetch(path, init) {
  return window.SSAuth.backendFetch(path, init);
}

function failText(e) {
  return window.SSAuth.friendlyError(e && e.message ? e.message : String(e));
}

async function sync() {
  let data;
  try { data = payload(); } catch (e) { return status(e.message, true); }
  const cfg = await chrome.storage.local.get({ accessToken: "" });
  if (!cfg.accessToken) return status("还没登录 ShopSage：请先用官网账号登录。", true);
  const button = $('sync'); button.disabled = true;
  try {
    status('正在同步商品基础信息与已采到的详情…');
    // content 必须放 body 顶层——后端 ExtensionProductPayload.content 读顶层（2026-11-09 生产钉死）
    const product = { ...data.product };
    const rawContent = product.content;
    const contentDiag = compactDiag(rawContent);
    const content = compactContent(rawContent);
    /* 空壳不当 DOC：标题没有、图/SKU/属性/描述全空的包一律不写底稿，只回报诊断 */
    const docIsReal = !!content && !!content.title && (content.images.length || content.skus.length || content.props.length || content.descriptionHtml.length > 40);
    delete product.content;
    delete product.contentStatus;
    const guard = await ownerCheckBeforeSync(data.product);
    if (!guard.ok) return status(guard.message, true);
    const d = await backendFetch('/api/extension/products', {
      method: 'POST',
      body: JSON.stringify({ product, source: data.product.platform, market: data.market, costs: data.costs, content: docIsReal ? content : null, contentDiag })
    });
    status(docIsReal
      ? `已同步到采集箱${d.id ? ` · 编号 ${d.id}` : ''}。整页内容：DOC·${JSON.stringify(content).length}B（图${content.images.length}·规格${content.skus.length}·属性${content.props.length}${content.video ? '·有视频' : ''}），后台「AI商品选品 → 采集箱」可直接编辑后发布。`
      : `已同步基础信息${d.id ? ` · 编号 ${d.id}` : ''}，但这条没有整页内容——打开 1688 详情页点「采集到选品库」再同步即可补齐 SKU/图片/描述。`);
  } catch (e) { status(failText(e), true); }
  finally { button.disabled = false; }
}

async function analyze() {
  let data;
  try { data = payload(); } catch (e) { return status(e.message, true); }
  const cfg = await chrome.storage.local.get({ accessToken: "" });
  if (!cfg.accessToken) return status("AI 分析走 ShopSage 服务端：请先用官网账号登录。", true);
  const button = $('analyze'); button.disabled = true; status('服务端正在分析（按后台点数结算）…');
  try {
    const guard2 = await ownerCheckBeforeSync(data.product);
    if (!guard2.ok) return status(guard2.message, true);
    const synced = await backendFetch('/api/extension/products', {
      method: 'POST',
      body: JSON.stringify({ product: data.product, source: data.product.platform, market: data.market, costs: data.costs })
    });
    const done = await backendFetch('/api/extension/analyze', {
      method: 'POST',
      body: JSON.stringify({ id: synced.id })
    });
    const report = done?.analysisResult?.report || '';
    $('reportText').textContent = report || '分析完成，但服务端没有返回报告内容。';
    $('report').classList.remove('hidden');
    $('report').scrollIntoView({ behavior: 'smooth' });
    status('分析完成 · 报告已存到后台采集箱。');
  } catch (e) { status('分析失败：' + failText(e), true); }
  finally { button.disabled = false; }
}

document.addEventListener('DOMContentLoaded', async () => {
  $('sync').onclick = sync;
  $('analyze').onclick = analyze;
  if ($('msOpenAuto')) $('msOpenAuto').onclick = async () => {
    // 自动化的操作 UI 在 1688 页浮窗里；这里聚焦/打开一个 1688 页即可。
    // 不再开可见的 automation.html —— 它现在是 offscreen 控制页，开两份会双实例抢指令。
    const tabs = await chrome.tabs.query({ url: '*://*.1688.com/*' });
    if (tabs && tabs.length) chrome.tabs.update(tabs[0].id, { active: true });
    else chrome.tabs.create({ url: 'https://www.1688.com/' });
  };
  window.MSMarket.init({});
  /* 登录做到最前端：没登录只见登录框，登录成功才加载选品库 */
  const connected = await window.SSAuth.mountGate({ onConnected: () => { void load(); } });
  if (connected) await load();
});
chrome.storage.onChanged.addListener((changes, area) => { if (area !== 'local' || !changes) return; /* 分桶后键是 products:v1:<邮箱>/__unassigned__，旧的 changes.products 永远不触发 → 采集后列表不刷新；改判任意 products: 前缀 */ if (Object.prototype.hasOwnProperty.call(changes, 'products') || Object.keys(changes).some((k) => k.indexOf('products:') === 0)) load(); });

/* ── 自动化入口（增量 · 复用现成 sync()/MSMarket，不复制费率逻辑）2026-11-23 ──
   供 automation/automation.js 通过 chrome.tabs.sendMessage 驱动：
   把当前账号「已采集未同步」的条目逐条选中 → 设目标市场 → 现成 sync() 进采集箱。
   成功判定读 status 文案（沿用你线上真实措辞「已同步…采集箱」）。 */
const _sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function _setMarketCountry(code) {
  const sel = $('countrySelect');
  if (sel) {
    const opt = [...sel.options].find(o => o.value === code || o.textContent.includes(code));
    if (opt) { sel.value = opt.value; sel.dispatchEvent(new Event('change', { bubbles: true })); return true; }
  }
  const txt = $('country');
  if (txt) { txt.style.display = ''; txt.value = code; txt.dispatchEvent(new Event('input', { bubbles: true })); return true; }
  return false;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  // 只处理本模块消息；SS_AUTO_CTRL 等其它类型绝不 return true，避免吞掉浮窗↔控制页的通道（店铺卡「加载中」的真因）
  if (!(msg.type === 'SS_PING' || msg.type === 'SS_SET_MARKET' || msg.type === 'SS_AUTO_CLAIM' || msg.type === 'SS_AUTO_SYNC')) return;
  (async () => {
    if (!msg) return;
    if (msg.type === 'SS_PING') { sendResponse({ ok: true }); return; }
    if (msg.type === 'SS_SET_MARKET') { sendResponse({ ok: _setMarketCountry(msg.country) }); return; }
    if (msg.type === 'SS_AUTO_CLAIM') {
      /* 2026-11-24 实测根因：未登录时采的条目全落进「未归属桶」，而该桶永不参与同步
         → 用户看到的是「同步一直重复/同步不出去」。这里把它们认领进当前登录账号的桶。
         非破坏式：不删未归属桶，只在原条目上打认领标记，重复执行不会二次认领。 */
      try {
        const st = await window.MSStore.readAll();
        if (!st.email) return sendResponse({ ok: false, error: '未登录官网账号，无法认领' });
        const un = (Array.isArray(st.unassigned) ? st.unassigned : []).filter(x => x && !x.claimedInto);
        if (!un.length) return sendResponse({ ok: true, moved: 0, total: (st.mine || []).length });
        const mine = (st.mine || []).slice();
        const seen = new Set(mine.map(x => x.url));
        const claim = un.filter(x => x.url && !seen.has(x.url))
          .map(x => Object.assign({}, x, { ownerEmail: st.email, ownerStampedAt: new Date().toISOString(), claimedInto: st.key }));
        const merged = mine.concat(claim).slice(0, window.MSStore.MAX_ITEMS || 500);
        await window.MSStore.writeBucket(st.key, merged);
        await window.MSStore.writeBucket(window.MSStore.UNASSIGNED,
          (Array.isArray(st.unassigned) ? st.unassigned : []).map(x => claim.some(c => c.url === x.url) ? Object.assign({}, x, { claimedInto: st.key, claimedAt: new Date().toISOString() }) : x));
        sendResponse({ ok: true, moved: claim.length, total: merged.length });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      return;
    }
    if (msg.type === 'SS_AUTO_SYNC') {
      try {
        const email = window.SSAuth && window.SSAuth.currentEmail ? await window.SSAuth.currentEmail() : '';
        if (!email) return sendResponse({ ok: false, error: '未登录官网账号' });
        await load();                              // 重新读库，拿到 automation 刚采集的新条目
        if (msg.country) _setMarketCountry(msg.country);
        // 只处理这一批（按 url 精确匹配）且未同步过的 → 杜绝反复同步同一批
        const urlSet = Array.isArray(msg.urls) && msg.urls.length ? new Set(msg.urls) : null;
        const skuMax = Number(msg.skuMax) > 0 ? Number(msg.skuMax) : 0;
        const limit = Math.min(Math.max(Number(msg.limit) || 20, 1), 60);
        const targets = urlSet
          ? products.filter(p => urlSet.has(p.url) && !p.syncedToInboxId)
          : products.filter(p => !p.syncedToInboxId).slice(0, limit);
        let synced = 0, failed = 0; const results = [];
        for (const it of targets) {
          selectedId = it.id; render();            // render 回填 purchasePrice/重量
          window.MSMarket.refresh(true); await _sleep(150);
          const mk = window.MSMarket.requestMarket(), cs = window.MSMarket.requestCosts();
          // 目标毛利率反推售价（复用 SS_RULES.suggestPrice），再按浮动%调整 → 写入 targetPrice
          let sell = null;
          if (cs.purchasePrice > 0 && cs.shipping > 0) {
            const base = window.SS_RULES.suggestPrice({
              purchaseCny: cs.purchasePrice, shippingCny: cs.shipping,
              feePct: cs.platformFeeRate, otherPct: cs.otherCostRate,
              targetMarginPct: msg.targetMarginPct, targetCurrency: mk.currency
            });
            if (base != null) sell = Math.round(base * (1 + (Number(msg.floatPct) || 0) / 100) * 100) / 100;
          }
          // ⑤ 逐 SKU 用同一套毛利公式反推「折后成交价」，再按活动折扣换算成平台「标价」= 折后价 ÷ (1−折扣)
          //    每个 SKU 用各自的 1688 进价（it.content.skus[].price），运费/费率共用商品主档；超过 10 个只取前 10。
          const disc = Math.min(Math.max(Number(msg.discountPct) || 0, 0), 90);
          const discDiv = 1 - disc / 100;
          let skuPrices = [];
          if (cs.shipping > 0 && it.content && Array.isArray(it.content.skus) && it.content.skus.length) {
            skuPrices = it.content.skus.slice(0, 10).map(s => {
              const cost = (s && Number(s.price) > 0) ? Number(s.price) : (cs.purchasePrice > 0 ? cs.purchasePrice : null);
              if (cost == null) return { spec: (s && s.spec) || "", cost: null, discounted: null, list: null };
              const b = window.SS_RULES.suggestPrice({
                purchaseCny: cost, shippingCny: cs.shipping,
                feePct: cs.platformFeeRate, otherPct: cs.otherCostRate,
                targetMarginPct: msg.targetMarginPct, targetCurrency: mk.currency
              });
              const discounted = b != null ? Math.round(b * (1 + (Number(msg.floatPct) || 0) / 100) * 100) / 100 : null;
              const list = (discounted != null && discDiv > 0) ? Math.round(discounted / discDiv * 100) / 100 : discounted;
              return { spec: (s && s.spec) || "", cost, discounted, list };
            });
          }
          if (sell != null) {
            const tp = $('targetPrice');
            if (tp) { tp.value = sell; tp.dispatchEvent(new Event('input', { bubbles: true })); tp.dispatchEvent(new Event('change', { bubbles: true })); }
            window.MSMarket.refresh(true); await _sleep(120);
          } else {
            const tp = $('targetPrice'); if (tp && !tp.value && it.price != null) { /* 没算出售价就留空，不造数 */ }
          }
          // SKU 文本过长截断（同步进采集箱前，让发布时的规格名短一点）
          if (skuMax && it.content && Array.isArray(it.content.skus)) {
            it.content.skus = it.content.skus.map(s => (s && s.spec && String(s.spec).length > skuMax) ? Object.assign({}, s, { spec: String(s.spec).slice(0, skuMax) + '…' }) : s);
          }
          try { await sync(); } catch (e) { /* sync 内部写 status */ }
          const st = ($('status').textContent || '');
          if (/已同步|已进采集箱/.test(st)) {
            // 真实采集箱编号（sync 成功文案里带「编号 xxx」）；拿不到才退回本地标记
            it.syncedToInboxId = (st.match(/编号\s*([a-z0-9]+)/) || [])[1] || ('r' + Date.now());
            // 「整页内容：DOC」才算补齐；只同步了基础信息的条目发布必被平台拦
            const doc = /整页内容：DOC/.test(st);
            it.docReady = doc;
            synced++; results.push({ title: it.title, url: it.url, sell, currency: mk.currency, doc, inboxId: it.syncedToInboxId, skuPrices, discountPct: disc });
          } else { failed++; results.push({ title: it.title, url: it.url, doc: false, err: String(st).replace(/\s+/g, ' ').trim().slice(0, 140) || 'sync 无状态反馈' }); }
          await _sleep(250);
        }
        await window.MSStore.writeBucket(storeKey, products);
        sendResponse({ ok: true, synced, failed, results });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    }
  })();
  return true; // 异步回复
});
