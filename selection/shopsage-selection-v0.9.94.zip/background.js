/* ShopSage MV3 service worker：
 * 关键修复：采购/店铺类后端调用直接在 service worker 里用存储的 Bearer fetch，不再开 purchase.html 控制页标签；
 * automation.html 只保留给「开始持续跑」的循环（用户主动点才开）。这样刷新 1688/拼多多 页不会再自动冒出一堆标签。 */

function base() { return "https://www.shopsage.cc"; }
async function getToken() {
  const s = await chrome.storage.local.get(["backendUrl", "accessToken", "tokenAt", "refreshToken"]);
  const b = (s.backendUrl || base()).replace(/\/+$/, "") || base();
  let token = s.accessToken || "";
  const stale = !token || (Date.now() - Number(s.tokenAt || 0) > 12 * 60 * 1000);
  if (stale && s.refreshToken) {
    try {
      const rr = await fetch(b + "/api/auth/refresh", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken: s.refreshToken }) });
      const rj = await rr.json().catch(() => ({}));
      const d = (rj && rj.data) ? rj.data : rj;
      if (d && d.accessToken) { token = d.accessToken; await chrome.storage.local.set({ accessToken: token, refreshToken: d.refreshToken || s.refreshToken, tokenAt: Date.now() }); }
    } catch (e) {}
  }
  return { b, token };
}
async function swFetch(path, init) {
  const { b, token } = await getToken();
  if (!token) throw new Error("未登录 ShopSage 账号");
  let r = await fetch(b + path, { method: (init && init.method) || "GET", credentials: "include", headers: Object.assign({ "Content-Type": "application/json", "x-app-locale": "zh", Authorization: "Bearer " + token }, (init && init.headers) || {}), body: init && init.body });
  if (r.status === 401) { // 再刷一次
    const s = await chrome.storage.local.get(["refreshToken"]);
    try {
      const rr = await fetch(b + "/api/auth/refresh", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken: (s && s.refreshToken) || "" }) });
      const rj = await rr.json().catch(() => ({})); const d = (rj && rj.data) ? rj.data : rj;
      if (d && d.accessToken) { await chrome.storage.local.set({ accessToken: d.accessToken, refreshToken: d.refreshToken || s.refreshToken, tokenAt: Date.now() });
        r = await fetch(b + path, { method: (init && init.method) || "GET", credentials: "include", headers: { "Content-Type": "application/json", "x-app-locale": "zh", Authorization: "Bearer " + d.accessToken }, body: init && init.body }); }
    } catch (e) {}
  }
  const data = await r.json().catch(() => ({}));
  if (r.status >= 400) throw new Error((data && (data.message || (data.data && data.data.message))) || ("后台返回 " + r.status));
  return (data && typeof data === "object" && "success" in data && "data" in data) ? data.data : data;
}

// ── 一键登录（票据换 token）放进 SW：常驻可收，不再依赖插件页面是否开着 ──
const _handoffOnce = new Map();
async function swHandoff(ticket) {
  const tk = String(ticket || "");
  if (!tk) throw new Error("缺少登录票据");
  if (_handoffOnce.has(tk)) return _handoffOnce.get(tk); // 同一票据被重复投递(中继+直投)：复用一次兑换结果，避免第二次报"无效/过期"
  const p = _doHandoff(tk).finally(() => setTimeout(() => _handoffOnce.delete(tk), 120000));
  _handoffOnce.set(tk, p);
  return p;
}
async function _doHandoff(ticket) {
  const b = base();
  const r = await fetch(b + "/api/v1/extension/handoff", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "x-app-locale": "zh" }, body: JSON.stringify({ ticket: String(ticket) }) });
  const j = await r.json().catch(() => ({}));
  const d = (j && j.data) ? j.data : j;
  if (r.status !== 200 || !d || !d.accessToken) throw new Error((d && (d.message || d.error)) || ("一键登录失败 " + r.status));
  const u = d.user || {};
  const email = u.email || d.email || "";
  const userName = u.name || d.userName || d.name || email;
  await chrome.storage.local.set({ backendUrl: b, accessToken: d.accessToken, refreshToken: d.refreshToken || "", tokenAt: Date.now(), email, userName });
  try { const me = await fetch(b + "/api/auth/me", { headers: { Authorization: "Bearer " + d.accessToken }, credentials: "include" }); if (me.status === 401) throw new Error("换到的令牌无效"); } catch (e) {}
  return { email };
}

/* 老版本一键登录只存了 token、没把 user.email 落到 storage：弹窗按 token 显示“已登录”，
 * 自动化面板按 email 判断却报“未登录”。这里用现有 Bearer 回填一次邮箱，修复已登录用户。 */
async function ensureEmail() {
  const s = await chrome.storage.local.get({ email: "", userName: "" });
  if (s.email) return s.email;
  try {
    // 走 swFetch：401 时会用 refreshToken 自动续期后再取；裸 fetch 遇到过期 token 会直接失败，
    // 导致店铺接口能载入、邮箱却回填不了（自动化面板仍报未登录）。
    const d = await swFetch("/api/auth/me");
    const u = (d && d.user) ? d.user : d;
    const email = (u && (u.email || (u.account && u.account.email))) || (d && d.email) || "";
    if (email) await chrome.storage.local.set({ email, userName: (u && (u.name || u.email)) || email });
    else { try { console.warn("[ShopSage] ensureEmail 未能从 /api/auth/me 取到邮箱，返回结构键：", u ? Object.keys(u).join(",") : "(空)"); } catch (e) {} }
    return email;
  } catch (e) { return ""; }
}

async function handlePurchase(op, p) {
  if (op === "ping") return { ok: true, ready: true };
  if (op === "bind") return { ok: true, data: await swFetch("/api/purchase/bind?poId=" + encodeURIComponent(String(p.poId || "")), { method: "GET" }) };
  if (op === "report") {
    const body = { externalOrderNo: (p.externalOrderNo || "") || undefined, domesticTrackingNo: (p.domesticTrackingNo || p.trackingNo || "") || undefined, domesticCarrier: (p.domesticCarrier || p.carrier || "") || undefined, trackingNo: (p.trackingNo || "") || undefined, carrier: (p.carrier || "") || undefined, paidCostCny: (p.paidCostCny == null || p.paidCostCny === "" || isNaN(Number(p.paidCostCny))) ? undefined : Number(p.paidCostCny), unitCostCny: (p.unitCostCny == null || p.unitCostCny === "" || isNaN(Number(p.unitCostCny))) ? undefined : Number(p.unitCostCny), cnTitle: (p.cnTitle || "") || undefined, quantity: (p.quantity == null || p.quantity === "" || isNaN(Number(p.quantity))) ? undefined : Number(p.quantity) };
    return { ok: true, data: await swFetch("/api/purchase/" + encodeURIComponent(String(p.poId || "")) + "/report", { method: "POST", body: JSON.stringify(body) }) };
  }
  if (op === "pending") return { ok: true, data: await swFetch("/api/purchase/pending?hours=" + encodeURIComponent(Number(p.hours) || 24), { method: "GET" }) };
  if (op === "forwarders") return { ok: true, data: await swFetch("/api/purchase/forwarders", { method: "GET" }) };
  if (op === "skuLink") return { ok: true, data: await swFetch("/api/purchase/sku-link", { method: "POST", body: JSON.stringify(p) }) };
  if (op === "shops") return { ok: true, data: await swFetch("/api/shops", { method: "GET" }) };
  throw new Error("未知 op " + op);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;

  // 采购/店铺接口：SW 直接 fetch，不开任何控制页标签
  if (message.type === "SS_PURCHASE_API") {
    handlePurchase(message.op, message.payload || {}).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  // 内容脚本中继的一键登录票据（绕开 externally_connectable，双通道之一）
  if (message.type === "SS_HANDOFF") {
    swHandoff(message.ticket).then((r) => sendResponse({ ok: true, email: r.email })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  if (message.type === "OPEN_LIBRARY") {
    chrome.tabs.create({ url: chrome.runtime.getURL("library.html") });
    return;
  }

  // 自动化开跑前强制回填邮箱：控制器标签已存在时不会再走 SS_AUTO_OPEN_CTRL，
  // 只靠打开控制页时回填会漏掉“控制器早就开着”的场景。
  if (message.type === "SS_ENSURE_EMAIL") {
    ensureEmail().then((email) => sendResponse({ ok: !!email, email })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  // 自动化控制页：只在用户点「开始持续跑」等主动操作时才拉起（按 URL 复用，绝不重复开）
  // 稳定性：pinned 该隐藏控制页——Chrome/ego 的 Memory Saver 不丢弃 pinned 标签，避免长循环被中途杀（"只采集没填完"根因）
  if (message.type === "SS_AUTO_OPEN_CTRL") {
    (async () => {
      await ensureEmail();
      const url = chrome.runtime.getURL("automation/automation.html");
      try { const f = await chrome.tabs.query({ url }); if (f && f.length) { try { await chrome.tabs.update(f[0].id, { pinned: true }); } catch (e) {} return sendResponse({ ok: true, reused: true }); } } catch (e) {}
      try { const t = await chrome.tabs.create({ url, active: false }); try { await chrome.tabs.update(t.id, { pinned: true }); } catch (e) {} sendResponse({ ok: true, opened: true }); } catch (e) { sendResponse({ ok: false }); }
    })();
    return true;
  }

  if (message.type === "injectFile") {
    chrome.scripting.executeScript({ target: { tabId: message.tabId }, files: [message.file] })
      .then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
});

// 官网中转页经 externally_connectable 直投票据：SW 常驻接收，插件页面没开也能一键登录
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  const okSender = sender && sender.url && /^https:\/\/([a-z0-9-]+\.)?shopsage\.cc\//.test(sender.url);
  if (!okSender || !message || message.type !== "shopsage-handoff" || !message.ticket) {
    sendResponse({ ok: false, error: "来源或消息不符合" });
    return true;
  }
  swHandoff(message.ticket).then((r) => sendResponse({ ok: true, email: r.email })).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
  return true;
});

/* 稳定性看门狗：自动化循环跑在隐藏控制页 automation.html。若该页被丢弃/崩溃/重载而任务本应仍在跑，
 * 控制页自身会按持久化进度自动续跑；这里再兜一层——SW 定时发现"应仍在跑但控制页已不存在"时，
 * 重新拉起 pinned 控制页触发续跑。10 分钟无心跳视为陈旧，不复活。
 * 注意：chrome.alarms 需 manifest 声明 "alarms" 权限；用存在性守卫，缺权限也不崩、SW 照常注册。 */
const AUTO_RUN_KEY = "ssAutoRun";
const AUTO_CTRL_URL = () => chrome.runtime.getURL("automation/automation.html");
function armWatchdog(){ try { if (chrome.alarms) chrome.alarms.create("ssAutoWatchdog", { periodInMinutes: 1 }); } catch (e) {} }
if (chrome.alarms) {
  chrome.runtime.onStartup.addListener(armWatchdog);
  chrome.runtime.onInstalled.addListener(armWatchdog);
  armWatchdog();
  chrome.alarms.onAlarm.addListener(async (a) => {
    if (!a || a.name !== "ssAutoWatchdog") return;
    try {
      const s = await chrome.storage.local.get(AUTO_RUN_KEY);
      const st = s && s[AUTO_RUN_KEY];
      if (!st || !st.running) return;
      if (Date.now() - Number(st.at || 0) > 10 * 60 * 1000) { await chrome.storage.local.remove(AUTO_RUN_KEY); return; }
      const tabs = await chrome.tabs.query({ url: AUTO_CTRL_URL() });
      if (tabs && tabs.length) { try { await chrome.tabs.update(tabs[0].id, { pinned: true }); } catch (e) {} return; }
      const t = await chrome.tabs.create({ url: AUTO_CTRL_URL(), active: false });
      try { await chrome.tabs.update(t.id, { pinned: true }); } catch (e) {}
    } catch (e) {}
  });
}
