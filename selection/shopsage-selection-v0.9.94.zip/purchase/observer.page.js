/* ShopSage 采购板块 · 1688 页观察者（MAIN world, document_start）
 * 板块隔离：只服务「采购」，与采集/自动化无关；只在 1688 域运行。
 * 职责：
 *  1) 读 URL hash 里的 #ss_po=<poId>，postMessage 给 ISOLATED 浮窗，然后清掉 hash（不外泄 poId）。
 *  2) 包裹 window.fetch + XMLHttpRequest，捕获页面自己发出的 1688 订单接口(h5api.m.1688.com / dataline)响应，
 *     从中通用抽取候选订单记录（订单号/运单/承运/金额/offerId/下单时间），postMessage 给浮窗。
 *  3) 把最近一次疑似订单响应原样存到 window.__ssPurchaseCap，供开发校准真实字段（解析器据真实结构再收紧，不猜）。
 * 红线：不碰支付、不写任何 1688 表单、不猜测——只读页面已发出的数据，抽不到就交给浮窗走手填。 */
(function () {
  "use strict";
  try {
    if (window.__ssPurchaseObserver) return;
    window.__ssPurchaseObserver = true;

    // ── 1) ss_po 认领 ──────────────────────────────────────────────
    function readPo() {
      try {
        const m = /(?:^|[#&?])ss_po=([A-Za-z0-9_-]+)/.exec(location.hash || "");
        if (!m) return;
        const poId = m[1];
        // 清掉 hash，避免用户复制链接带出 poId（poId 非密钥，但按文档来）
        history.replaceState(null, "", location.pathname + location.search);
        post({ type: "SS_PURCHASE_PO", poId, at: Date.now() });
      } catch (e) {}
    }
    readPo();
    // SPA 路由/二次带 hash
    addEventListener("hashchange", readPo);
    let _href = location.href;
    setInterval(() => { if (location.href !== _href) { _href = location.href; readPo(); } }, 1200);

    // ── 2) 与 ISOLATED 浮窗通信（MAIN 世界不能用 chrome.*）──────────
    function post(obj) {
      try { obj.__ssP = 1; window.postMessage(obj, location.origin); } catch (e) {}
    }

    // ── 3) 通用抽取：从任意 JSON 里找像「1688 订单」的结构 ───────────
    const ORDER_ID_RE = /\b\d{15,20}\b/;
    const OFFER_RE = /(?:detail\.1688\.com\/offer\/(\d+)|offerId["\s:=]+(\d{6,})|offer["\s:=]+(\d{6,})|goods_id=(\d{6,})|goodsId["\s:=]+(\d{6,}))/i;
    const TRACK_RE = /(?:JT\d{9,}|SF\d{9,}|(?:[A-Z]{2})\d{9,12})\b/; // 极兔JT/顺丰SF/通用两字母+数字
    const AMOUNT_KEYS = ["payment", "payAmount", "actualPayAmount", "sumPayment", "payFee", "unitPrice", "unitCost", "realPayFee", "totalPrice", "amount", "paidFee", "payAmountStr", "orderAmount"];
    const ORDER_ID_KEYS = ["orderId", "bizOrderId", "orderNo", "tradeId", "id", "parentOrderId", "mainOrderId", "orderCode", "orderSn", "sn"];
    const TRACK_KEYS = ["logisticsNo", "trackingNo", "mailNo", "waybill", "expressNo", "运单号", "invoiceNo", "trackingNumber", "logisticsCode", "waybillNo"];
    const CARRIER_KEYS = ["companyName", "logisticsCompany", "carrier", "expressCompany", "cpName", "物流公司", "logisticsName"];
    const TIME_KEYS = ["gmtCreate", "createTime", "createTimeStr", "payTime", "orderCreateTime", "createdOn", "confirmTime"];

    function toStr(v) { return v == null ? "" : (typeof v === "object" ? "" : String(v)); }
    function offerIdFromUrl(u) { const m = /offer\/(\d+)\.html/i.exec(u || "") || /goods_id=(\d+)/i.exec(u || ""); return m ? m[1] : ""; }

    // 递归收集候选订单记录
    function scan(node, out, depth) {
      if (depth > 12 || !node) return;
      if (Array.isArray(node)) { node.forEach((x) => scan(x, out, depth + 1)); return; }
      if (typeof node !== "object") return;
      const rec = {};
      // 订单号
      for (const k of ORDER_ID_KEYS) { const s = toStr(node[k]); if (ORDER_ID_RE.test(s)) { rec.orderNo = (s.match(ORDER_ID_RE) || [])[0]; break; } }
      // 金额
      for (const k of AMOUNT_KEYS) { const s = toStr(node[k]); const n = Number(String(s).replace(/[^0-9.\-]/g, "")); if (isFinite(n) && n > 0) { rec.amount = n; rec.amountKey = k; break; } }
      // 运单
      for (const k of TRACK_KEYS) { const s = toStr(node[k]); if (TRACK_RE.test(s)) { rec.trackingNo = (s.match(TRACK_RE) || [])[0]; break; } }
      if (!rec.trackingNo) { const blob = JSON.stringify(node).slice(0, 4000); const tm = blob.match(TRACK_RE); if (tm) rec.trackingNo = tm[0]; }
      // 承运
      for (const k of CARRIER_KEYS) { const s = toStr(node[k]); if (s && /快递|速递|物流|邮政|顺丰|圆通|中通|韵达|申通|极兔|百世|京东|EMS/i.test(s)) { rec.carrier = s.slice(0, 24); break; } }
      // offer 链接/id
      const blobForOffer = JSON.stringify(node).slice(0, 6000);
      const om = OFFER_RE.exec(blobForOffer); if (om) rec.offerId = om[1] || om[2] || om[3] || "";
      // 时间
      for (const k of TIME_KEYS) { const s = toStr(node[k]); if (/\d{4}[-/]\d{2}[-/]\d{2}/.test(s)) { rec.time = s.slice(0, 19); break; } }

      if (rec.orderNo || rec.trackingNo || (rec.offerId && rec.amount != null)) {
        out.push(rec);
      }
      for (const key in node) { try { scan(node[key], out, depth + 1); } catch (e) {} }
    }

    function processResponse(text, src) {
      try {
        if (!text || typeof text !== "string") return;
        if (text.length > 300000) return; // 太长的不解析
        // 只处理含订单/物流特征的数据，省 CPU
        if (!/offerId|orderId|bizOrderId|logistics|orderNo|orderSn|goods_id|detail\.1688|pinduoduo|yangkeduo|运单|订单/i.test(text)) return;
        let j;
        // mtop 可能是 jsonp：mtopjsonp1({...})；fetch 多为纯 JSON
        const jsm = text.match(/\{[\s\S]*\}/);
        // H4：1688/拼多多订单号常 16–19 位，JSON.parse 会把长整型当浮点丢末位（实测 …700→704）→ 回传错单。
        // 解析前把「作为值出现的 15–20 位纯整数」加引号（lookahead 不吞分隔符，连号也能各自命中）；已是字符串的（带引号）不受影响。
        let payload = jsm ? jsm[0] : text;
        payload = payload.replace(/([:\[,]\s*)(\d{15,20})(?=\s*[,}\]])/g, '$1"$2"');
        j = JSON.parse(payload);
        // 校准用：留一份原始（截断）
        try { window.__ssPurchaseCap = { ts: Date.now(), src: src || "", api: (j && j.api) || "", raw: text.slice(0, 20000), json: j }; } catch (e) {}
        const recs = [];
        scan(j, recs, 0);
        // 去重
        const seen = new Set(); const uniq = [];
        for (const r of recs) { const k = (r.orderNo || "") + "|" + (r.trackingNo || "") + "|" + (r.offerId || "") + "|" + (r.amount || ""); if (seen.has(k)) continue; seen.add(k); uniq.push(r); }
        if (uniq.length) post({ type: "SS_PURCHASE_ORDERS", orders: uniq.slice(0, 40), src: src || "" });
      } catch (e) {}
    }

    // ── fetch 包裹 ────────────────────────────────────────────────
    const of = window.fetch;
    if (typeof of === "function") {
      window.fetch = function () {
        const p = of.apply(this, arguments);
        try {
          p.then((res) => {
            try {
              const u = (res && res.url) || "";
              if (/(1688\.com|pinduoduo\.com|yangkeduo\.com)/.test(u) && /order|trade|dataline|logistic|mtop|goods|api|query|refund|express/i.test(u)) {
                res.clone().text().then((t) => processResponse(t, "fetch:" + u.slice(0, 60))).catch(() => {});
              }
            } catch (e) {}
          }).catch(() => {});
        } catch (e) {}
        return p;
      };
    }

    // ── XMLHttpRequest 包裹 ───────────────────────────────────────
    const OO = XMLHttpRequest.prototype.open, OS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, u) { this.__ssU = String(u || ""); return OO.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function () {
      const x = this;
      x.addEventListener("load", function () {
        try {
          const u = x.__ssU || "";
          if (/1688\.com/.test(u) && /order|trade|dataline|logistic|mtop/i.test(u)) {
            const t = x.responseText || "";
            processResponse(t, "xhr:" + u.slice(0, 60));
          }
        } catch (e) {}
      });
      return OS.apply(this, arguments);
    };

    // ── 若页面后续用 window.lib.mtop（部分走 <script> jsonp 抓不到），补一层 ──
    function hookMtop() {
      try {
        const L = window.lib && window.lib.mtop; if (!L || typeof L.request !== "function" || L.__ssWrapped) return;
        const orig = L.request.bind(L);
        L.__ssWrapped = 1;
        window.lib.mtop.request = function (opt, cb) {
          const wrapped = function (res) {
            try { processResponse(JSON.stringify(res), "mtop:" + ((opt && opt.api) || "")); } catch (e) {}
            return cb && cb(res);
          };
          return orig(opt, wrapped);
        };
      } catch (e) {}
    }
    hookMtop();
    // lib.mtop 常在 document 后才就绪
    const iv = setInterval(() => { hookMtop(); if (window.lib && window.lib.mtop) clearInterval(iv); }, 1500);
    setTimeout(() => clearInterval(iv), 60000);
  } catch (e) {}
})();
