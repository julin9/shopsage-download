/* ShopSage 插件在线探测应答（跨板块通用，非采购/采集/自动化任一专属）
 * 官网（如 /purchase 采购弹窗）会发 window.postMessage({type:"shopsage-extension:ping"})，
 * 1.2 秒内插件不回 pong 就提示"未检测到插件"。本脚本在 shopsage.cc 页面收到 ping 就回 pong + 版本。
 * 只应答这一个探测消息，不做其它事、不采集任何页面内容。 */
(function () {
  "use strict";
  if (window.__ssPresenceBound) return;
  window.__ssPresenceBound = true;

  window.addEventListener("message", function (ev) {
    try {
      if (!ev || ev.source !== window) return;
      var d = ev.data;
      if (d && d.type === "shopsage-extension:ping") {
        var v = "";
        try { v = (chrome.runtime.getManifest().version) || ""; } catch (e) {}
        window.postMessage({ type: "shopsage-extension:pong", version: v, extensionId: (chrome.runtime.id || "") }, location.origin);
      }
      // 一键登录第二通道：官网用 window.postMessage 递票据 → 转发 SW 换票 → 回投结果（不依赖 externally_connectable）
      if (d && d.type === "shopsage-handoff" && d.ticket) {
        try {
          chrome.runtime.sendMessage({ type: "SS_HANDOFF", ticket: d.ticket }, function (resp) {
            window.postMessage({ type: "shopsage-handoff:result", ok: !!(resp && resp.ok), email: (resp && resp.email) || "", error: (resp && resp.error) || "" }, location.origin);
          });
        } catch (e) {
          window.postMessage({ type: "shopsage-handoff:result", ok: false, error: "插件通道未就绪，请重试" }, location.origin);
        }
      }
    } catch (e) {}
  });
})();
