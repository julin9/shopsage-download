/**
 * ShopSage 选品助手 · 登录与后台请求 v3（2026-11-09）
 *
 * 老板口径：① 插件登录要像生图网站一样用官网一键登录，不再输密码；
 *           ② 不要经常重新登录（之前 15 分钟就掉线的体验很差）。
 *
 * 这版两条都从根上解决，且仍然只用官网这一套账号地基（无第二套凭据表）：
 *
 *  一键登录（主路径）：
 *    插件打开官网中转页 /extension/handoff?ext=<插件ID> → 官网登录态签发 60 秒一次性票据
 *    （aud=shopsage-extension）→ 页面 chrome.runtime.sendMessage 直接递给插件 →
 *    插件拿票据 POST /api/v1/extension/handoff → 换 access + refresh 令牌（响应体）。
 *    刷新令牌 7 天轮换，从此 7 天内打开插件直接可用；官网登出即作废。
 *
 *  静默续期（次路径兜底）：
 *    access token 15 分钟；临期用刷新令牌 POST /api/v1/auth/refresh（放请求体，
 *    不依赖第三方 Cookie——之前走 Cookie 的路被跨源 SameSite 掐死，这就是反复掉线的根因）。
 *    后台轮换：旧的作废、新的回到响应体，插件跟着更新存储。
 *
 *  密码登录保留为兜底（官网 Cookie 被清了/插件刚装）。
 *  密码与刷新令牌的存放：刷新令牌存 chrome.storage（第一方客户端，等同移动端做法）；
 *  密码永不落盘；官网后台退出登录，服务端会话作废，插件同步下线。
 */
(function (root) {
  'use strict';

  var DEFAULT_BASE = 'https://www.shopsage.cc';
  var ACCESS_TTL_MS = 12 * 60 * 1000;   // 官网 15 分钟，提前 3 分钟续
  var STORE_KEYS = ['backendUrl', 'email', 'accessToken', 'tokenAt', 'refreshToken', 'userName'];

  function baseOf(url) {
    return String(url || '').trim().replace(/\/+$/, '') || DEFAULT_BASE;
  }

  function state() {
    return chrome.storage.local.get({
      backendUrl: '', email: '', accessToken: '', tokenAt: 0, refreshToken: '', userName: ''
    });
  }

  function isConnected(s) {
    return !!(s && (s.accessToken || s.refreshToken));
  }

  /** 裸请求：返回 {status, data}，不抛错。 */
  async function raw(path, init, base) {
    var res = await fetch(baseOf(base) + path, {
      method: (init && init.method) || 'GET',
      credentials: 'include',
      headers: Object.assign(
        { 'Content-Type': 'application/json', 'x-app-locale': 'zh' },
        (init && init.headers) || {}
      ),
      body: init && init.body
    }).catch(function () {
      throw new Error('连不上 ShopSage 官网，请检查网络后重试');
    });
    var data = await res.json().catch(function () { return {}; });
    return { status: res.status, data: data };
  }

  function errOf(data, status, fallback) {
    var m = (data && (data.message || (data.data && data.data.message))) || '';
    return m || fallback || ('后台返回 ' + status);
  }

  /** 官网后台全局信封 {success,data}——不拆包调用方拿到的是空壳。 */
  function unwrap(envelope) {
    if (envelope && typeof envelope === 'object' &&
        Object.prototype.hasOwnProperty.call(envelope, 'success') &&
        Object.prototype.hasOwnProperty.call(envelope, 'data')) {
      return envelope.data;
    }
    return envelope;
  }

  /** 用刷新令牌换新令牌（后台轮换：旧的作废）。优先请求体；没有刷新令牌时试官网 Cookie。 */
  async function renew() {
    var s = await state();
    var body = s.refreshToken ? { refreshToken: s.refreshToken } : {};
    var r = await raw('/api/auth/refresh', { method: 'POST', body: JSON.stringify(body) });
    if (r.status !== 200) {
      if (r.data && r.data.code === 'INVALID_REFRESH_TOKEN') throw new Error('EXPIRED');
      throw new Error('RENEW_FAILED');
    }
    var payload = unwrap(r.data) || {};
    var accessToken = payload.accessToken;
    var refreshToken = payload.refreshToken || s.refreshToken || '';
    if (!accessToken) throw new Error('EXPIRED');
    await chrome.storage.local.set({
      accessToken: accessToken,
      refreshToken: refreshToken,
      tokenAt: Date.now(),
      userName: (payload.user && (payload.user.name || payload.user.email)) || s.userName || s.email || '',
    });
    return accessToken;
  }

  /** 临期自动续；续不动 = 真掉线，如实 NEED_LOGIN。 */
  async function validToken() {
    var s = await state();
    if (!s.accessToken && !s.refreshToken) throw new Error('NEED_LOGIN');
    if (s.accessToken && Date.now() - Number(s.tokenAt || 0) < ACCESS_TTL_MS) return s.accessToken;
    try {
      return await renew();
    } catch (e) {
      if (e.message === 'EXPIRED' || e.message === 'RENEW_FAILED') {
        await chrome.storage.local.remove(['accessToken', 'tokenAt']);
        throw new Error('NEED_LOGIN');
      }
      throw e;
    }
  }

  /** 账号密码登录（兜底路径）。密码不落盘。 */
  async function login(email, password) {
    email = String(email || '').trim();
    if (!email || !password) throw new Error('请填邮箱和密码');
    var s = await state();
    var base = baseOf(s.backendUrl);
    var r = await raw('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: email, password: password })
    }, base);
    if (r.status !== 200) throw new Error(errOf(r.data, r.status, '登录失败，请检查邮箱和密码'));
    var payload = unwrap(r.data) || {};
    var user = payload.user || {};
    if (!payload.accessToken) throw new Error('官网没有返回登录凭证');

    // 密码登录也补换一枚刷新令牌：登录响应只带 Cookie（跨源拿不到），走一次 refresh 换出令牌对的另一半
    var refreshToken = '';
    try {
      var rr = await raw('/api/auth/refresh', { method: 'POST', body: '{}' }, base);
      if (rr.status === 200) {
        var rp = unwrap(rr.data) || {};
        accessToken2Check(rp);
        refreshToken = rp.refreshToken || '';
        payload.accessToken = rp.accessToken || payload.accessToken;
      }
    } catch (e) { /* 换不出就先只有 15 分钟 access——如实不编 */ }

    await chrome.storage.local.set({
      backendUrl: base,
      email: email,
      userName: user.name || user.email || email,
      accessToken: payload.accessToken,
      refreshToken: refreshToken,
      tokenAt: Date.now(),
    });
    return { email: email, name: user.name || user.email || email, hasRenew: !!refreshToken };
  }

  function accessToken2Check(rp) { /* 占位：refresh 响应的形状校验走 unwrap 之外不做强校验 */ }

  /** 退出：让官网把会话作废（有刷新令牌就带上），再清本地。 */
  async function logout() {
    var s = await state();
    var base = baseOf(s.backendUrl);
    try {
      if (s.refreshToken) {
        await raw('/api/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: s.refreshToken }) }, base);
      }
    } catch (e) { /* 够不着也要让用户能退出本地 */ }
    await chrome.storage.local.remove(STORE_KEYS);
  }

  /** 统一后台请求：临期自动续（401 再续一次重试），401 = 请重新登录。 */
  async function backendFetch(path, init) {
    var s = await state();
    if (!s.accessToken && !s.refreshToken) throw new Error('NEED_LOGIN');
    var base = baseOf(s.backendUrl);
    var token = await validToken();

    var r = await raw(path, {
      method: (init && init.method) || 'GET',
      headers: { Authorization: 'Bearer ' + token },
      body: init && init.body
    }, base);

    if (r.status === 401) {
      var renewed = null;
      try { renewed = await renew(); } catch (e) { /* 续不上就走 NEED_LOGIN */ }
      if (!renewed) throw new Error('NEED_LOGIN');
      r = await raw(path, {
        method: (init && init.method) || 'GET',
        headers: { Authorization: 'Bearer ' + renewed },
        body: init && init.body
      }, base);
      if (r.status === 401) throw new Error('NEED_LOGIN');
    }
    if (r.status >= 400) throw new Error(errOf(r.data, r.status, '后台返回 ' + r.status));
    return unwrap(r.data);
  }

  function friendlyError(message) {
    if (message === 'NEED_LOGIN') return '登录已失效，请重新登录（可用官网一键登录，几秒完成）。';
    if (message === 'RENEW_FAILED') return '暂时无法自动续期，请重新登录一次。';
    return message || '操作没有成功，请重试。';
  }

  /* ── 一键登录：官网中转页把一次性票据递进来 ───────────────────────── */
  async function handoff(ticket) {
    if (!ticket) throw new Error('缺少登录票据');
    var s = await state();
    var base = baseOf(s.backendUrl);
    var r = await raw('/api/v1/extension/handoff', {
      method: 'POST',
      body: JSON.stringify({ ticket: String(ticket) })
    }, base);
    if (r.status !== 200) throw new Error(errOf(r.data, r.status, '一键登录失败，请回插件重试'));
    var payload = unwrap(r.data) || {};
    if (!payload.accessToken || !payload.refreshToken) throw new Error('官网没有返回完整令牌');
    var user = payload.user || {};
    await chrome.storage.local.set({
      backendUrl: base,
      email: user.email || '',
      userName: user.name || user.email || '',
      accessToken: payload.accessToken,
      refreshToken: payload.refreshToken,
      tokenAt: Date.now(),
    });
    // 通知打开着的页面（登录闸门/选品库）刷新登录态
    try { window.dispatchEvent(new Event('ms-auth-changed')); } catch (e) { /* noop */ }
    return { email: user.email || '', name: user.name || user.email || '' };
  }

  /** 官网中转页（shopsage.cc 域）通过 externally_connectable 递票据进来。 */
  if (root.chrome && root.chrome.runtime && root.chrome.runtime.onMessageExternal) {
    root.chrome.runtime.onMessageExternal.addListener(function (msg, sender, sendResponse) {
      var okSender = sender && sender.url && /https:\/\/([a-z0-9-]+\.)?shopsage\.cc\//.test(sender.url);
      if (!okSender || !msg || msg.type !== 'shopsage-handoff' || !msg.ticket) {
        sendResponse({ ok: false, error: '来源或消息不符合' });
        return true;
      }
      handoff(msg.ticket).then(
        function (r) { sendResponse({ ok: true, email: r.email }); },
        function (e) { sendResponse({ ok: false, error: e && e.message ? e.message : String(e) }); }
      );
      return true;   // 异步应答
    });
  }

  function wirePasswordEye() {
    var input = document.getElementById('msGatePassword');
    var eye = document.getElementById('msGateEye');
    if (!input || !eye) return;
    var EYE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
    var EYE_OFF = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
    function paint() {
      var shown = input.type === 'text';
      eye.innerHTML = shown ? EYE_OFF : EYE;
      eye.setAttribute('aria-label', shown ? '隐藏密码' : '显示密码');
      eye.setAttribute('data-shown', shown ? '1' : '0');
    }
    eye.onclick = function () { input.type = input.type === 'text' ? 'password' : 'text'; paint(); };
    paint();
  }

  function friendlyError(message) {
    if (message === 'NEED_LOGIN') return '登录已失效，请重新登录（可用官网一键登录，几秒完成）。';
    if (message === 'RENEW_FAILED') return '暂时无法自动续期，请重新登录一次。';
    return message || '操作没有成功，请重试。';
  }

  /**
   * 登录闸门：顶部一颗「用官网账号一键登录」主按钮（打开官网中转页，几秒完成），
   * 账号密码表单收成兜底折叠。没登录只见登录框，登录成功才出正文。
   */
  async function mountGate(opts) {
    var gate = document.getElementById('msGate');
    var main = document.getElementById('msMain');
    var s = await state();
    wirePasswordEye();

    function render(on) {
      if (gate) gate.classList.toggle('hidden', !!on);
      if (main) main.classList.toggle('hidden', !on);
      var chip = document.getElementById('msAccount');
      if (chip) chip.textContent = on ? (s.userName || s.email || '已登录') : '未登录';
      var out = document.getElementById('msLogout');
      if (out) out.style.display = on ? '' : 'none';
    }

    var oneBtn = document.getElementById('msOneClick');
    if (oneBtn) {
      oneBtn.onclick = function () {
        var msg = document.getElementById('msGateMsg');
        if (msg) { msg.textContent = '正在打开官网连接页…'; }
        try {
          chrome.tabs.create({ url: baseOf(s.backendUrl) + '/extension/handoff?ext=' + chrome.runtime.id });
        } catch (e) { if (msg) msg.textContent = '打开官网连接页失败：' + e.message; }
      };
    }

    var btn = document.getElementById('msGateLogin');
    var msg = document.getElementById('msGateMsg');
    if (btn) {
      btn.onclick = async function () {
        var email = document.getElementById('msGateEmail');
        var pass = document.getElementById('msGatePassword');
        btn.disabled = true;
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = '正在登录…'; }
        try {
          var r = await login(email ? email.value : '', pass ? pass.value : '');
          if (pass) pass.value = '';
          s = await state();
          render(true);
          if (msg) {
            msg.className = 'ms-gate-msg ok';
            msg.textContent = r.hasRenew
              ? '已登录，7 天内打开插件直接可用。'
              : '已登录；此次没能建立 7 天续期，下次打开需重新登录一次。';
          }
          if (opts && opts.onConnected) opts.onConnected();
        } catch (e) {
          if (msg) { msg.className = 'ms-gate-msg err'; msg.textContent = friendlyError(e.message); }
        } finally {
          btn.disabled = false;
        }
      };
      var passEl = document.getElementById('msGatePassword');
      if (passEl) passEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') btn.click(); });
    }

    var out = document.getElementById('msLogout');
    if (out) {
      out.onclick = async function () {
        await logout();
        s = await state();
        render(false);
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = ''; }
        if (opts && opts.onDisconnected) opts.onDisconnected();
      };
    }

    // 一键登录完成（官网中转页递票据回来）→ 立即刷新闸门为已登录
    window.addEventListener('ms-auth-changed', async function () {
      s = await state();
      render(isConnected(s));
      if (isConnected(s) && opts && opts.onConnected) opts.onConnected();
    });

    var on = isConnected(s);
    render(on);
    return on;
  }

  root.SSAuth = {
    DEFAULT_BASE: DEFAULT_BASE,
    state: state, isConnected: isConnected, login: login, logout: logout,
    renew: renew, validToken: validToken, backendFetch: backendFetch,
    handoff: handoff, mountGate: mountGate, baseOf: baseOf, friendlyError: friendlyError,
  };
})(typeof window !== 'undefined' ? window : this);
