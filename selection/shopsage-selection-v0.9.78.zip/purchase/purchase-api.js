/* ShopSage 采购板块 · 控制页后台桥（独立于「自动化」板块）
 * 本文件只在 purchase/purchase.html 里运行；该页已先加载 ../auth.js（window.SSAuth 就绪）。
 * 作用：1688 上的采购浮窗（content script）不能直接用扩展 Bearer，故把 bind/report/pending
 *      这些官网 /api/purchase/* 调用集中到本控制页，用 SSAuth.backendFetch 发，结果回给浮窗。
 * 板块隔离：与 automation/ 完全独立，互不发消息、各用各的 storage 命名空间（ssPurchase*）。 */
"use strict";

function ssPurchaseBF(path, init) {
  if (!(window.SSAuth && window.SSAuth.backendFetch)) {
    // 控制页刚开、auth.js 还没挂上 SSAuth：给出可读错误，不抛裸 TypeError
    return Promise.reject(new Error("采购控制页鉴权未就绪（SSAuth 未加载）——刷新本页或稍后重试"));
  }
  return window.SSAuth.backendFetch(path, init);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "SS_PURCHASE_API") return; // 只接采购板块的消息
  const op = msg.op, p = msg.payload || {};
  (async () => {
    try {
      if (op === "ping") { sendResponse({ ok: true, ready: true }); return; }

      if (op === "bind") {
        const poId = String(p.poId || "");
        if (!poId) return sendResponse({ ok: false, code: "NO_PO", error: "缺少 poId" });
        const d = await ssPurchaseBF("/api/purchase/bind?poId=" + encodeURIComponent(poId), { method: "GET" });
        sendResponse({ ok: true, data: d });
        return;
      }

      if (op === "report") {
        const poId = String(p.poId || "");
        if (!poId) return sendResponse({ ok: false, code: "NO_PO", error: "缺少 poId" });
        // 9.3：国内段用 domesticTrackingNo/domesticCarrier（推货代用），与平台国际运单号分开；
        //      实付走 paidCostCny（CNY 总额）。同时保留旧字段名兼容。
        const numOrUndef = (v) => (v === "" || v == null || isNaN(Number(v))) ? undefined : Number(v);
        const body = {
          externalOrderNo: (p.externalOrderNo || "").trim() || undefined,
          domesticTrackingNo: (p.domesticTrackingNo || p.trackingNo || "").trim() || undefined,
          domesticCarrier: (p.domesticCarrier || p.carrier || "").trim() || undefined,
          trackingNo: (p.trackingNo || "").trim() || undefined,   // 兼容旧字段
          carrier: (p.carrier || "").trim() || undefined,
          paidCostCny: numOrUndef(p.paidCostCny),                 // 9.3 新增：实付总额 CNY
          unitCostCny: numOrUndef(p.unitCostCny),                 // 手填单价（视为 MANUAL）
          cnTitle: (p.cnTitle || "").trim() || undefined,         // 10.3 中文品名，工作台/货代备注用
          quantity: numOrUndef(p.quantity),
        };
        const d = await ssPurchaseBF("/api/purchase/" + encodeURIComponent(poId) + "/report", {
          method: "POST", body: JSON.stringify(body),
        });
        sendResponse({ ok: true, data: d });
        return;
      }

      if (op === "skuLink") {
        // 9.1：发布成功后上报「平台SKU ↔ 1688 货源SKU」配对。同 (租户,platformSku) 覆盖更新，可多次调。
        const body = {
          platformSku: String(p.platformSku || "").trim(),
          offerId: String(p.offerId || "").trim(),
          sourceSkuId: String(p.sourceSkuId || "").trim(),
          spec: String(p.spec || "").trim(),
          unitCostCny: (p.unitCostCny === "" || p.unitCostCny == null || isNaN(Number(p.unitCostCny))) ? undefined : Number(p.unitCostCny),
          offerUrl: String(p.offerUrl || "").trim(),
          source: String(p.source || "PLUGIN_PUBLISH"),
        };
        if (!body.platformSku) return sendResponse({ ok: false, code: "NO_SKU", error: "缺少 platformSku" });
        const d = await ssPurchaseBF("/api/purchase/sku-link", { method: "POST", body: JSON.stringify(body) });
        sendResponse({ ok: true, data: d });
        return;
      }


      if (op === "pending") {
        const hours = Number(p.hours) || 24;
        const d = await ssPurchaseBF("/api/purchase/pending?hours=" + encodeURIComponent(hours), { method: "GET" });
        sendResponse({ ok: true, data: d });
        return;
      }

      if (op === "forwarders") {
        // 货代（含收件仓库地址）——后端按 tenantId 过滤，天然按账号隔离，绝不跨账号串数据
        const d = await ssPurchaseBF("/api/purchase/forwarders", { method: "GET" });
        sendResponse({ ok: true, data: d });
        return;
      }

      sendResponse({ ok: false, code: "UNKNOWN_OP", error: "未知 op " + op });
    } catch (e) {
      const friendly = (window.SSAuth && window.SSAuth.friendlyError)
        ? window.SSAuth.friendlyError((e && e.message) ? e.message : String(e))
        : String((e && e.message) || e);
      sendResponse({ ok: false, error: friendly });
    }
  })();
  return true; // 异步 sendResponse
});

// 冷启动探针：让浮窗能 ping 到本页是否就绪
document.addEventListener("DOMContentLoaded", () => {});
