/* ShopSage 采购板块 · 1688 浮窗（ISOLATED content script，document_idle）
 * 与「采集」「自动化」两个板块彻底分离：独立 UI（.ss-purchase-*）、独立 storage 命名空间（ssPurchase*）、
 * 只跟本板块的 observer.page.js（window message）和 purchase/purchase.html（chrome.runtime SS_PURCHASE_API）通信。
 * 红线：只在 1688 域；抓不到就手填，绝不猜；不碰支付。 */
(function () {
  "use strict";
  if (window.__ssPurchaseWidgetBound) return;
  window.__ssPurchaseWidgetBound = true;

  // 下单/确认订单/订单类页面识别（1688 + 拼多多，含常见下单主机/路径）
  function orderish(u) {
    return /(buy\.1688\.com|make\.1688\.com|order\.1688\.com|cart\.1688\.com|trade\.1688\.com|makeorder|make_order|smart_make|\/order[\/?._]|\/confirm|\/submit|\/pay|\/receiver|orders\.html|order_list|下单|确认订单)/i.test(u || "");
  }
  // 帧守卫：只在「顶层」或「下单页 iframe」渲染浮窗，避免每个 iframe 各弹一个重复窗口
  const IS_TOP = (window.top === window.self);
  if (!IS_TOP && !orderish(location.href)) return;

  const PO_TTL_MS = 6 * 60 * 60 * 1000;   // session 读不到时，local 兜底 6 小时过期
  let active = null;      // { poId, po, orders:[], autoReport:true }
  let reportedAt = null;
  let el = null;
  let dead = false;       // 扩展重载后旧脚本上下文失效 → 置真，停一切 chrome.* 调用，提示刷新

  // 扩展上下文是否仍有效（重载后 chrome.runtime.id 会变 undefined，再调 sendMessage/storage 就抛 "Extension context invalidated"）
  function alive() { try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; } }
  function markDead() {
    if (dead) return; dead = true;
    if (el) el.innerHTML = '<div class="hd"><span class="ttl">ShopSage 采购</span></div><div class="bd" style="padding:10px;color:#b25a00">扩展已更新，请刷新本 1688 页面后重试。</div>';
  }

  // ── storage：按登录邮箱分键（切换账号彻底隔离，绝不把上一个账号的采购态带过来）──
  function curEmail(cb) {
    if (!alive()) return cb("__dead__");
    try { chrome.storage.local.get(["email"], (s) => cb(((s && s.email) || "__anon__").trim() || "__anon__")); }
    catch (e) { cb("__anon__"); }
  }
  function pkey(email) { return "ssPurchaseActive:" + email; }
  function storeGet(cb) {
    if (!alive()) { markDead(); return cb(null); }
    curEmail((email) => {
      const key = pkey(email);
      try {
        chrome.storage.session.get([key], (s) => {
          if (chrome.runtime.lastError || !s || !s[key]) {
            try { chrome.storage.local.get([key], (l) => cb(l && l[key])); } catch (e) { cb(null); }
          } else cb(s[key]);
        });
      } catch (e) { markDead(); cb(null); }
    });
  }
  function storeSet(v, cb) {
    if (!alive()) { markDead(); return cb && cb(); }
    curEmail((email) => {
      const key = pkey(email);
      const val = v ? { ...v, at: Date.now(), ownerEmail: email } : null;
      try { chrome.storage.session.set({ [key]: val }, () => { void chrome.runtime.lastError; }); } catch (e) {}
      try { chrome.storage.local.set({ [key]: val }, () => { void chrome.runtime.lastError; cb && cb(); }); } catch (e) { markDead(); cb && cb(); }
    });
  }
  // 账号切换：清掉当前内存里的采购态（含 po/收件地址/候选），改读新账号的键——绝不残留上一账号的数据
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.email) {
        const ne = (changes.email.newValue || "__anon__"); const oe = (changes.email.oldValue || "__anon__");
        if (ne !== oe) { active = null; reportedAt = null; if (el) { el.remove(); el = null; } }
      }
    });
  } catch (e) {}


  // ── 调后端：直接发给 service worker（SW 用存储的 Bearer 直接 fetch），不再开任何控制页标签 ──
  async function callApi(op, payload, then) {
    if (!alive()) { markDead(); return then && then({ ok: false, error: "扩展已更新，刷新页面重试" }); }
    const r = await new Promise((res) => {
      try { chrome.runtime.sendMessage({ type: "SS_PURCHASE_API", op, payload }, (resp) => {
        res(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : (resp || { ok: false }));
      }); } catch (e) { markDead(); res({ ok: false, error: "扩展已更新，刷新页面重试" }); }
    });
    then && then(r);
  }

  // ── 渲染浮窗（仿妙手「代发采购」分区：商品信息/订单信息/采购金额/配对/操作；品牌蓝、左侧居中）──
  function render() {
    if (!active || !el) return;
    const o = matchOrders();
    const po = active.po || {};
    const prod = String(po.productName || "").slice(0, 40);
    const spec = String(po.spec || (po.sourceSkuId ? "规格SKU " + po.sourceSkuId : "")).slice(0, 40);
    const unit = (o && o.amount != null) ? o.amount : (po.expectedUnitCostCny != null ? po.expectedUnitCostCny : "");
    const qty = po.quantity || (o ? "" : "");
    const paid = (active.paidCostCny != null ? active.paidCostCny : (o && o.amount != null ? o.amount : ""));
    const rowsFor = (list) => list.map((x, i) => `<label class="opt"><input type="radio" name="sspo" value="${i}" ${i === 0 ? "checked" : ""}> 单号 <b>${esc(x.orderNo || "—")}</b> · ¥${esc(x.amount != null ? x.amount : "?")} · ${esc(x.trackingNo || "无运单")}${x.carrier ? "/" + esc(x.carrier) : ""}</label>`).join("");
    // 货代收货：采购单快照优先，没有就用本账号货代（保证商品/下单页即使没 PO 也能显示可复制的收货地址）
    const st = (po.shipToName || po.shipToAddress)
      ? { fwd: po.shipToForwarder || "", name: po.shipToName || "", phone: po.shipToPhone || "", addr: po.shipToAddress || "" }
      : (active.fwd ? { fwd: active.fwd.name || "", name: active.fwd.contact || "", phone: active.fwd.phone || "", addr: active.fwd.warehouseAddress || "" } : null);
    active._st = st;

    el.innerHTML = `
      <div class="hd"><span class="ttl"><img class="lg" src="${logoUrl()}" alt="ShopSage">ShopSage 采购</span><button type="button" class="min" title="收起">收起</button></div>
      <div class="bd">
        <div class="sec"><div class="sec-t">商品信息</div>
          <div class="kv"><span>名称</span><b>${esc(prod || "—")}</b></div>
          <div class="kv"><span>规格</span><b>${esc(spec || "—")}</b></div>
          <div class="kv"><span>SKU</span><b>${esc((po.skus && po.skus[0]) || po.sourceSkuId || "—")}</b></div>
          <div class="kv"><span>中文品名</span><input name="cnTitle" value="${esc(active.cnTitle || po.cnTitle || "")}" placeholder="货代备注/工作台用"></div>
          ${po.supplierUrl ? `<div class="lnk"><a href="${esc(po.supplierUrl)}" target="_blank">查看货源宝贝</a></div>` : ""}
        </div>
        <div class="sec"><div class="sec-t">订单信息</div>
          <div class="kv"><span>店铺</span><b>${esc(po.shopName || "—")}</b></div>
          <div class="kv"><span>平台订单号</span><b>${esc(po.orderNo || active.poId || "")}</b></div>
          <div class="kv"><span>1688订单号</span><input name="ext" value="${esc(o ? o.orderNo : "")}" placeholder="未抓到·可手填"></div>
          ${po.shipToReason ? `<div class="unlinked">⚠ 本账号还没配货代/无仓库地址（${esc(po.shipToReason)}）。请去「ShopSage → 货代管理」添加并校验凭据后再采购。</div>`
            : (st ? `<div class="kv"><span>货代</span><b>${esc(st.fwd || "—")}</b></div>
           <div class="kv"><span>收件人</span><b>${esc(st.name || "—")}</b></div>
           <div class="kv"><span>电话</span><b>${esc(st.phone || "—")}</b></div>
           <div class="kv"><span>地址</span><b class="addr">${esc(st.addr || "—")}</b></div>
           <div class="lnk"><button type="button" class="copy">复制收件人信息</button> <span class="hint">下单时把这三行填到货源收货地址（货代再发国际；ShopSage 不代付、也不自动推送）</span></div>`
            : `<div class="kv"><span>货代</span><b>${esc(active.fwdErr || "读取中…")}</b></div>`)}
        </div>
        <div class="sec"><div class="sec-t">采购金额（RMB）</div>
          <div class="grid3">
            <div class="num"><label>单价</label><b>¥${esc(unit === "" ? "?" : unit)}</b></div>
            <div class="num"><label>数量</label><b>${esc(qty === "" ? "?" : qty)}</b></div>
            <div class="num"><label>运费</label><b>¥${esc(po.freightCny != null ? po.freightCny : 0)}</b></div>
          </div>
          <div class="kv"><span>实付款</span><input name="paid" value="${esc(paid)}" placeholder="1688 实际付款 ¥"> <small>RMB</small></div>
          <div class="kv"><span>国内快递</span><input name="track" value="${esc(o ? o.trackingNo : "")}" placeholder="未发货可留空"></div>
          <div class="kv"><span>国内承运</span><input name="carrier" value="${esc(o ? o.carrier : "")}" placeholder="如 极兔/中通"></div>
        </div>
        ${po.linked === false ? `<div class="unlinked">⚠ 该 SKU 还没配对，请去「采购工作台 → SKU 配对」补一条再采购（不替你猜价）。</div>` : (po.linked === true ? `<div class="linked">已配对 · 预期采购价 ¥${esc(po.expectedUnitCostCny != null ? po.expectedUnitCostCny : "?")}（${esc(po.costSource || "LINK")}）${po.offerUrl ? ` · <a href="${esc(po.offerUrl)}" target="_blank">打开货源核对</a>` : ""}</div>` : "")}
        ${active.orders && active.orders.length > 1 ? `<details class="cands"><summary>抓到 ${active.orders.length} 条候选，选一个</summary>${rowsFor(active.orders)}</details>` : ""}
        <div class="act">
          <button type="button" class="rep primary">回传</button>
          <label class="auto"><input type="checkbox" class="autoCb" ${active.autoReport ? "checked" : ""}> 自动回传</label>
          <button type="button" class="pend">查待回传</button>
        </div>
        <div class="stat">${esc(statusLine())}</div>
        <div class="warn">付款请你在 1688 自行完成，ShopSage 不代付。</div>
       </div>`;
    wire();
    enableDrag();
  }


  function statusLine() {
    if (active.error) return "⚠ " + active.error;
    if (reportedAt) return "已回传 · " + reportedAt;
    const o = matchOrders();
    if (o && active.autoReport) return "自动匹配到订单，准备回传…";
    if (!o && active.orders && active.orders.length) return "抓到候选，请选一个再回传";
    if (!(active.orders && active.orders.length)) return "等待货源订单数据…（在订单/详情/付款成功页会自动识别）";
    return "";
  }

  // 匹配：按 bound PO 的 offerId/供应商链接 + 金额，从抓到的候选里选最像的一条
  function matchOrders() {
    const list = active.orders || [];
    if (!list.length) return null;
    const supId = offerId(active.po && active.po.supplierUrl);
    const cands = list.filter((x) => (!supId || !x.offerId || x.offerId === supId));
    const pool = cands.length ? cands : list;
    // 唯一 offer 命中 → 直接选；否则交给用户（不猜）
    if (supId) {
      const exact = pool.filter((x) => x.offerId === supId);
      if (exact.length === 1) return exact[0];
    }
    if (pool.length === 1) return pool[0];
    return active._picked || null;   // 用户手选的
  }

  function wire() {
    const $ = (c) => el.querySelector(c);
    const q = (n) => (el.querySelector(`input[name="${n}"]`) || {}).value || "";
    $(".min").onclick = () => { el.classList.toggle("is-mini"); };
    $(".rep").onclick = () => report();
    $(".autoCb").onchange = (e) => { active.autoReport = e.target.checked; storeSet({ poId: active.poId, po: active.po, autoReport: active.autoReport }); if (e.target.checked) maybeAuto(); };
    $(".pend").onclick = () => loadPending();
    const cp = $(".copy"); if (cp) cp.onclick = () => {
      const s = active._st || {}; const txt = [s.name || "", s.phone || "", s.addr || ""].filter(Boolean).join("  ");
      try { navigator.clipboard.writeText(txt).then(() => { active.error = "已复制货代收货信息"; render(); }, () => { active.error = "复制失败，请手动选择"; render(); }); } catch (e) { active.error = "复制不可用"; render(); }
    };
    const cf = $(".copyfwd"); if (cf) cf.onclick = () => {
      const f = active.fwd || {}; const txt = [f.contact || "", f.phone || "", f.warehouseAddress || ""].filter(Boolean).join("  ");
      try { navigator.clipboard.writeText(txt).then(() => { active.error = "已复制货代收货地址"; render(); }, () => { active.error = "复制失败，请手动选择"; render(); }); } catch (e) { active.error = "复制不可用"; render(); }
    };
    el.querySelectorAll('input[name="sspo"]').forEach((r) => { r.onchange = () => { active._picked = active.orders[+r.value]; render(); maybeAuto(); }; });
    ["ext", "track", "carrier", "paid", "cnTitle"].forEach((n) => { const i = el.querySelector(`input[name="${n}"]`); if (i) i.oninput = () => { active._manual = active._manual || {}; active._manual[n] = i.value; }; });
  }

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
  function offerId(u) { const m = /offer\/(\d+)\.html/i.exec(u || "") || /goods_id=(\d+)/i.exec(u || ""); return m ? m[1] : ""; }
  function logoUrl() { try { return chrome.runtime.getURL("assets/shopsage-icon-64.png"); } catch (e) { return ""; } }

  // 取本账号货代（后端按 tenantId 过滤，跨账号不串数据）；AUTHORIZED 优先，其次第一条
  function loadForwarders() {
    callApi("forwarders", {}, (r) => {
      if (r && r.ok) {
        const rows = (r.data && (r.data.rows || (r.data.data && r.data.data.rows))) || [];
        const pick = rows.find((x) => x && x.status === "AUTHORIZED") || rows[0] || null;
        const wh = pick && Array.isArray(pick.warehouses) && pick.warehouses[0] ? pick.warehouses[0] : {};
        active.fwd = pick ? {
          name: pick.name || "",
          contact: pick.contact || wh.contactName || "",
          phone: pick.phone || wh.contactMobile || "",
          warehouseAddress: pick.warehouseAddress || wh.fullAddress || "",
        } : null;
        active.fwdErr = pick ? "" : (rows.length ? "" : "本账号还没配货代");
      } else { active.fwd = null; active.fwdErr = (r && r.error) || "货代读取失败"; }
      render();
    });
  }

  function collect() {
    const $ = (n) => (el.querySelector(`input[name="${n}"]`) || {}).value || "";
    return {
      poId: active.poId,
      externalOrderNo: $("ext"),
      domesticTrackingNo: $("track"),
      domesticCarrier: $("carrier"),
      paidCostCny: $("paid"),
      cnTitle: $("cnTitle"),
      quantity: (active.po && active.po.quantity) || "",
    };
  }

  function report(force) {
    const body = collect();
    if (!body.externalOrderNo && !body.trackingNo) { active.error = "订单号/快递单号至少有一个（抓不到就手填）"; render(); return; }
    active.error = "";
    callApi("report", body, (r) => {
      if (r && r.ok) {
        reportedAt = new Date().toLocaleTimeString();
        active.error = (r.data && r.data.needsRepush) ? "单号已更新，需回网站重新推货代" : "";
        render();
        if (r.data && r.data.po) { active.po = r.data.po; }
      } else { active.error = (r && r.error) || "回传失败"; render(); }
    });
  }

  let autoTriedFor = {};
  function maybeAuto() {
    if (!active || !active.autoReport) return;
    const o = matchOrders();
    if (!o) return;
    const key = (o.orderNo || "") + "|" + (o.trackingNo || "");
    if (!o.orderNo) return;
    if (autoTriedFor[key]) return;       // 同一份数据只自动回传一次（幂等防连点）
    autoTriedFor[key] = 1;
    render();
    setTimeout(() => report(true), 400);
  }

  function loadPending() {
    callApi("pending", { hours: 24 }, (r) => {
      if (!r || !r.ok) { active.error = (r && r.error) || "查询失败"; render(); return; }
      const rows = (r.data && (r.data.rows || r.data.data && r.data.data.rows)) || [];
      active.pendingList = rows;
      active.error = "";
      if (rows.length && !active.po) { pickPending(rows); }
      else if (!rows.length) { active.error = "最近 24h 没有待回传的采购单"; render(); }
      render();
    });
  }
  function pickPending(rows) {
    el && el.insertAdjacentHTML("beforeend", "");
    // 简化：取第一条作为 active.po 继续 bind
    if (rows[0] && rows[0].poId) bindPo(rows[0].poId);
  }

  function bindPo(poId) {
    callApi("bind", { poId }, (r) => {
      if (r && r.ok && r.data && (r.data.ok !== false)) {
        const dd = r.data;
        const base = dd.po || (dd.data && dd.data.po) || dd;   // 9.2：配对字段可能在 data 顶层，也可能并入 po
        active.po = {
          ...base,
          linked: (dd.linked != null ? dd.linked : base.linked),
          offerId: dd.offerId || base.offerId || "",
          sourceSkuId: dd.sourceSkuId || base.sourceSkuId || "",
          offerUrl: dd.offerUrl || base.offerUrl || base.supplierUrl || "",
          expectedUnitCostCny: (dd.expectedUnitCostCny != null ? dd.expectedUnitCostCny : base.expectedUnitCostCny),
          costSource: dd.costSource || base.costSource || "",
          shopName: dd.shopName || base.shopName || "",
          shipToName: dd.shipToName || base.shipToName || "",
          shipToPhone: dd.shipToPhone || base.shipToPhone || dd.phone || base.phone || "",
          shipToAddress: dd.shipToAddress || base.shipToAddress || "",
          freightCny: (dd.freightCny != null ? dd.freightCny : base.freightCny),
          skus: dd.skus || base.skus || [],
        };
        storeSet({ poId, po: active.po, autoReport: active.autoReport });
        render(); maybeAuto(); loadForwarders();
      } else {
        active.error = (r && (r.error || (r.data && r.data.code))) || "PO 绑定失败（不属于当前账号？）";
        render();
      }
    });
  }

  // ── 来自 observer.page.js 的 window message ─────────────────────
  window.addEventListener("message", (ev) => {
    if (dead || !alive()) { markDead(); return; }
    const d = ev.data;
    if (!d || d.__ssP !== 1) return;
    if (d.type === "SS_PURCHASE_PO" && d.poId) {
      if (!active || active.poId !== d.poId) active = { poId: d.poId, po: null, orders: [], autoReport: true };
      show();
      bindPo(d.poId);
    } else if (d.type === "SS_PURCHASE_ORDERS" && Array.isArray(d.orders)) {
      if (!active) active = { poId: (active && active.poId) || "", po: null, orders: [], autoReport: true };
      const before = matchOrders();
      // 合并候选（按 orderNo|tracking 去重保留最新）
      const map = {};
      (active.orders || []).concat(d.orders).forEach((x) => { map[(x.orderNo || "") + "|" + (x.trackingNo || "")] = x; });
      active.orders = Object.values(map);
      show();
      render();
      maybeAuto();
    }
  });

  function ensure() {
    if (el) return el;
    el = document.createElement("div");
    el.className = "ss-purchase-widget";
    document.documentElement.appendChild(el);
    applyPos();
    return el;
  }
  function show() { ensure(); render(); }

  // 自由拖动（展开/收起都能拖），位置记忆到 chrome.storage.local（带失效守卫）
  function applyPos() {
    if (!alive()) return;
    try { chrome.storage.local.get(["ssPurchasePos"], (s) => {
      if (chrome.runtime.lastError) return;
      const p = s && s.ssPurchasePos;
      if (p && el && alive()) {
        const w = el.getBoundingClientRect().width || 320; const h = el.getBoundingClientRect().height || 300;
        const L = Math.max(4, Math.min(parseFloat(p.left) || 16, Math.max(4, window.innerWidth - w - 6)));
        const T = Math.max(4, Math.min(parseFloat(p.top) || 80, Math.max(4, window.innerHeight - h - 6)));
        el.style.left = L + "px"; el.style.top = T + "px"; el.style.bottom = "auto"; el.style.transform = "none";
      }
    }); } catch (e) {}
  }
  function savePos() {
    if (!alive() || !el) return;
    try { const r = el.getBoundingClientRect(); chrome.storage.local.set({ ssPurchasePos: { left: Math.round(r.left) + "px", top: Math.round(r.top) + "px" } }, () => { void chrome.runtime.lastError; }); } catch (e) {}
  }
  function enableDrag() {
    const hd = el && el.querySelector(".hd"); if (!hd) return;
    hd.style.cursor = "move";
    hd.onmousedown = (e) => {
      if (e.target.closest("button")) return;
      const r = el.getBoundingClientRect(); const dx = e.clientX - r.left, dy = e.clientY - r.top;
      const mv = (ev) => { const rr = el.getBoundingClientRect(); el.style.left = Math.max(4, Math.min(ev.clientX - dx, window.innerWidth - rr.width - 6)) + "px"; el.style.top = Math.max(4, Math.min(ev.clientY - dy, window.innerHeight - rr.height - 6)) + "px"; el.style.bottom = "auto"; el.style.transform = "none"; };
      const up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); savePos(); };
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); e.preventDefault();
    };
  }

  // 当前货源 id（1688 offer / 拼多多 goods_id）
  function currentSourceId() { const m = /offer\/(\d+)/i.exec(location.href) || /goods_id=(\d+)/i.exec(location.href); return m ? m[1] : ""; }
  function isProductPage() { return /(detail\.1688\.com\/offer\/|goods_id=|mobile\.yangkeduo\.com\/goods|\/goods\.html)/i.test(location.href); }
  // 主动关联：按当前货源匹配一个待回传采购单，命中就认领并显示；下单页没精确命中则取最近一条
  function autoMatchPending() {
    callApi("pending", { hours: 720 }, (r) => {
      const rows = (r && r.ok && r.data && (r.data.rows || (r.data.data && r.data.data.rows))) || [];
      const sid = currentSourceId();
      let hit = null;
      if (sid) hit = rows.find((x) => { const u = (x.supplierUrl || x.offerUrl || ""); const m = /offer\/(\d+)/i.exec(u) || /goods_id=(\d+)/i.exec(u); return m && m[1] === sid; });
      if (hit) { active = { poId: String(hit.poId || hit.id || ""), po: null, orders: [], autoReport: true }; show(); bindPo(active.poId); }
      else if (orderish(location.href)) { active = { poId: "", po: null, orders: [], autoReport: true, pendingList: rows }; show(); }
      // 商品页但无匹配 PO → 不打扰、不显示
    });
  }

  // 启动：① 有活动 PO 直接恢复；② 否则在商品/下单页尝试按货源主动关联待回传单并显示。
  storeGet((v) => {
    if (v && v.poId && (!v.at || Date.now() - v.at < PO_TTL_MS)) {
      active = { poId: v.poId, po: v.po || null, orders: [], autoReport: v.autoReport !== false };
      show();
      bindPo(v.poId);
    } else if (isProductPage() || orderish(location.href)) {
      // 商品详情页(有“立即下单”)或下单/订单页：显示采购浮窗；搜索/首页不打扰
      active = { poId: "", po: null, orders: [], autoReport: true };
      show();
      loadForwarders();
      autoMatchPending();
    }
  });
})();
