// content/inbox-publisher.content.js
// 注入 www.shopsage.cc/selection/inbox（官网采集箱）。由插件 automation 控制器经
// chrome.tabs.sendMessage 驱动，模仿真人在「编辑商品」抽屉里走完发布。
//
// 依据 2026-11-24 线上实测（PetKiss Shop / TH）：
//   · 抽屉按钮：一键翻译 / 生成英文全球标题 / AI 优化标题 / 编辑 HTML 源码 / AI 润色
//              / 发布前检查 / 发布到 TikTok / 保存修改 / 查看将提交的报文
//   · 英文标题输入框 placeholder：「只许英文字符，25–255 个」
//   · 成稿标题 textarea placeholder：「点右侧「一键翻译」生成，或直接手写；可反复改」
//   · 检查通过时页面出现「检查通过，可以发布」；未齐时出现「必填项已齐…」（反义）或列缺项
//   · 发布前必须勾两个 checkbox：<label>「只建草稿，不送审…」</label>
//                                <label>「我确认：这会在 TikTok 建出真实商品…」</label>
//     未勾时「发布到 TikTok」保持 disabled —— 这就是发布闸门的真实形态。
//   · ⚠️ 发布接口 HTTP 200 ≠ 发布成功。平台会在响应体里回错误，页面显示
//     「发布没成功 …… TikTok 接口调用失败｜平台原话：…」。
//   · 2026-11-24 端到端实测（test@shopsage.cc / PetKiss Shop / TH）跑出的两处平台硬拦，缺一不可：
//       ① description 含中文 → Policy Violation: product description must not contain Chinese language characters
//       ② SKU 规格名含中文 → Invalid Parameter: sale_attribute_value_name received `海星小鱼`,
//          but Chinese characters are not allowed
//     两处都清洗并「保存修改」落库后，真发布成功：商品 ID 1738726293117568899，
//     request_id 202611241021504B0D3548C03C0819E4E4，上传 4 张图。
//   · 英文标题 / SKU 有无 / 仓库 / 类目属性 实测都不拦（必填项齐时闸门自己就过了）。
//   · 已发布条目自动跳过 + 角标「已发布」，绝不重复发。
(() => {
  if (window.__ssInboxPubBound) return;
  window.__ssInboxPubBound = true;

  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms | 0)));
  const btn = (re) => [...document.querySelectorAll("button,[role=\"button\"]")]
    .find((e) => re.test(norm(e.textContent)));
  const CN = /[\u4e00-\u9fa5]/;

  const enTitleInput = () => [...document.querySelectorAll("input")]
    .find((e) => /只许英文/.test(e.placeholder || ""));
  const thTitleArea = () => [...document.querySelectorAll("textarea")]
    .find((e) => /一键翻译/.test(e.placeholder || ""));

  function setReactValue(el, v) {
    const proto = el.tagName === "TEXTAREA"
      ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const d = Object.getOwnPropertyDescriptor(proto, "value");
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // 抽屉里的落库动作 —— 实测真按钮文案是「保存修改」（不是「保存」）。
  // 不点它，描述/SKU 的清洗只停在 DOM 里，提交报文仍取服务端的旧值 → 照样被平台拒。
  async function saveDrawer() {
    const s = btn(/^保存修改$/) || btn(/保存源码|保存描述/) || btn(/^(应用|确定)$/);
    if (!s) return { ok: false, error: "没有「保存修改」按钮（页面改版？）" };
    if (s.disabled) return { ok: false, error: "「保存修改」当前不可点" };
    s.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    await sleep(1500);
    return { ok: true, by: norm(s.textContent) };
  }

  // ── 1. 英文标题：缺就点「生成英文全球标题」，等它填进来（不自己编标题）
  async function ensureEnglishTitle(waitMs) {
    const inp = enTitleInput();
    if (!inp) return { ok: false, error: "没找到英文标题框（页面改版？）" };
    if (norm(inp.value).length >= 25 && !CN.test(inp.value)) {
      return { ok: true, had: true, title: inp.value.slice(0, 120) };
    }
    const g = btn(/生成英文全球标题/);
    if (!g) return { ok: false, error: "没有「生成英文全球标题」按钮" };
    g.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    const t0 = Date.now();
    while (Date.now() - t0 < (waitMs || 45000)) {
      await sleep(1000);
      const v = norm(enTitleInput() ? enTitleInput().value : "");
      if (v.length >= 25 && !CN.test(v)) return { ok: true, had: false, title: v.slice(0, 120) };
    }
    return { ok: false, error: "生成英文标题超时" };
  }

  // ── 2. 描述去中文：实测硬拦之一（TikTok: description must not contain Chinese）
  //    走真人的路：点「编辑 HTML 源码」→ 源码框里剥中文（保留 <img>）→ 点「保存修改」落库。
  //    ⚠️ 2026-11-24 实测：描述存在服务端，不点「保存修改」清洗就白做
  //    （落库走 PATCH /api/extension/inbox/:id；我上一版匹配的是「保存」，真按钮文案是「保存修改」）。
  function stripChineseFromHtml(html) {
    let out = String(html || "");
    const before = (out.match(/[\u4e00-\u9fa5]+/g) || []).length;
    // 属性值里的中文（如 title="预览状态下无法点击…"、alt="白色"）→ 清空该属性值
    out = out.replace(/(\b(?:title|alt|placeholder)\s*=\s*["'])(?:[^"'])*(["'])/gi,
      (m, a, b) => (CN.test(m) ? a + b : m));
    // 标签之间的中文文本 → 删（图片/布局不动）
    out = out.replace(/>([^<>]*)</g, (m, txt) => (CN.test(txt) ? ">" + txt.replace(/[\u4e00-\u9fa5\u3000-\u303f\uff00-\uffef]+/g, "") + "<" : m));
    // 兜底：残留散中文字符
    out = out.replace(/[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]+/g, "");
    return { html: out.replace(/\s{2,}/g, " ").trim(), removed: before };
  }

  async function cleanDescription(waitMs) {
    const e = btn(/编辑\s*HTML\s*源码/);
    if (!e) return { ok: false, skipped: true, error: "没有「编辑 HTML 源码」入口，跳过描述清洗" };
    e.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    let ta = null;
    const t0 = Date.now();
    while (Date.now() - t0 < (waitMs || 8000)) {
      ta = [...document.querySelectorAll("textarea")].find((x) => /<img|<div|offer_details/i.test(x.value || ""));
      if (ta) break;
      await sleep(400);
    }
    if (!ta) return { ok: false, error: "HTML 源码框没出现（改版了？）" };
    const cur = ta.value || "";
    if (!CN.test(cur)) return { ok: true, removed: 0 };
    const r = stripChineseFromHtml(cur);
    setReactValue(ta, r.html);
    await sleep(300);
    const sv = await saveDrawer();
    if (!sv.ok) return { ok: false, error: "描述已清洗但没落库：" + sv.error, removed: r.removed };
    const still = [...document.querySelectorAll("textarea")].find((x) => /<img|<div/i.test(x.value || ""));
    const left = still ? CN.test(still.value || "") : false;
    return { ok: !left, removed: r.removed, savedBy: sv.by };
  }

  // ── 2b. SKU 规格名去中文：实测硬拦之二
  //    平台原话：Invalid Parameter. Parameter `sale_attribute_value_name` received `海星小鱼`,
  //    but Chinese characters are not allowed. → 规格值含中文，整单被拒。
  //    插件侧没有逐 SKU 翻译入口（「一键翻译」实测 500），所以这里用 ASCII 兜底名 + 长文本截断，
  //    保证「能发出去」；想保留原意请后端把 /translate 修好再接。
  async function cleanSkuSpecs(maxLen) {
    const cap = Math.min(Math.max(Number(maxLen) || 30, 3), 60);
    const ins = [...document.querySelectorAll("input")].filter((e) => /填实际规格/.test(e.placeholder || ""));
    if (!ins.length) return { ok: true, changed: 0, note: "没有可编辑的 SKU 规格框" };
    let changed = 0;
    ins.forEach((e, i) => {
      const v0 = String(e.value || "");
      if (!v0 && !CN.test(v0)) return;
      let v = v0.replace(/[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]+/g, " ").replace(/\s+/g, " ").trim()
                .replace(/^[-_/\s]+|[-_/\s]+$/g, "");
      const ascii = (v.match(/[A-Za-z0-9]/g) || []).length;
      // 纯中文、或剥完只剩标点 → 用 ASCII 兜底名（别留 "/XL" 这种垃圾进平台）
      if (CN.test(v0) && ascii < 2) v = "Spec " + (i + 1);
      if (!v) v = "Spec " + (i + 1);
      if (v.length > cap) v = v.slice(0, cap).replace(/[\s_-]+$/, ""); // 过长截断（你要求的）
      if (v !== v0) { setReactValue(e, v); changed++; }
    });
    if (!changed) return { ok: true, changed: 0 };
    await sleep(300);
    const sv = await saveDrawer();
    return { ok: sv.ok, changed, savedBy: sv.by, error: sv.ok ? "" : sv.error };
  }

  // ── 3. 发布前检查 + 读结论（不能只点不看）
  //    ⚠️ 抽屉里有常驻帮助文案「…缺一项平台就整单拒收」，宽泛的「缺」字模式会误判成失败。
  //    只认明确的闸门语句。
  const PASS_RE = /检查通过[，,]?\s*可以发布|可以发布/;
  const FAIL_RE = /发布没成功|检查未通过|必填项未齐|暂不能发布|无法发布|缺以下必填|缺少的必填项|还有\d+项未填/;
  async function runChecks(timeoutMs) {
    const c = btn(/^发布前检查$/);
    if (!c) return { ok: false, error: "没有「发布前检查」按钮" };
    c.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    const t0 = Date.now();
    while (Date.now() - t0 < (timeoutMs || 30000)) {
      await sleep(900);
      const t = norm(document.body.innerText || "");
      if (PASS_RE.test(t)) return { ok: true, verdict: "检查通过，可以发布" };
      if (FAIL_RE.test(t)) {
        const m = t.match(FAIL_RE);
        return { ok: false, verdict: String(m && m[0] || "").slice(0, 120) };
      }
    }
    return { ok: false, error: "检查超时无结论（别当通过）" };
  }

  // ── 4. 勾两道确认（草稿优先），再核发布按钮是否亮起
  async function armPublish(opts) {
    const wantDraft = opts && opts.draftOnly !== false;
    let draftTicked = false;
    [...document.querySelectorAll("input[type=\"checkbox\"],[role=\"checkbox\"]")].forEach((c) => {
      const l = c.closest("label");
      const txt = norm(l ? l.innerText : "");
      if (/只建草稿/.test(txt)) {
        if (wantDraft && !(c.checked || c.getAttribute("aria-checked") === "true")) l.click();
        draftTicked = !!(c.checked || c.getAttribute("aria-checked") === "true");
      }
      if (/我确认/.test(txt) && !(c.checked || c.getAttribute("aria-checked") === "true")) l.click();
    });
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      const p = btn(/^发布到\s*TikTok$/);
      if (p && !p.disabled && p.getAttribute("aria-disabled") !== "true") return { ok: true, draftOnly: draftTicked };
      await sleep(400);
    }
    const p2 = btn(/^发布到\s*TikTok$/);
    return { ok: false, error: "发布按钮仍禁用", stillDisabled: p2 ? !!p2.disabled : "no-btn" };
  }

  // ── 5. 点发布 + 读回执。HTTP/点击不等于成功：必须看页面回执文本。
  async function publishAndWait(opts) {
    const p = btn(/^发布到\s*TikTok$/);
    if (!p) return { ok: false, error: "没有「发布到 TikTok」按钮" };
    if (p.disabled || p.getAttribute("aria-disabled") === "true") {
      return { ok: false, error: "发布按钮禁用：先跑检查并勾「我确认」" };
    }
    p.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    const t0 = Date.now();
    // 页面回执最多等 18 秒；拿不到（发布跳转/冻结）就返回 clicked，由控制页后端轮询这条 inbox 状态作权威判定，
    // 不再死等 90 秒把 executeScript/控制页卡在导航上。
    const limit = Math.min((opts && opts.timeoutMs) || 90000, 18000);
    while (Date.now() - t0 < limit) {
      await sleep(1200);
      const t = norm(document.body.innerText || "");
      const fail = t.match(/发布没成功[^\n]{0,300}|平台原话[^\n]{0,300}|Policy Violation[^\n]{0,300}|TikTok 接口调用失败[^\n]{0,300}/);
      if (fail) return { ok: false, platformError: fail[0].slice(0, 260) };
      // 成功只认明确回执；「已发布」三个字在列表卡片上是常驻文本，绝不能当成功信号
      if (/发布成功|已在平台创建商品|草稿已创建|创建成功/.test(t)) {
        const productId = (t.match(/已在平台创建商品\s*([0-9]{10,})/) || [])[1] || (t.match(/商品\s*ID[^\d]{0,6}(\d{10,})/) || [])[1] || "";
        const requestId = (t.match(/request_id[：:]\s*([A-Z0-9]{12,})/i) || [])[1] || "";
        const imgs = (t.match(/上传到平台的图片\s*(\d+)\s*张/) || [])[1] || "";
        return { ok: true, productId, requestId, images: imgs, draftOnly: !!(opts && opts.draftOnly !== false),
          receipt: (t.match(/.{0,30}(发布成功|已建草稿|草稿已创建|创建成功).{0,90}/) || [""])[0] };
      }
    }
    return { ok: false, clicked: true, error: "已点发布，页面18秒内无明确回执，转后端状态确认" };
  }

  async function openEditor(titleHint) {
    const editBtns = [...document.querySelectorAll("button,a,[role=\"button\"]")]
      .filter((b) => /^编辑商品$/.test(norm(b.textContent)));
    if (!editBtns.length) return { ok: false, error: "列表里没有「编辑商品」" };
    let target = editBtns[0];
    if (titleHint) {
      const hint = String(titleHint).slice(0, 24);
      target = editBtns.find((b) => {
        let c = b;
        for (let d = 0; d < 10 && c; d++) { c = c.parentElement; if (c && norm(c.textContent).includes(hint)) break; }
        if (!c) return false;
        // 只选「未发布」的匹配条目：本轮自动化新采同步进去的就是未发布；
        // 你手动采的、已发布/已填好的同名条目一律跳过，绝不误发你的。
        if (/已发布/.test(norm(c.textContent))) return false;
        return true;
      }) || null;
      if (!target) return { ok: false, error: "没找到标题含「" + hint + "」的未发布条目（已发布的已跳过）" };
    }
    target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window }));
    const t0 = Date.now();
    while (Date.now() - t0 < 12000) {
      await sleep(300);
      if (btn(/^发布到\s*TikTok$/)) return { ok: true };
    }
    return { ok: false, error: "抽屉没打开（发布按钮未出现）" };
  }

  // ── 列表：状态解析 + 已发布过滤 + 角标
  function cardOf(b) {
    let c = b;
    for (let d = 0; d < 10 && c; d++) { c = c.parentElement; if (c && /已发布|待评估|待发布|已入围|待同步/.test(norm(c.textContent))) break; }
    return c;
  }
  function cardTitle(t) {
    return String(t || "").replace(/^(已发布|待评估|待发布|已入围|待同步)\s*/, "")
      .split(/\s*(?:1688|拼多多|查看原商品|采购价)/)[0].trim().slice(0, 60);
  }
  // 我们这轮自己发成功的，也记下来，状态没刷新也不会重发
  const publishedByUs = window.__ssPublishedByUs || (window.__ssPublishedByUs = new Set());

  // 台账注入：控制器把「我们已发过的标题」灌进来（站点列表状态实测会滞后，不能只信文案）
  function seedPublished(titles) {
    (titles || []).forEach((t) => { if (t) publishedByUs.add(String(t).slice(0, 60)); });
    return { ok: true, known: publishedByUs.size };
  }

  function markBadges() {
    [...document.querySelectorAll("button,a,[role=\"button\"]")]
      .filter((b) => /^编辑商品$/.test(norm(b.textContent))).forEach((b) => {
        const c = cardOf(b); if (!c) return;
        const t = norm(c.textContent);
        const done = /已发布/.test(t) || publishedByUs.has(cardTitle(t));
        c.style.position = c.style.position || "relative";
        let tag = c.querySelector(":scope > .sspub-badge");
        if (done && !tag) {
          tag = document.createElement("span");
          tag.className = "sspub-badge";
          tag.textContent = "已发布";
          tag.setAttribute("style", "position:absolute;top:6px;right:6px;z-index:9;background:#0a8a4a;color:#fff;font-size:11px;line-height:1;padding:4px 7px;border-radius:6px;font-family:MiSans,system-ui,sans-serif;");
          c.appendChild(tag);
        } else if (!done && tag) { tag.remove(); }
      });
    return { ok: true, badges: document.querySelectorAll(".sspub-badge").length };
  }

  function isPublishedCard(titleHint) {
    if (!titleHint) return false;
    const hit = [...document.querySelectorAll("button,a,[role=\"button\"]")]
      .filter((b) => /^编辑商品$/.test(norm(b.textContent)))
      .map((b) => cardOf(b))
      .find((c) => c && norm(c.textContent).includes(String(titleHint).slice(0, 24)));
    // 卡片找不到（例如发布后页面跳进了详情页）→ 不能因此判定"未发布"而重发
    if (!hit) return publishedByUs.has(String(titleHint).slice(0, 60));
    const t = norm(hit.textContent);
    return /已发布/.test(t) || publishedByUs.has(cardTitle(t)) || publishedByUs.has(String(titleHint).slice(0, 60));
  }

  function listItems() {
    const out = [];
    [...document.querySelectorAll("button,a,[role=\"button\"]")]
      .filter((b) => /^编辑商品$/.test(norm(b.textContent))).forEach((b) => {
        const c = cardOf(b);
        const t = norm(c ? c.textContent : "");
        const status = (t.match(/已发布|待评估|待发布|已入围|待同步/) || [""])[0];
        const title = cardTitle(t);
        out.push({ status, published: status === "已发布" || publishedByUs.has(title), title, snip: t.slice(0, 60) });
      });
    return { ok: true, url: location.href, items: out };
  }

  function numbers() {
    const en = enTitleInput(), th = thTitleArea();
    const price = [...document.querySelectorAll("input")].find((e) => /填了才算利润/.test(e.placeholder || ""));
    const disc = [...document.querySelectorAll("input")].find((e) => /打4折|折/.test(e.placeholder || ""));
    const sku = [...document.querySelectorAll("input")].filter((e) => /填实际规格/.test(e.placeholder || "")).map((e) => e.value);
    const cur = [...document.querySelectorAll("select")].map((s) => s.value).filter((v) => /THB|USD|VND|MYR|IDR|PHP|SGD|CNY/.test(v))[0] || "";
    return { ok: true, enTitle: en ? en.value.slice(0, 120) : "", thTitle: th ? th.value.slice(0, 60) : "",
      sellPrice: price ? price.value : "", discount: disc ? disc.value : "", currency: cur, skuSpecs: sku, skuCount: sku.length };
  }

  // 自动预填发布必填（分层：货源已带 / 平台自动 / 店铺默认）。把"补一项冒一项"的必填一次性填上。
  // o.defaults = 控制页读「发布默认设置」(店铺层A/B) 传来：{stockQty, weightKg, dims:{l,w,h}, brand, warehouse}
  async function fillPublishDefaults(o) {
    const D = (o && o.defaults) || {};
    const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
    const set = (el, v) => { const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value"); if (d && d.set) d.set.call(el, v); else el.value = v; el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
    const done = {}, miss = {};
    // 1) 库存：库存批量框（应用到全部 SKU 行）
    const stockBatch = [...document.querySelectorAll("input")].find((e) => /应用到全部行/.test(e.placeholder || ""));
    if (stockBatch) { set(stockBatch, String(D.stockQty || 100)); done.stock = true; } else miss.stock = "无库存批量框";
    // 2) 品牌：默认无品牌（或店铺默认品牌）
    const brandSel = [...document.querySelectorAll("select")].find((s) => s.options && [...s.options].some((op) => /无品牌/.test(op.text)));
    if (brandSel) { const want = D.brand ? [...brandSel.options].find((op) => op.text.includes(D.brand)) : null; const opt = want || [...brandSel.options].find((op) => /无品牌/.test(op.text)); if (opt) { brandSel.value = opt.value; brandSel.dispatchEvent(new Event("change", { bubbles: true })); } done.brand = opt ? (want ? D.brand : "无品牌") : "未选"; } else miss.brand = "无品牌下拉";
    // 3) 平台类目：未选则点现成「AI 自动定位」
    if (/店铺与类目选好后/.test(norm(document.body.innerText || ""))) {
      const ai = [...document.querySelectorAll("button,[role=button]")].find((b) => /AI\s*自动定位/.test(norm(b.textContent)));
      if (ai) { ai.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window })); await sleep(9000); done.category = "AI定位"; } else miss.category = "无AI自动定位按钮";
    } else done.category = "已选";
    // 4) 重量：优先用货源「重量（g）：NN」换算 kg，否则店铺默认
    const gMatch = (document.body.innerText || "").match(/重量（g）[：:]\s*(\d+)/);
    const kgInput = [...document.querySelectorAll("input")].find((e) => /800\s*克|千克|（kg）|\(kg\)/i.test(e.placeholder || ""));
    if (kgInput && !norm(kgInput.value)) { const kg = gMatch ? Number(gMatch[1]) / 1000 : (Number(D.weightKg) || 0.5); set(kgInput, String(kg || 0.5)); done.weight = gMatch ? gMatch[1] + "g→kg" : "default"; } else if (kgInput) done.weight = "已填"; else miss.weight = "无kg框";
    // 5) 包装长/宽/高：店铺默认（货源若带件重尺更好，先按默认填，缺则记 miss 让检查暴露）
    const dimInputs = [...document.querySelectorAll("input")].filter((e) => /^(长|宽|高)/.test(norm(e.placeholder)) || (/包装/.test(norm((e.closest("label") || e.parentElement || {}).innerText || "")) && /cm/.test(e.placeholder || "")));
    const dv = [D.dims && D.dims.l, D.dims && D.dims.w, D.dims && D.dims.h, 20, 15, 10];
    let di = 0; dimInputs.forEach((e) => { if (!norm(e.value) && di < 3) { set(e, String(dv[di] != null ? dv[di] : [20, 15, 10][di])); di++; } });
    if (di > 0) done.dims = di + "项"; else if (dimInputs.length) done.dims = "已填"; else miss.dims = "无包装尺寸框";
    // 遍历每个 SKU 行填必填（实测列序：0货源价 1本地展示价※ 2库存※ 3重量kg 4长 5宽 6高）——多规格商品必填大头在这
    const sell0 = (() => { const p = [...document.querySelectorAll("input")].find((e) => /填了才算利润/.test(e.placeholder || "")); return p && p.value ? p.value : ""; })();
    let skuRows = 0, skuFilled = 0;
    [...document.querySelectorAll("tbody tr")].forEach((r) => {
      const ins = [...r.querySelectorAll("input")]; if (ins.length < 7) return; skuRows++;
      const cols = [[1, sell0], [2, String(D.stockQty || 100)], [3, String(D.weightKg || 0.5)], [4, String((D.dims && D.dims.l) || 20)], [5, String((D.dims && D.dims.w) || 15)], [6, String((D.dims && D.dims.h) || 10)]];
      cols.forEach(([idx, val]) => { if (val && !norm(ins[idx] && ins[idx].value)) { set(ins[idx], val); skuFilled++; } });
    });
    done.skuRows = skuRows + "行/" + skuFilled + "格";
    // 保存落库
    const sv = [...document.querySelectorAll("button,[role=button]")].find((b) => /^保存修改$/.test(norm(b.textContent)));
    if (sv && !sv.disabled) { sv.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: false, view: window })); await sleep(1200); }
    return { ok: true, done, miss };
  }

  // 一条搞定：真人序列 = 开抽屉 → 英文标题 → 描述去中文(落库) → SKU去中文/截断(落库) → 自动预填必填 → 检查 → 勾确认 → 发布读回执
  async function publishOne(o) {
    const steps = [];
    if (isPublishedCard(o.titleHint)) { return { ok: false, skipped: true, stage: "已发布", error: "这条已是「已发布」，跳过不再重复发" }; }
    const op = await openEditor(o.titleHint); steps.push(["开抽屉", op]);
    if (!op.ok) return { ok: false, stage: "开抽屉", error: op.error, steps };
    const en = await ensureEnglishTitle(o.enWaitMs || 45000); steps.push(["英文标题", en]);
    if (!en.ok) return { ok: false, stage: "英文标题", error: en.error, steps, numbers: numbers() };
    const cl = await cleanDescription(); steps.push(["描述去中文", cl]);
    if (!cl.ok && !cl.skipped) return { ok: false, stage: "描述去中文", error: cl.error, steps };
    const sk = await cleanSkuSpecs(o.skuMax || 30); steps.push(["SKU去中文/截断", sk]);
    if (!sk.ok) return { ok: false, stage: "SKU去中文", error: sk.error, steps };
    const fd = await fillPublishDefaults(o); steps.push(["自动预填必填", fd]);
    const ck = await runChecks(); steps.push(["发布前检查", ck]);
    if (!ck.ok) return { ok: false, stage: "发布前检查", error: ck.error || ck.verdict, steps, numbers: numbers() };
    const arm = await armPublish({ draftOnly: o.draftOnly !== false }); steps.push(["勾确认", arm]);
    if (!arm.ok) return { ok: false, stage: "勾确认", error: arm.error, steps };
    const pub = await publishAndWait({ draftOnly: o.draftOnly !== false, timeoutMs: o.timeoutMs || 120000 });
    steps.push(["发布回执", pub]);
    if (pub.ok && o.titleHint) { publishedByUs.add(String(o.titleHint).slice(0, 60)); try { markBadges(); } catch (e) {} }
    return { ok: pub.ok, stage: "发布", numbers: numbers(), title: en.title,
      productId: pub.productId, requestId: pub.requestId, images: pub.images,
      error: pub.error || pub.platformError, platformError: pub.platformError, receipt: pub.receipt, steps };
  }

  // 暴露给控制页：发布走 chrome.scripting.executeScript 即时注入调用（穿透后台标签 bfcache 冻结），
  // 不再用 chrome.tabs.sendMessage 的长消息端口（实测控制页/采集箱页后台被冻结时端口关闭、收不到回执）。
  window.__ssPublishOne = publishOne;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // 只处理本模块的 ss* 消息；其它类型（尤其浮窗↔控制页的 SS_AUTO_CTRL）绝不 return true，否则会吞掉那条通道
    if (!msg || typeof msg.type !== "string" || msg.type.slice(0, 2) !== "ss") return;
    (async () => {
      try {
        if (!msg) return sendResponse({ ok: false, error: "空消息" });
        if (msg.type === "ssList") return sendResponse(listItems());
        if (msg.type === "ssOpenEditor") return sendResponse(await openEditor(msg.titleHint));
        if (msg.type === "ssNumbers") return sendResponse(numbers());
        if (msg.type === "ssChecks") return sendResponse(await runChecks());
        if (msg.type === "ssCleanDesc") return sendResponse(await cleanDescription());
        if (msg.type === "ssCleanSku") return sendResponse(await cleanSkuSpecs(msg.skuMax));
        if (msg.type === "ssMarkBadges") return sendResponse(markBadges());
        if (msg.type === "ssSeedPublished") return sendResponse(seedPublished(msg.titles));
        if (msg.type === "ssArm") return sendResponse(await armPublish({ draftOnly: msg.draftOnly !== false }));
        if (msg.type === "ssPublish") return sendResponse(await publishAndWait({ draftOnly: msg.draftOnly !== false }));
        if (msg.type === "ssPublishOne") return sendResponse(await publishOne(msg));
        sendResponse({ ok: false, error: "未知类型 " + msg.type });
      } catch (err) { sendResponse({ ok: false, error: String((err && err.message) || err) }); }
    })();
    return true;
  });

  // 角标：进页面先打一遍，列表重渲染后补打（节流，不常驻高频）
  try {
    markBadges();
    let bt = 0;
    new MutationObserver(() => {
      const n = Date.now();
      if (n - bt < 1500) return;
      bt = n;
      setTimeout(() => { try { markBadges(); } catch (e) {} }, 300);
    }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
})();
