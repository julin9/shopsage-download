/* automation/automation.js — 控制器（隐藏 automation.html tab）。真·流水线：
 *   每个关键词一批：走 1688 搜索框(正确编码)采集 N 个 → 同步这 N 个(按目标毛利率反推售价+浮动) → 发布这 N 个 → 下一批。
 *   绝不重复：只处理本轮新采到的、且用 url 精确匹配 + 同步后打 syncedToInboxId 标记。
 * 复用现成：capture.js/MS_CAPTURE、MSStore、library 的 sync()/SS_RULES.suggestPrice、采集箱发布按钮。 */
"use strict";
const $ = (id) => document.getElementById(id);
const state = { running:false, paused:false, cycle:0, nCollect:0, nSync:0, nPublish:0, nPrepared:0, cfg:null, panelTabId:null, email:"", hasSession:false, log:[] };
// 稳定性：循环进度持久化到 chrome.storage，控制页被丢弃/重载后能自动续跑，不再"只采集没填完"
const RUNKEY = "ssAutoRun";
function persistRun(){ try{ chrome.storage.local.set({ [RUNKEY]: { running:state.running, paused:state.paused, cycle:state.cycle, nPrepared:state.nPrepared, cfg:state.cfg, at:Date.now() } }); }catch(e){} }
let libTabId = null, boxTabId = null;

const sleep = (ms)=>new Promise(r=>setTimeout(r,Math.max(0,ms|0)));
const r2 = (n)=>Number.isFinite(n)?Math.round(n*100)/100:null;
function log(m){ state.log.push(`[${new Date().toLocaleTimeString()}] ${m}`); if(state.log.length>500)state.log.shift(); const l=$("log"); if(l){l.textContent=state.log.join("\n");l.scrollTop=1e9;} }
function alive(id){return new Promise(r=>{if(id==null)return r(false);chrome.tabs.get(id,t=>r(!chrome.runtime.lastError&&!!t));});}
function openTab(o){return new Promise(r=>chrome.tabs.create(o,t=>r(t)));}
function closeTab(id){chrome.tabs.remove(id).catch(()=>{});}
function complete(id,to=25000){const t0=Date.now();return (async()=>{while(Date.now()-t0<to){const s=await new Promise(r=>chrome.tabs.get(id,t=>r(chrome.runtime.lastError?"x":t&&t.status)));if(s==="complete"){await sleep(900);return;}await sleep(400);}})();}
function send(tabId,msg){return new Promise(r=>{try{chrome.tabs.sendMessage(tabId,msg,resp=>r(chrome.runtime.lastError?{ok:false,error:chrome.runtime.lastError.message}:resp));}catch(e){r({ok:false,error:String(e)});}});}
function inj(tabId,func,args){return chrome.scripting.executeScript({target:{tabId},func,args:args||[]}).then(r=>r&&r[0]&&r[0].result).catch(()=>null);}

// ── 登录态单一真源（修「一直显示未登录」根因）──────────────────────────
// 面板「已登录」只认 state.email；而 state.email 旧版仅在 collectBatch 里赋值一次。
// 结果：①「信息填好存后台/只上传发布」模式（publishExisting）根本不走 collectBatch → 永远未登录；
//       ② 采集模式在 claimHistory/ensureLoginEmail/search1688（十几秒）期间也不刷新 → 持续未登录；
//       ③ 采集/弹窗按 accessToken 判登录，自动化按 email 判，两套不同源。
// 统一做法：任何状态读取/每个动作开跑前，都从 storage 现取 email，取不到再让 SW 用现有 Bearer 回填一次。
async function hasSession(){ try{ const s=await chrome.storage.local.get({accessToken:"",refreshToken:""}); return !!(s&&(s.accessToken||s.refreshToken)); }catch(e){ return false; } }
async function currentStoreEmail(){ try{ return (await window.MSStore.currentEmail())||""; }catch(e){ return ""; } }
async function refreshEmail(){
  let em = await currentStoreEmail();
  if(!em){
    // 老会话只存了 token 没存 email：让 SW 用 Bearer 调 /api/auth/me 回填，再现取一次
    em = await new Promise((res)=>{ try{ chrome.runtime.sendMessage({type:"SS_ENSURE_EMAIL"},(r)=>res((r&&r.email)||"")); }catch(e){ res(""); } });
    if(!em) em = await currentStoreEmail();
  }
  if(em) state.email = em;
  state.hasSession = !!(em) || (await hasSession());
  return state.email || "";
}

async function ensureLibTab(){
  if(await alive(libTabId))return libTabId;
  const t=await openTab({url:chrome.runtime.getURL("library.html"),active:false}); libTabId=t.id; await complete(t.id);
  for(let i=0;i<15;i++){const p=await send(t.id,{type:"SS_PING"});if(p&&p.ok)return t.id;await sleep(500);} throw Error("选品库未就绪(先登录)");
}

// ── 搜索：1688 的中文搜索是 GBK，手拼 URL 必乱码（实测）。唯一稳的做法是把关键词填进
//    官方搜索框再提交，让浏览器按页面 charset 编码。首页那个框是 <textarea>，
//    结果页顶部那个是 <input>（2026-11-24 实测），两种都要接住。
async function search1688(kw){
  const before = new Set((await chrome.tabs.query({url:"https://s.1688.com/*"})).map(t=>t.id));
  const home = await openTab({url:"https://www.1688.com/", active:false});
  await complete(home.id);
  const typed = await inj(home.id, (k)=>{
    const sels=["#alisearch-input","textarea[name='keywords']","input[name='keywords']","textarea[placeholder*='搜索']","input[placeholder*='搜索']","textarea[placeholder*='批发']","input[placeholder*='批发']"];
    let el=null; for(const s of sels){ el=document.querySelector(s); if(el) break; }
    if(!el) return false;
    const proto = el.tagName==="TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const d = Object.getOwnPropertyDescriptor(proto,"value");
    if(d&&d.set) d.set.call(el,k); else el.value=k;
    el.dispatchEvent(new Event("input",{bubbles:true})); el.dispatchEvent(new Event("change",{bubbles:true}));
    const form = el.closest ? el.closest("form") : el.form;
    if(form){ form.submit(); return true; }
    const btn=[...document.querySelectorAll("button,a")].find(b=>/搜\s*索/.test(b.textContent||""));
    if(btn){ btn.click(); return true; }
    el.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",keyCode:13,bubbles:true}));
    return true;
  }, [kw]);
  if(!typed){ closeTab(home.id); return null; }
  // 首页表单实测会开新标签；也兼容原地跳转
  for(let i=0;i<30;i++){
    await sleep(600);
    const now = (await chrome.tabs.query({url:"https://s.1688.com/selloffer/offer_search.htm*"})).map(t=>t.id);
    const fresh = now.find(id=>!before.has(id));
    if(fresh){ if(fresh!==home.id) closeTab(home.id); await complete(fresh,30000); return fresh; }
    const u = await new Promise(r=>chrome.tabs.get(home.id,t=>r(chrome.runtime.lastError?"":(t&&t.url)||"")));
    if(/offer_search\.htm/.test(u)){ await complete(home.id,30000); return home.id; }
  }
  closeTab(home.id); return null;
}

// ── 详情页补齐：实测「列表页采集」只有基础信息，SKU/描述/详情图全空，
//    采集箱抽屉原话「这条没采到详情图——回 1688 详情页重新点『采集到选品库』再同步即可补齐」，
//    这种条目发布必被平台拦。所以每条都要进详情页点插件自己的「采集到选品库」。
async function enrichFromDetail(url){
  const t = await openTab({url, active:false});
  try{
    await complete(t.id);
    for(let i=0;i<12;i++){ await inj(t.id, ()=>window.scrollTo(0,document.body.scrollHeight)); await sleep(700); }
    for(let i=0;i<24;i++){
      const clicked = await inj(t.id, ()=>{
        const b=[...document.querySelectorAll("button,a,[role='button']")].find(x=>/采集到选品库/.test((x.innerText||"").trim()));
        if(!b) return false;
        b.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:false,view:window}));
        return true;
      });
      if(clicked){ await sleep(3500); return true; }
      await sleep(700);
    }
    return false;
  } finally { closeTab(t.id); }
}

// 走 1688 搜索框（正确编码）采集一批；未登录直接拒绝——静默落进「未归属桶」= 永远同步不出去（实测根因）
async function collectBatch(c, knownOffers){
  const em = await refreshEmail();
  const store0 = await window.MSStore.readAll();
  state.email = em || store0.email || "";
  if(!state.email){ log("未登录 ShopSage 账号，已停止采集：未登录采到的条目会落进「未归属桶」，永远不会同步到采集箱。请先在插件里登录。"); return []; }
  log(`当前账号：${state.email}｜本地库 ${store0.key}（共 ${(store0.mine||[]).length} 条${(store0.unassigned||[]).length?`，另有未归属 ${(store0.unassigned||[]).length} 条`:''}）`);
  const kw = c.keywords[state.cycle % c.keywords.length];
  log(`正在通过 1688 搜索框检索「${kw}」…（这步要开结果页、等加载，约十几秒）`);
  const tabId = await search1688(kw);
  if(!tabId){ log(`「${kw}」没能通过 1688 搜索框打开结果页（改版？）`); return []; }
  let batch=[];
  try{
    await sleep(1500);
    await chrome.scripting.executeScript({target:{tabId},files:["capture.js"]}).catch(()=>{});
    for(let i=0;i<3;i++){ await inj(tabId, ()=>window.scrollTo(0,document.body.scrollHeight)); await sleep(900); }
    const items = (await inj(tabId, ()=>window.MS_CAPTURE?window.MS_CAPTURE():[])) || [];
    const store = await window.MSStore.readAll();
    const mine = Array.isArray(store.mine) ? store.mine.slice() : [];
    const known = new Set(mine.map(x=>x.url));
    const knownOffer = knownOffers || new Set();
    for(const p of items){
      if(!p||!p.url||known.has(p.url)) continue;
      const oid=(String(p.url).match(/offer\/(\d+)/i)||[])[1]||"";
      if(oid && knownOffer.has(oid)) continue;   // ③ 后端采集箱已有该 offer → 绝不重复采集/上架
      if(batch.length >= c.batchSize) break;
      mine.unshift(Object.assign({}, p, { ownerEmail: store.email, syncedToInboxId: null, docReady: false }));
      known.add(p.url); if(oid) knownOffer.add(oid); batch.push(p);
    }
    await window.MSStore.writeBucket(store.key, mine);
    state.nCollect += batch.length;
    log(`搜索「${kw}」识别 ${items.length} 个，本轮取 ${batch.length} 个进选品库`, "ok");
  } finally { closeTab(tabId); }
  // 逐条进详情页补齐 SKU/描述/图（发布的前提）
  let enriched = 0, procIdx = 0;
  const kept = [];   // 只把「补齐出完整内容」的商品交给后续同步/填稿，杜绝空白半成品进采集箱
  for(const p of batch){
    procIdx++;
    // 与插件自己的详情页判定同一口径（content.js: /\/offer\/\d+ 或拼多多 goods_id），不一致会静默跳过补齐
    const isDetail = /\/offer\/\d+/.test(p.url||"") || (/goods\.html|goods_id=/.test(p.url||""));
    const pn = String(p.title||p.url).slice(0,24);
    if(!isDetail){ log(`跳过补齐（链接不是详情页形态）：${pn}`); continue; }
    log(`补齐详情页 ${procIdx}/${batch.length}：${pn} …`);   // 逐条进度：这步较慢，不刷日志客户会以为停了
    // 补齐后必须确认详情内容真的写进了库（有主图或 SKU 才算齐）；只点成功但内容为空不算，最多重试 3 次。
    let done=false;
    for(let a=1; a<=3 && !done; a++){
      if(a>1) log(`「${pn}」第${a}次重试打开详情页…`);
      await enrichFromDetail(p.url);
      const st = await window.MSStore.readAll();
      const it = (st.mine||[]).find(x=>x.url===p.url);
      const ct = it && it.content;
      // 必须有真实主图才算齐（缩略图空=采集不全的根因；单规格无 SKU 也允许，但主图必须在）
      const hasFull = !!(ct && !ct.__msDiag && Array.isArray(ct.images) && ct.images.length > 0);
      if(hasFull){
        done=true; enriched++; kept.push(p);
        log(`「${pn}」补齐完成（主图 ${ct.images.length} 张${Array.isArray(ct.skus)&&ct.skus.length?` / SKU ${ct.skus.length} 个`:''}）`);
        const list=(st.mine||[]).map(x=>x.url===p.url?Object.assign({},x,{docReady:true}):x);
        await window.MSStore.writeBucket(st.key, list);
      } else if(a<3){ log(`「${pn}」第${a}次补齐内容仍不全（无主图），重试…`); await sleep(Math.max(1500,c.delay)); }
    }
    if(!done) log(`「${pn}」详情页始终没采到完整内容（图/SKU），不标记可发布`,"warn");
    if(!state.running) break;
    await sleep(c.delay);
  }
  if(batch.length) log(`详情页补齐 ${enriched}/${batch.length} 条${enriched<batch.length?`（${batch.length-enriched} 条详情页结构不同/无主图，已跳过不进采集箱）`:""}`, enriched===batch.length?"ok":"warn");
  // 补齐失败（无主图）的条目从本地库也清掉，避免留下空白半成品污染选品库/采集箱
  const failedUrls = new Set(batch.filter(p=>kept.indexOf(p)<0).map(p=>p.url));
  if(failedUrls.size){
    try{
      const st2 = await window.MSStore.readAll();
      const cleaned = (st2.mine||[]).filter(x=>!failedUrls.has(x.url));
      if(cleaned.length !== (st2.mine||[]).length) await window.MSStore.writeBucket(st2.key, cleaned);
    }catch(e){}
  }
  return kept;
}

async function syncBatch(c, batch){
  const tab=await ensureLibTab();
  const urls=batch.map(b=>b.url);
  const r=await send(tab,{type:"SS_AUTO_SYNC", urls, country:c.market, shopId:c.shop, targetMarginPct:c.targetMarginPct, floatPct:c.floatPct, discountPct:c.discountPct, limit:c.batchSize});
  if(r&&r.ok){ state.nSync+=(r.synced||0); const rs=r.results||[]; const noDoc=rs.filter(x=>x.doc===false).length; rs.forEach(x=>{ if(x.sell) log(`售价(按${c.targetMarginPct}%毛利${c.floatPct?`±${c.floatPct}%`:""})=${x.sell} ${x.currency} · ${x.title}`); else if(x.err) log('同步失败：'+String(x.title||'').slice(0,24)+' → '+x.err,'warn'); }); log(`同步本批 ${r.synced} 条${r.failed?`（失败 ${r.failed}）`:""}${noDoc?` · 其中 ${noDoc} 条只有基础信息（没进详情页补齐，不可发布）`:""}`, noDoc?"warn":"ok"); return rs; }
  log("同步未跑通："+((r&&r.error)||"library 没响应")); return [];
}

async function ensureBoxTab(){
  if(await alive(boxTabId)){ await (new Promise(r=>chrome.tabs.update(boxTabId,{url:"https://www.shopsage.cc/selection/inbox"},()=>r()))); await complete(boxTabId); return boxTabId; }
  const t=await openTab({url:"https://www.shopsage.cc/selection/inbox",active:false}); boxTabId=t.id; await complete(t.id);
  await chrome.scripting.executeScript({target:{tabId:t.id},files:["content/inbox-publisher.content.js"]}).catch(()=>{});
  return t.id;
}
async function askPanel(items){ if(!(await alive(state.panelTabId)))return false; const r=await send(state.panelTabId,{type:"SS_AUTO_CONFIRM_REQ",items,market:state.cfg.market}); return !!(r&&r.ok); }

// 发布台账（chrome.storage）：站点列表的「已发布」文案实测会滞后，去重必须以我们自己的回执为准
const LEDGER_KEY = "ssAutoLedger";
const lkey = (shopId, title) => String(shopId || "_") + "|" + String(title || "").slice(0, 60);
async function ledgerGet(){ return new Promise(r=>{ try{ chrome.storage.local.get(LEDGER_KEY,(s)=>r((s&&s[LEDGER_KEY])||{})); }catch(e){ r({}); } }); }
async function ledgerPut(k, v){ const l=await ledgerGet(); l[k]=v; return new Promise(r=>{ try{ chrome.storage.local.set({[LEDGER_KEY]:l},()=>r()); }catch(e){ r(); } }); }

// 采集箱页可能被发布流程跳到详情页；每条之前把它拉回列表并等内容脚本监听就绪
async function boxReady(){
  for(let i=0;i<20;i++){
    try{
      const inj=await chrome.scripting.executeScript({target:{tabId:boxTabId}, func:()=>!!window.__ssPublishOne});
      if(inj&&inj[0]&&inj[0].result) return true;
    }catch(e){}
    await sleep(800);
  }
  return false;
}

// 发布结果权威判定：不靠页面回执/导航（会被发布跳转和后台 bfcache 坑掉），改轮询后端这条 inbox 的 status。
// 实测状态源 = GET /api/extension/inbox；这条 id 命中且 status 含「已发布/published」或带平台商品ID 才算真发出去。
async function pollInboxStatus(inboxId, timeoutMs){
  const t0=Date.now();
  while(Date.now()-t0 < (timeoutMs||120000)){
    try{
      const d=await SS("/api/extension/inbox",{method:"GET"});
      const arr=Array.isArray(d)?d:((d&&(d.data||d.items||d.inbox||d.list))||[]);
      const it=(Array.isArray(arr)?arr:[]).find(x=>x&&(x.id===inboxId||x.inboxId===inboxId||x.inboxItemId===inboxId));
      if(it){
        const st=String(it.status||it.state||it.publishStatus||"");
        const pid=it.tiktokProductId||it.productId||it.listingId||it.externalProductId||"";
        if(/已发布|published|listed|在售/i.test(st)||pid) return {ok:true, status:st, productId:String(pid||""), viaBackend:true};
      }
    }catch(e){}
    if(!state.running) return {ok:false, error:"已停止"};
    await sleep(4000);
  }
  return {ok:false, error:"后端轮询超时，未见该条转「已发布」"};
}

// 店铺发布默认（A+B）：优先读后端配置接口，拿不到回退 chrome.storage 的本地默认。
async function getPublishDefaults(shopId){
  let d = null;
  try{
    const r = await SS("/api/extension/shop-publish-defaults?shopId="+encodeURIComponent(shopId||""),{method:"GET"});
    if(r && (r.stockQty||r.weightKg||r.dims||r.brand||r.warehouse)) d=r;
  }catch(e){ /* 后端未提供该接口 → 回退本地 */ }
  if(!d){
    const k = "ssAutoPubDefaults:"+(shopId||"_");
    d = await new Promise(res=>{ try{ chrome.storage.local.get(k,(s)=>res((s&&s[k])||{})); }catch(e){ res({}); } });
  }
  return { stockQty:Number(d.stockQty)||100, weightKg:Number(d.weightKg)||0.5, dims:d.dims||{l:20,w:15,h:10}, brand:d.brand||"", warehouse:d.warehouse||"" };
}

// 商用 API 驱动发布：控制页用扩展 token 直接组装完整 body 调后端 publish，
// 完全不碰采集箱网页 DOM（绕开 SPA 找不到条目 / 后台标签被冻结 / 会话隔离 这三个坑）。
// 数据源：条目 draft（平台侧编辑：globalTitle/categoryId/attrs/warehouseId/brandId/skuSales/skuLogistics + 成稿）
//        + sourceSnapshot（货源底稿：skus/描述/主图/物流）+ 顶层 title/targetPrice。
// 描述去中文（TikTok 硬拦：product description must not contain Chinese）——保留 <img> 结构，剥中文文本与属性串
function stripCnHtml(html){
  let out=String(html||"");
  out=out.replace(/(\b(?:title|alt|placeholder)\s*=\s*["'])(?:[^"']*)(["'])/gi,(m,a,b)=>/[\u4e00-\u9fa5]/.test(m)?a+b:m);
  out=out.replace(/>([^<>]*)</g,(m,t)=>/[\u4e00-\u9fa5]/.test(t)?">"+t.replace(/[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]+/g,"")+"<":m);
  out=out.replace(/[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]+/g,"");
  return out.replace(/\s{2,}/g," ").trim();
}
function stripCnText(s){return String(s||"").replace(/[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]+/g," ").replace(/\s+/g," ").trim();}
// 平台硬规则（2026-11-24 生产实测 rid 20261124225…）：TikTok create 拒销售属性值含中文
// 「Chinese characters are not allowed. Modify the attribute value name of the sale attribute」，
// 且本地 listing-check 不拦——只有真 publish 才报错。所以这里单独判中文。
function hasCjk(s){return /[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]/.test(String(s||""));}
// 鉴权守卫：控制页(automation.html)的 auth.js 若尚未挂上 SSAuth（刚重载/登录态失效的瞬间），
// 给出可操作的中文提示，而不是抛裸 TypeError「Cannot read properties of undefined」。
function SS(p,o){ if(!(window.SSAuth&&window.SSAuth.backendFetch)) throw new Error("控制页鉴权未就绪（SSAuth 未加载或登录态失效）——请刷新当前 1688 页面后重试；若仍不行，到插件「设置」里重新登录一次"); return window.SSAuth.backendFetch(p,o); }

async function publishViaApi(inboxId, shopId, defaults){
  if(!inboxId) return {ok:false, error:"无 inboxId"};
  const BF=(p,o)=>SS(p,o);
  let item=null;
  try{
    const list = await BF("/api/extension/inbox",{method:"GET"});
    const arr = Array.isArray(list)?list:((list&&(list.data||list.items||list.list))||[]);
    item = (Array.isArray(arr)?arr:[]).find(x=>x&&(x.id===inboxId||x.inboxId===inboxId));
  }catch(e){ return {ok:false, error:"读条目失败："+((e&&e.message)||e)}; }
  if(!item) return {ok:false, error:"条目不在采集箱（可能没同步成功）"};
  const d=item.draft||{}, snap=item.sourceSnapshot||{};
  const dl=(d.listing&&typeof d.listing==="object")?d.listing:d; // DraftListing 可能嵌在 draft.listing
  const steps=[];
  // 1) 平台类目：不信任 draft.categoryId（很可能是 1688 类目，平台不认），总是调 suggest-category 拿平台叶子
  let categoryId="";
  try{
    const sc=await BF("/api/tiktok/listing/inbox/"+inboxId+"/suggest-category",{method:"POST",body:JSON.stringify({shopId})});
    categoryId=String((sc&&sc.primary&&sc.primary.id)||"").trim();
    steps.push("类目:"+(sc&&sc.primary&&sc.primary.path?String(sc.primary.path).slice(0,24):categoryId||"无"));
  }catch(e){
    categoryId=String(dl.categoryId||d.categoryId||"").trim();
    steps.push("类目:suggest失败退draft:"+String((e&&e.message)||e).slice(0,40));
  }
  if(!categoryId) return {ok:false, error:"没定位到平台类目 步骤:"+steps.join("/")};
  // 2) 英文全球标题：没有调 global-title
  let globalTitle=String(dl.globalTitle||d.globalTitle||"").trim();
  if(!globalTitle){ try{ const gt=await BF("/api/tiktok/listing/inbox/"+inboxId+"/global-title",{method:"POST"}); globalTitle=String((gt&&gt.globalTitle)||"").trim(); steps.push("标题:生成"); }catch(e){ steps.push("标题:生成失败"); } }
  else steps.push("标题:已有");
  if(!globalTitle) return {ok:false, error:"没生成英文全球标题"};
  // 3) 逐 SKU 销售属性：spec-prefill（ai 翻译当地语言，失败回退 auto 采集原文）
  let filled=[];
  try{ const sp=await BF("/api/tiktok/listing/inbox/"+inboxId+"/spec-prefill",{method:"POST",body:JSON.stringify({shopId, categoryId, mode:"ai"})}); filled=(sp&&(sp.filled||sp.pairing))||[]; steps.push("销售属性:ai "+filled.length); }
  catch(e){ try{ const sp=await BF("/api/tiktok/listing/inbox/"+inboxId+"/spec-prefill",{method:"POST",body:JSON.stringify({shopId, categoryId, mode:"auto"})}); filled=(sp&&sp.filled)||[]; steps.push("销售属性:auto "+filled.length); }catch(e2){ steps.push("销售属性:失败"); } }
  const byIdx={};
  (Array.isArray(filled)?filled:[]).forEach(f=>{ const i=Number(f.skuIndex); (byIdx[i]=byIdx[i]||[]).push({attributeId:String(f.attrId||f.attributeId||""), valueName:String(f.value||f.valueName||"").trim()}); });
  // 4) 组装 skus
  const srcSkus=d.skus||snap.skus||snap.skuTable||[];
  const skus=(Array.isArray(srcSkus)?srcSkus:[]).map((s,i)=>({
    sellerSku:String(s.sellerSku||s.skuId||""), spec:String(s.spec||""),
    price:String(s.price||item.targetPrice||""), stock:String(s.stock||defaults.stockQty||100),
    salesAttributes: byIdx[i]||[],
    ...((dl.skuLogistics&&dl.skuLogistics[i])?{weightKg:String(dl.skuLogistics[i].weightKg||""), dimensionsCm:dl.skuLogistics[i].lengthCm?{length:String(dl.skuLogistics[i].lengthCm),width:String(dl.skuLogistics[i].widthCm||""),height:String(dl.skuLogistics[i].heightCm||"")}:undefined}:{})
  }));
  // 4b) 中文销售属性兜底（2026-11-24 生产实测：平台 create 拒销售属性值含中文，本地 listing-check 却不拦，
  //     只有真 publish 才报错；spec-prefill ai 翻译经常整批丢弃→落到 auto 中文原文）。
  //   只要多 SKU 的销售属性「不安全」就合并为「单 SKU、无销售属性」发布——平台对单规格商品不要求销售属性，
  //   这样每条都能先建出 AS_DRAFT 草稿（卖家可在 TikTok 后台补规格上架）。不安全＝未对齐 / 全空 / 含中文 / 组合重复，
  //   （2026-11-24 猫咪沙发实测：ai 给出泰语颜色但多 SKU 撞同一词→SKU_SALES_VALUE_DUPLICATE 整单拒，光判中文不够）。
  let finalSkus=skus;
  const normV=(v)=>String(v||"").trim().replace(/\s+/g," ").toLowerCase();
  const cjkIn=(s)=>(s.salesAttributes||[]).some(a=>hasCjk(a.valueName));
  let salesUnsafe=false, why="";
  if(skus.length>1){
    const sets=skus.map(s=>(s.salesAttributes||[]).filter(a=>a.valueName).map(a=>String(a.attributeId)).sort().join("|"));
    const first=sets[0];
    const misaligned=sets.some(k=>k!==first);
    const emptyAll=sets.every(k=>k==="");
    const anyCjk=skus.some(cjkIn);
    const seen={}; let dup=false;
    skus.forEach(s=>{ const c=(s.salesAttributes||[]).filter(a=>a.valueName).map(a=>String(a.attributeId)+"="+normV(a.valueName)).sort().join("&"); if(c){ if(seen[c])dup=true; seen[c]=1; } });
    if(misaligned){salesUnsafe=true;why="属性未对齐";}
    else if(emptyAll){salesUnsafe=true;why="规格值全空";}
    else if(anyCjk){salesUnsafe=true;why="含中文";}
    else if(dup){salesUnsafe=true;why="组合重复";}
  } else if(skus.length===1 && skus.some(cjkIn)){ salesUnsafe=true; why="单SKU值含中文"; }
  if(salesUnsafe){
    const totalStock=skus.reduce((n,s)=>n+(Number(s.stock)||0),0);
    const priceVal=(Array.isArray(skus)&&skus[0]&&skus[0].price)?skus[0].price:(item.targetPrice||"");
    const baseSku=String((srcSkus[0]&&(srcSkus[0].sellerSku||srcSkus[0].skuId))||inboxId||"SSKU").replace(/[^\w.-]/g,"").slice(0,40)||"SSKU";
    finalSkus=[{ sellerSku:baseSku, spec:"", price:String(priceVal), stock:String(totalStock||defaults.stockQty||100), salesAttributes:[] }];
    steps.push("销售属性["+why+"]→合并单SKU发布("+(Array.isArray(srcSkus)?srcSkus.length:skus.length)+"合1)");
  }
  // 描述：去中文；若剥完为空/太短（纯中文货源），用英文兜底，保证非空且无中文
  let descHtml = stripCnHtml(d.descriptionHtml||d.description||snap.descriptionHtml||snap.description||"");
  if(!descHtml || descHtml.replace(/<[^>]+>/g,"").replace(/\s/g,"").length < 15){
    descHtml = "<p>"+(globalTitle||stripCnText(item.title)||"Pet Product")+"</p><p>See product images for details. Quality item as described.</p>";
  }
  const body = {
    shopId, categoryId, globalTitle, title: String(item.title||""),
    descriptionHtml: descHtml,
    mainImages:(d.mainImages||d.images||snap.mainImages||(item.imageUrl?[item.imageUrl]:[])).map(String),
    attributes: dl.attrs||d.attrs||[], skus:finalSkus,

    weightKg: String(dl.weightKg||d.weightKg||snap.weightKg||defaults.weightKg||0.5),
    dimensionsCm: dl.dimensionsCm||d.dimensionsCm||{length:String((defaults.dims&&defaults.dims.l)||20),width:String((defaults.dims&&defaults.dims.w)||15),height:String((defaults.dims&&defaults.dims.h)||10)},
    warehouseId: dl.warehouseId||d.warehouseId||defaults.warehouse||undefined,
    brandId: dl.brandId||d.brandId||undefined,
    confirm:true, saveMode:"AS_DRAFT"
  };
  // 5) 先 check 拿完整缺项（若还缺），再 publish
  try{
    const chk = await BF("/api/tiktok/listing/inbox/"+inboxId+"/listing-check",{method:"POST",body:JSON.stringify(body)});
    if(chk && chk.ready===false){
      const bl=(chk.blockers||[]).map(b=>b.message||b.code||b.field).filter(Boolean);
      return {ok:false, error:"缺项["+(bl.join("；")||JSON.stringify(chk.blockers||[]).slice(0,240))+"] 步骤:"+steps.join("/"), blockers:chk.blockers};
    }
  }catch(e){ /* check 失败不拦，继续 publish */ }
  try{
    const r = await BF("/api/tiktok/listing/inbox/"+inboxId+"/publish",{method:"POST",body:JSON.stringify(body)});
    const pid=String((r&&(r.siteProductId||r.globalProductId||r.productId||r.id))||"").trim();
    // 严格判定：必须后端明确 ok:true 且带回平台商品ID，才算真建出（不再"没报错=成功"误判）
    if(r && r.ok===true && pid){
      // 9.1 发布成功→上报「平台SKU ↔ 1688 货源SKU」配对（采购价闭环）。每个 SKU 一条，覆盖更新；失败不影响发布结果。
      try{
        const offerId=(String(item.externalUrl||"").match(/offer\/(\d+)/i)||[])[1]||"";
        const links=(body.skus||[]).map((sk,i)=>{
          const src=srcSkus[i]||{};
          return SS("/api/purchase/sku-link",{method:"POST",body:JSON.stringify({
            platformSku:String(sk.sellerSku||""), offerId,
            sourceSkuId:String(src.skuId||src.sellerSku||""),
            spec:String(src.spec||""),
            unitCostCny:(src.price!=null&&src.price!==""&&!isNaN(Number(src.price))?Number(src.price):undefined),
            offerUrl:String(item.externalUrl||""), source:"PLUGIN_PUBLISH"
          })}).then(()=>1).catch(()=>0);
        });
        const n=(await Promise.all(links)).filter(Boolean).length;
        steps.push("配对上报:"+n+"/"+links.length);
      }catch(e){ steps.push("配对上报失败"); }
      return {ok:true, productId:pid, steps, raw:r};
    }
    return {ok:false, error:"publish未确认建出: "+JSON.stringify(r).slice(0,320)+" 步骤:"+steps.join("/")};
  }catch(e){
    const msg=String((e&&e.message)||e);
    return {ok:false, error:"publish报错:"+msg.slice(0,220)+" 步骤:"+steps.join("/")};
  }
}

// 「填好存后台、不自动发布」：把所有必填信息自动补全后，PATCH 写回 draft，
// 客户打开 采集箱→该商品 编辑页即「已填好」，自己点「发布/送审」。不调用平台 publish，零平台写副作用。
// 销售属性只存 ai 译成的当地语言值（非中文）；译不出就留空，由客户在编辑页填，绝不把中文写进去卡他发布。
async function prepareAndSaveDraft(inboxId, shopId, defaults, opts){
  opts=opts||{};
  const skuPrices=Array.isArray(opts.skuPrices)?opts.skuPrices:null;   // 同步时逐 SKU 算好的 {spec,cost,discounted,list}
  const disc=Math.min(Math.max(Number(opts.discountPct)||0,0),90);
  const discDiv=1-disc/100;
  // 取某 SKU 的平台标价：优先同步算好的 list；没有就用折后价/商品 targetPrice 现算折扣换算（绝不回落 0）
  const listPriceFor=(i,sku)=>{
    const sp=skuPrices&&skuPrices[i];
    if(sp&&sp.list!=null) return sp.list;
    if(sp&&sp.discounted!=null&&discDiv>0) return Math.round(sp.discounted/discDiv*100)/100;
    const tp=Number(sku&&sku.sellPrice)||Number(item&&item.targetPrice)||0;
    if(tp>0&&discDiv>0) return Math.round(tp/discDiv*100)/100;
    return tp>0?tp:null;
  };
  if(!inboxId) return {ok:false, error:"无 inboxId"};
  const steps=[];
  let item=null;
  try{ const list=await SS("/api/extension/inbox",{method:"GET"}); const arr=Array.isArray(list)?list:((list&&(list.data||list.items||list.list))||[]); item=(Array.isArray(arr)?arr:[]).find(x=>x&&(x.id===inboxId||x.inboxId===inboxId)); }
  catch(e){ return {ok:false, error:"读条目失败:"+((e&&e.message)||e)}; }
  if(!item) return {ok:false, error:"条目不在采集箱"};
  const d=item.draft||{}, snap=item.sourceSnapshot||{};
  const dl=(d.listing&&typeof d.listing==="object")?d.listing:{};
    // 1) 平台类目：总是先调 suggest-category 拿平台叶子类目（draft.categoryId 可能是 1688/非叶子类目，直接拿去 spec-prefill 会报「Category is not final category」→销售属性取不到→误合并单SKU）。
    //    后端偶发 504/空回执要重试（最多 3 次），而不是一次失败就退回非叶子类目导致塌成单 SKU。
    let categoryId="", categoryPath="";
    for(let attempt=1; attempt<=3 && !categoryId; attempt++){
      try{
        const sc=await SS("/api/tiktok/listing/inbox/"+inboxId+"/suggest-category",{method:"POST",body:JSON.stringify({shopId})});
        if(sc&&sc.primary){ categoryId=String(sc.primary.id||"").trim(); categoryPath=String(sc.primary.path||"").trim(); steps.push("类目:suggest叶子定位"); }
        else steps.push("类目:suggest空回执#"+attempt);
      }catch(e){ steps.push("类目:suggest失败#"+attempt+":"+String((e&&e.message)||e).slice(0,50)); }
      if(!categoryId && attempt<3) await sleep(1500);
    }
    if(!categoryId){ categoryId=String(dl.categoryId||d.categoryId||"").trim(); categoryPath=String(dl.categoryPath||"").trim(); if(categoryId) steps.push("类目:退draft(可能非叶子)"); }
    if(!categoryId) return {ok:false, error:"没定位到平台类目 步骤:"+steps.join("/")};
  // 2) 英文全球标题
  let globalTitle=String(dl.globalTitle||d.globalTitle||"").trim();
  if(!globalTitle){ try{ const gt=await SS("/api/tiktok/listing/inbox/"+inboxId+"/global-title",{method:"POST"}); globalTitle=String((gt&&gt.globalTitle)||"").trim(); steps.push("标题:生成"); }catch(e){ steps.push("标题:失败"); } } else steps.push("标题:已有");
  if(!globalTitle) return {ok:false, error:"没生成英文全球标题 步骤:"+steps.join("/")};
  // 3) 销售属性：只存 ai 译成且非中文的值，按每 SKU 的 {属性ID: 值} 映射
  // ⑤ 逐 SKU 定价可观测：把每个保留 SKU 的「1688进价 → 折后成交价 → 平台标价」原样打出来，便于核对（纯日志，不改数值）
  if(Array.isArray(skuPrices)&&skuPrices.length){
    log('逐SKU定价：'+skuPrices.map(p=>'进'+(p.cost==null?'?':p.cost)+'→折后'+(p.discounted==null?'?':p.discounted)+'→标价'+(p.list==null?'?':p.list)).join(' ｜ '));
  }
  const srcSkusAll=(Array.isArray(d.skus)?d.skus:(Array.isArray(snap.skus)?snap.skus:[]));
  // ⑤ 超过 10 个 SKU 只保留原顺序前 10（用户口径：删减到 10 内）
  const srcSkus=srcSkusAll.slice(0,10);
  const skuSales=srcSkus.map(()=>({}));
  try{
    const sp=await SS("/api/tiktok/listing/inbox/"+inboxId+"/spec-prefill",{method:"POST",body:JSON.stringify({shopId, categoryId, mode:"ai"})});
    const filled=(sp&&(sp.filled||sp.pairing))||[];
    let kept=0;
    (Array.isArray(filled)?filled:[]).forEach(f=>{ const i=Number(f.skuIndex); const v=String(f.value||f.valueName||"").trim(); const aid=String(f.attrId||f.attributeId||"").trim(); if(i>=0&&i<skuSales.length&&v&&aid&&!hasCjk(v)){ skuSales[i][aid]=v; kept++; } });
    steps.push("销售属性:ai 返回"+(Array.isArray(filled)?filled.length:0)+"条/保留"+kept+"条");
    if(kept===0){ try{ const raw=JSON.stringify(sp||{}); steps.push("ai空回执样本:"+raw.slice(0,160)); }catch(e){} }
  }catch(e){ const emsg=String((e&&e.message)||e); steps.push("销售属性:ai抛错:"+emsg.slice(0,160)); if(/TikTok|其它平台|其他平台|仍在排期|不支持|only\s+tiktok/i.test(emsg)){ return {ok:false, notTiktok:true, error:"该店铺不是 TikTok Shop（发布链路目前只接通 TikTok Shop），已跳过、未静默合并单 SKU。请在面板选择 TikTok Shop 店铺。", steps}; } }
  // 4) 单 SKU 含中文销售值→清掉（否则客户点发布被平台拒中文）
  if(srcSkus.length===1){ Object.keys(skuSales[0]||{}).forEach(k=>{ if(hasCjk(skuSales[0][k])) delete skuSales[0][k]; }); }
  // 多 SKU 安全性判定：未对齐/全空/含中文/组合重复 → 存稿时合并成单 SKU，保证客户一键发布必过
  const dims=defaults.dims||{l:20,w:15,h:10};
  const normV=(v)=>String(v||"").trim().replace(/\s+/g," ").toLowerCase();
  let collapse=false, why="";
  if(srcSkus.length>1){
    const sets=skuSales.map(m=>Object.keys(m).sort().join("|"));
    const first=sets[0];
    const misaligned=sets.some(k=>k!==first);
    const emptyAll=sets.every(k=>k==="");
    const anyCjk=skuSales.some(m=>Object.keys(m).some(k=>hasCjk(m[k])));
    const seen={}; let dup=false;
    skuSales.forEach(m=>{ const c=Object.keys(m).sort().map(k=>k+"="+normV(m[k])).join("&"); if(c){ if(seen[c])dup=true; seen[c]=1; } });
    // 只在「多个 SKU 的销售属性组合完全重复、平台无法区分」时才合并；
    // ai 译不出/属性留空/未对齐都不再塌成单 SKU —— 保留全部 SKU 与各自标价，属性由客户在编辑页补（发布前补即可）。
    if(dup){collapse=true;why="组合重复(无法区分)";}
    else if(emptyAll){ steps.push("销售属性:ai未给有效值→保留"+srcSkus.length+"个SKU、属性留空待客户填"); }
    else if(misaligned||anyCjk){ steps.push("销售属性:部分未译全→保留"+srcSkus.length+"个SKU(已填的保留、缺的待客户补)"); }
  }
  let fSkuSales=skuSales, fSrcSkus=srcSkus.map((s,i)=>Object.assign({},s,{_list:listPriceFor(i,s)}));
  if(collapse){
    const totStock=srcSkus.reduce((n,s)=>n+(Number(s.stock)||0),0);
    // ⑤ 合并单 SKU 时，标价取「最贵进价 SKU」算出的标价（保守，绝不少算利润）
    let maxCost=-Infinity, pickList=null;
    srcSkus.forEach((s,i)=>{ const sp=skuPrices&&skuPrices[i]; const cost=(sp&&sp.cost!=null)?sp.cost:(Number(s.price)||0); if(cost>maxCost){ maxCost=cost; pickList=listPriceFor(i,s); } });
    const priceVal=(pickList!=null?pickList:(item.targetPrice||""));
    const baseId=String((srcSkus[0]&&srcSkus[0].skuId)||inboxId||"").replace(/[^\w.-]/g,"").slice(0,40)||inboxId;
    fSrcSkus=[{ skuId:baseId, spec:"", price:(srcSkus[0]&&srcSkus[0].price!=null?String(srcSkus[0].price):""), _list:priceVal, stock:String(totStock||defaults.stockQty||100) }];
    fSkuSales=[{}];
    steps.push("销售属性["+why+"]→存稿合并单SKU("+srcSkusAll.length+"→10内→1，标价取最贵进价SKU="+priceVal+")");
  } else steps.push("销售属性:保留"+srcSkus.length+"个SKU"+(srcSkusAll.length>10?"（原"+srcSkusAll.length+"个，裁到10）":"")+"，逐SKU标价已按毛利+折扣算");
  const skuLogistics=fSrcSkus.map((s,i)=>{ const ex=(dl.skuLogistics&&dl.skuLogistics[collapse?0:i])||{}; return { weightKg:String(ex.weightKg||defaults.weightKg||""), lengthCm:String(ex.lengthCm||dims.l||""), widthCm:String(ex.widthCm||dims.w||""), heightCm:String(ex.heightCm||dims.h||"") }; });
  // 5) 描述去中文 + 兜底
  let descHtml=stripCnHtml(d.descriptionHtml||d.description||snap.descriptionHtml||snap.description||"");
  if(!descHtml||descHtml.replace(/<[^>]+>/g,"").replace(/\s/g,"").length<15){ descHtml="<p>"+(globalTitle||stripCnText(item.title)||"Pet Product")+"</p><p>See product images for details. Quality item as described.</p>"; }
  const mainImages=((d.mainImages||d.images||snap.mainImages||(item.imageUrl?[item.imageUrl]:[]))||[]).map(String).filter(Boolean);
  // 6) 组装新 draft（在现有 draft 上覆盖 listing/descriptionHtml/images/weight/skus，其它字段保留）
  const newListing={ ...dl, shopId:String(shopId||dl.shopId||""), globalTitle, categoryId, categoryPath, attrs: dl.attrs||[], skuSales: fSkuSales, skuLogistics, warehouseId: dl.warehouseId||defaults.warehouse||"", brandId: dl.brandId||(defaults.brand||undefined) };
  const skus=fSrcSkus.map(s=>({ skuId:String(s.skuId||s.sellerSku||""), spec:String(s.spec||""), price:(s.price!=null?String(s.price):""), sellPrice:String(s._list!=null?s._list:(s.sellPrice!=null?s.sellPrice:(item.targetPrice||""))), stock:String(s.stock||defaults.stockQty||100) }));
  const w=(d.weight&&typeof d.weight==="object")?d.weight:{};
  const newDraft={ ...d, listing:newListing, descriptionHtml:descHtml, images:mainImages, weight:{ weightKg:String(w.weightKg||defaults.weightKg||""), lengthCm:String(w.lengthCm||dims.l||""), widthCm:String(w.widthCm||dims.w||""), heightCm:String(w.heightCm||dims.h||"") }, skus };
  // 7) 存回官网后台
  try{ await SS("/api/extension/inbox/"+inboxId,{method:"PATCH",body:JSON.stringify({draft:newDraft})}); steps.push("已保存编辑稿"); return {ok:true, saved:true, steps}; }
  catch(e){ return {ok:false, error:"保存失败:"+((e&&e.message)||e), steps}; }
}

async function publishBatch(c, results){
  // 「开始持续跑」第三段：不再发平台，而是把本批新同步的条目全部「信息填好存后台」(prepareAndSaveDraft)，
  // 客户随后自己在「采集箱→该商品」逐个点「发布/送审」上架。零平台写副作用，绝不自动上架。
  const raw=(results&&results.length)?results:[];
  const noDoc=raw.filter(x=>x.doc===false).length;
  if(noDoc) log(`${noDoc} 条只有基础信息（没进详情页补齐）已跳过填稿`);
  const items=raw.filter(x=>x.doc!==false && x.inboxId).map(x=>({title:x.title,inboxId:x.inboxId, skuPrices:x.skuPrices, discountPct:(x.discountPct!=null?x.discountPct:c.discountPct)}));
  if(!items.length){ log("本批没有可填稿项"); return; }
  const pubDefaults = await getPublishDefaults(c.shop);
  const PKEY="ssPrepared:"+String(c.shop||"_");
  const prepared = await new Promise(res=>{ try{ chrome.storage.local.get(PKEY,(s)=>res((s&&s[PKEY])||{})); }catch(e){ res({}); } });
  let done=0, skip=0; const blocks={};
  for(const it of items){
    if(prepared[it.inboxId]){ skip++; continue; }   // 跨轮去重：已填过稿的不重复填（省 AI 点数）
    log(`填稿中：${String(it.title||"").slice(0,24)} …`);
    const r = await prepareAndSaveDraft(it.inboxId, c.shop, pubDefaults, { skuPrices: it.skuPrices, discountPct: it.discountPct });
    if(r && r.ok){
      done++; prepared[it.inboxId]=1;
      try{ await new Promise(res=>chrome.storage.local.set({[PKEY]:prepared},res)); }catch(e){}
      log(`已填好存后台：${String(it.title||"").slice(0,24)}（步骤 ${(r.steps||[]).join("/")||"ok"}）`,"ok");
    }
    else { blocks["填稿"]=(blocks["填稿"]||0)+1; log(`填稿失败：${String(it.title||"").slice(0,24)} → ${(r&&r.error)||"无回执"}`,"warn"); }
    await sleep(c.delay);
  }
  const bk=Object.keys(blocks).map(k=>`${k}×${blocks[k]}`).join(" / ");
  log(`本批填稿存后台 ${done}/${items.length}${skip?`（已填过跳过 ${skip}）`:""}${bk?`（失败：${bk}）`:""} —— 请到「采集箱」逐个点「发布」上架`, done?"ok":"warn");
}

// 不采集，直接发布采集箱里已有的「待评估」条目 —— 专注验证/调通后端 publish，彻底避开 1688 反爬。
async function publishExisting(c){
  // 本模式不走 collectBatch，必须在此单独把登录态 email 落到 state.email，否则面板永远显示「未登录」。
  await ensureLoginEmail(); await refreshEmail();
  const defaults = await getPublishDefaults(c.shop);
  let arr=[];
  try{ const list=await SS("/api/extension/inbox",{method:"GET"}); arr=Array.isArray(list)?list:((list&&(list.data||list.items||list.list))||[]); }
  catch(e){ log("读采集箱失败："+((e&&e.message)||e),"warn"); return; }
  // 「待填」= 状态 NEW/待评估 的条目（不论是否已建过平台草稿）。自动补全必填信息后 PATCH 存回官网后台，
  // 客户打开「采集箱→该商品」即「已填好」，自己点「发布/送审」上架。本动作**不调平台 publish**，零上架副作用。
  const all=Array.isArray(arr)?arr:[];
  // 已填过的判定：draft.listing 里已有英文全球标题+平台类目 → 视为已补全，跳过，不重复填/不碰以前采的
  const isPrepared=(x)=>!!(x&&x.draft&&x.draft.listing&&String(x.draft.listing.globalTitle||"").trim()&&String(x.draft.listing.categoryId||"").trim());
  const pend=all.filter(x=>x&&(x.id||x.inboxId)&&/待评估|NEW/i.test(String(x.status||""))&&!isPrepared(x));
  const doneAlready=all.filter(x=>x&&(x.id||x.inboxId)&&/待评估|NEW/i.test(String(x.status||""))&&isPrepared(x)).length;
  const cap=pend.length>60?60:pend.length;
  log(`采集箱共 ${all.length} 条 · 已填过跳过 ${doneAlready} 条 · 本轮补全存稿 ${cap} 条（只填信息到后台，不发平台）`,"ok");
  let ok=0;
  for(const it of pend.slice(0,60)){
    const inboxId=String(it.id||it.inboxId);
    const r=await prepareAndSaveDraft(inboxId, c.shop, defaults, { discountPct: c.discountPct });
    if(r&&r.ok){ ok++; log(`已填好存后台：${String(it.title||"").slice(0,24)}（步骤 ${(r.steps||[]).join("/")||"ok"}）`,"ok"); }
    else log(`填稿失败：${String(it.title||"").slice(0,24)} → ${(r&&r.error)||""}`,"warn");
    await sleep(1500);
  }
  log(`后台编辑稿补全完成：${ok}/${cap} 条（去采集箱逐个点「发布」上架）`, ok?"ok":"warn");
}

// 开跑前先把历史「未归属」条目认领进当前账号（实测这 60 条就是这么卡住不动的）
async function claimHistory(){
  try{
    const tab=await ensureLibTab();
    const r=await send(tab,{type:"SS_AUTO_CLAIM"});
    if(r&&r.ok){ if(r.moved) log(`已认领历史未归属条目 ${r.moved} 条进当前账号（选品库共 ${r.total}）`, "ok"); else log("无待认领的未归属条目"); }
    else log("认领未执行：" + ((r&&r.error)||"无响应"));
  }catch(e){ log("认领失败："+(e.message||e)); }
}

async function ensureLoginEmail(){
  try{
    return await new Promise((res)=>chrome.runtime.sendMessage({type:"SS_ENSURE_EMAIL"},(r)=>res((r&&r.email)||"")));
  }catch(e){ return ""; }
}

// ③ 后端采集箱已有的 offer 集合（按 offerId，不是标题）——开跑前拉一次，本轮绝不重复采集/上架
function offerIdOf(url){ const m=String(url||"").match(/offer\/(\d+)/i); return m?m[1]:""; }
async function fetchInboxOfferIds(){
  const set=new Set();
  try{
    const list=await SS("/api/extension/inbox",{method:"GET"});
    const arr=Array.isArray(list)?list:((list&&(list.data||list.items||list.inbox||list.list))||[]);
    (Array.isArray(arr)?arr:[]).forEach(x=>{ const oid=offerIdOf(x&&(x.externalUrl||x.sourceUrl||x.offerUrl||x.url)); if(oid) set.add(oid); });
    log(`后端采集箱已有 ${set.size} 个 offer，本轮不会重复采集/上架`);
  }catch(e){ log("拉后端采集箱去重集合失败（将只按本地库去重）："+((e&&e.message)||e),"warn"); }
  return set;
}

async function loop(){
  // 控制器标签可能早就开着，面板点 start 不会触发 SS_AUTO_OPEN_CTRL；这里每次开跑都强制回填并落到 state.email。
  await ensureLoginEmail();
  await refreshEmail();
  await claimHistory();
  const c = state.cfg;
  // ③ 开跑前拉一次后端 offer 去重集合（本轮内新采的也会加进去，跨轮不重复）
  const knownOffers = await fetchInboxOfferIds();
  if(typeof state.nPrepared!=='number') state.nPrepared=0;
  state.running=true; persistRun();
  while(state.running && c && c.keywords.length){
    // ② 达到本次总目标数即自动停止，不再无限轮换关键词
    if(state.nPrepared >= (c.totalTarget||c.batchSize)){ log(`已达本次总目标 ${c.totalTarget||c.batchSize} 个，自动停止。`,"ok"); state.running=false; persistRun(); break; }
    if(state.paused){ await sleep(500); continue; }
    state.cycle++;
    const remain = (c.totalTarget||c.batchSize) - state.nPrepared;
    const round = Object.assign({}, c, { batchSize: Math.min(c.batchSize, remain) });
    log(`—— 第 ${state.cycle} 轮：${round.keywords[state.cycle%round.keywords.length]}（还需 ${remain}）——`);
    try{
      const batch=await collectBatch(round, knownOffers);
      if(!state.running) break; await sleep(c.delay);
      if(!batch.length){ log("本批没有新商品（都已采过/已在采集箱），停止"); state.running=false; persistRun(); break; }
      const results=await syncBatch(round, batch);
      if(!state.running) break; await sleep(c.delay);
      if(results.length){ await publishBatch(round, results); state.nPrepared+=results.length; }
      persistRun();
      await sleep(c.delay);
    }catch(e){ log("本轮异常："+(e.message||e)); persistRun(); await sleep(c.delay); }
  }
  state.running=false; persistRun();
  if(!state.running) log("已停止。");
}

function normalize(c){ c=c||{}; return { keywords:Array.isArray(c.keywords)&&c.keywords.length?c.keywords:[], shop:c.shop||"", market:c.market||"TH", totalTarget:Math.min(Math.max(Number(c.totalTarget)||Number(c.batchSize)||20,1),200), batchSize:Math.min(Math.max(Number(c.batchSize)||Number(c.totalTarget)||20,1),200), delay:Math.max(Number(c.delay)||6000,1500), handsOff:!!c.handsOff, draftOnly:c.draftOnly!==false, pubTimeout:Math.max(Number(c.pubTimeout)||90000,20000), targetMarginPct:Number(c.targetMarginPct)>0?Number(c.targetMarginPct):30, floatPct:Number.isFinite(Number(c.floatPct))?Number(c.floatPct):0, discountPct:Number.isFinite(Number(c.discountPct))?Math.min(Math.max(Number(c.discountPct),0),90):0 }; }
function snapshot(){ return { cycle:state.cycle, nCollect:state.nCollect, nSync:state.nSync, nPublish:state.nPublish, running:state.running, paused:state.paused, email:state.email||"", hasSession:!!state.hasSession, log:state.log.slice(-40).join("\n") }; }
// 店铺：形状容错（实测 /api/shops 200，但包装层可能是 data/shops/items 或裸数组）
async function listShops(){
  try{
    const d=await SS("/api/shops",{method:"GET"});
    const arr=Array.isArray(d)?d:((d&&(d.data||d.shops||d.items||d.list))||[]);
    if(!Array.isArray(arr)) return {ok:false,error:"/api/shops 返回不是数组："+Object.keys(arr||{}).join(",")};
    const shops=arr.map((s,i)=>({ id:String(s.id||s.shopId||s.shopCode||("shop"+i)), name:String(s.name||s.shopName||s.title||s.storeName||("店铺"+(i+1))) }));
    return {ok:true,shops};
  }catch(e){ return {ok:false,error:String((e&&e.message)||e)}; }
}

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(!msg||msg.type!=="SS_AUTO_CTRL")return;
  if(sender&&sender.tab) state.panelTabId=sender.tab.id;
  (async()=>{
    const a=msg.action;
    if(a==="ping"){ sendResponse({ok:true,ready:true}); return; }
    if(a==="start"){ state.cfg=normalize(msg.cfg); state.running=true; state.paused=false; state.cycle=0; state.nPrepared=0; persistRun(); sendResponse({ok:true}); loop(); return; }
    if(a==="pause"){ state.paused=!state.paused; persistRun(); sendResponse({ok:true,paused:state.paused}); return; }
    if(a==="stop"){ state.running=false; state.paused=false; persistRun(); sendResponse({ok:true}); return; }
    if(a==="status"){ await refreshEmail(); sendResponse({ok:true,data:snapshot()}); return; }
    if(a==="shops"){ sendResponse(await listShops()); return; }
    if(a==="publishExisting"){ state.cfg=normalize(msg.cfg); state.running=true; sendResponse({ok:true}); publishExisting(state.cfg); return; }
    sendResponse({ok:false,error:"未知 action "+a});
  })();
  return true;
});
document.addEventListener("DOMContentLoaded", ()=>{}); // 控制器纯消息驱动；tab 仅作运行载体

// 稳定性：控制页被 Chrome 丢弃/崩溃/重载后重新加载时，按持久化进度自动续跑未完成的自动化
//（10 分钟无心跳视为陈旧，不复活，避免老任务莫名重启）。
(async function resumeOnLoad(){
  try{
    const s = await new Promise(r=>{ try{ chrome.storage.local.get(RUNKEY,(x)=>r(x&&x[RUNKEY])); }catch(e){ r(null); } });
    if(!s || !s.running || !s.cfg || !Array.isArray(s.cfg.keywords) || !s.cfg.keywords.length) return;
    if(Date.now()-Number(s.at||0) > 10*60*1000){ try{ chrome.storage.local.remove(RUNKEY); }catch(e){} return; }
    state.cfg = normalize(s.cfg);
    state.cycle = Number(s.cycle)||0;
    state.nPrepared = Number(s.nPrepared)||0;
    state.paused = !!s.paused;
    state.running = true;
    log(`控制页重载·自动续跑上次未完成的自动化（第 ${state.cycle} 轮起，已处理 ${state.nPrepared} 个）`,"ok");
    loop();
  }catch(e){}
})();
