MiSans 子集 woff2 不入库（9.3MB 二进制）。
构建时由 scripts/build-market-scout.sh 从 plugins/.font-cache 或线上已发布包补齐。
