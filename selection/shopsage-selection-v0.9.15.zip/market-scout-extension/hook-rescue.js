/**
 * 拼多多「取数器没起来」的自动补救（2026-11-13 · 老板 #1：插件端对拼多多完全采不到信息）
 *
 * 证据（不是猜）：
 *  · 生产 API 日志 11/13 08:44:37 那条 PDD 采集诊断：
 *      url=https://mobile.yangkeduo.com/goods.html?goods_id=1012576239355
 *      {"goodsId":null,"reason":"hook_not_running","stage":"hook","hasContext":false}
 *  · 生产库 extension_collected_products 里 7 条采集**全部是 1688**，拼多多一条都没落库。
 *
 * 根因：page-hook.js 是 manifest 声明的 MAIN world 脚本，只在「页面加载那一刻」被注入。
 * 商家在装插件 / 更新插件**之前**就打开着的拼多多标签页里没有这个钩子；而拼多多的商品数据
 * 挂在页面自己的 window 对象上（ISOLATED 世界的 content script 看不见 window），
 * 钩子不在 = 注水数据和接口响应都抓不到 = 整页内容为空。表现就是「拼多多完全采不到信息」。
 *
 * 补救两步（顺序有讲究）：
 *  ① 当场把钩子补注进 MAIN world —— 不等重载，SPA 后续请求与 window 周期重扫立刻生效；
 *  ② 自动重载该标签页一次，等 load complete 再采 —— 这次声明式 content script 一定会跑。
 * 拼多多是异步把数据挂上 window 的，所以 complete 之后还要再等一小会儿。
 *
 * 铁律：
 *  · 一个标签页本次会话只自动重载一次（reloaded 集合），绝不来回刷商家的页面；
 *  · 救过什么、为什么刷页面，必须回话给界面，不许静默刷新；
 *  · 1688 有 DOM 兜底（domDetailFallback），不走这条路，别多刷一次页面；
 *  · 补救失败要说实话（注入失败 / 重载超时 / 重载后仍没数据，三种原因分别写清）。
 */
(function (root) {
  'use strict';

  var reloaded = new Set();          // 本次插件生命周期内已经自动重载过的 tabId
  var RELOAD_TIMEOUT_MS = 20000;
  var SETTLE_MS = 1500;              // PDD 异步挂数据，complete 之后再等一会儿

  function hostOf(url) {
    try { return new URL(String(url || '')).hostname.toLowerCase(); } catch (e) { return ''; }
  }

  function isPdd(url) {
    return /(^|\.)(pinduoduo|yangkeduo)\.com$/.test(hostOf(url));
  }

  /**
   * 要不要救：拼多多 + 详情页 + 整页内容没拿到。
   * content 存在且不是诊断包 ⇒ 已经采到了，不许再刷页面。
   */
  function needsRescue(list, url) {
    if (!isPdd(url)) return false;
    var first = list && list[0];
    if (!first) return false;
    var c = first.content;
    return !(c && !c.__msDiag);
  }

  /** 列表页的判据不一样：一条商品都没识别出来才救，识别到了就别动页面。 */
  function needsRescueForList(list, url) {
    return isPdd(url) && (!list || list.length === 0);
  }

  async function injectHook(tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['goods-shape.js', 'page-hook.js'],
        world: 'MAIN',
        injectImmediately: true,
      });
      return true;
    } catch (e) {
      return false;   // 没权限 / 页面不允许注入（chrome://、Web Store）
    }
  }

  function reloadAndWait(tabId) {
    return new Promise(function (resolve) {
      var settled = false;
      function finish(ok) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { chrome.tabs.onUpdated.removeListener(listener); } catch (e) { /* noop */ }
        resolve(ok);
      }
      function listener(id, info) {
        if (id === tabId && info && info.status === 'complete') finish(true);
      }
      var timer = setTimeout(function () { finish(false); }, RELOAD_TIMEOUT_MS);
      try { chrome.tabs.onUpdated.addListener(listener); } catch (e) { clearTimeout(timer); resolve(false); return; }
      try {
        chrome.tabs.reload(tabId, {});
      } catch (e) {
        finish(false);
      }
    });
  }

  function settle() {
    return new Promise(function (r) { setTimeout(r, SETTLE_MS); });
  }

  /**
   * @returns {{rescued:boolean, reason:string}} rescued=true 只表示「按预期刷完并等好了」，
   *          采没采到由调用方再看一次结果 —— 这里绝不替页面宣布成功。
   */
  async function rescue(tabId) {
    if (reloaded.has(tabId)) return { rescued: false, reason: 'already' };
    reloaded.add(tabId);
    var injected = await injectHook(tabId);
    var reloadedOk = await reloadAndWait(tabId);
    await settle();
    if (!injected) return { rescued: false, reason: 'inject_failed' };
    if (!reloadedOk) return { rescued: false, reason: 'reload_timeout' };
    return { rescued: true, reason: 'ok' };
  }

  root.MSRescue = {
    isPdd: isPdd,
    needsRescue: needsRescue,
    needsRescueForList: needsRescueForList,
    injectHook: injectHook,
    rescue: rescue,
    REASONS: {
      already: '这个页面刚才已经自动重载过一次了，不再反复刷；请手动刷新页面后再点采集。',
      inject_failed: '插件没能把取数器注进这个页面（该页不允许注入）。请手动刷新页面后再点采集。',
      reload_timeout: '页面 20 秒没加载完，可能卡在拼多多的验证或网络上。请手动刷新页面后再点采集。',
      ok: '已补挂取数器并重载页面。',
    },
    _reloaded: reloaded,
  };
})(typeof window !== 'undefined' ? window : this);
