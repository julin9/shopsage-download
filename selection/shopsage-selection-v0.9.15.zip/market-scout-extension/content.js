/**
 * ShopSage 选品助手 · 页面注入层（ISOLATED world）
 *
 * 只负责「把采集到的商品变成页面上的按钮」，取数全部交给 capture.js / page-hook.js。
 * 2026-11-08 重写要点：
 *   1. 拼多多不再依赖 <a href>（实测该结构在 PDD H5 上根本不存在），改吃数据块 + 接口钩子。
 *   2. chrome.runtime 调用全部加保护 —— 扩展重载后旧标签页的 content script 会拿到
 *      "Extension context invalidated"（chrome://extensions 里那条真实报错就是这个）。
 *   3. render 幂等 + 防抖，去掉 2.5 秒全量重扫。
 */
(() => {
  if (window.__marketScoutLoaded) return;
  window.__marketScoutLoaded = true;

  const HOST = location.hostname;
  const IS_1688 = /(^|\.)1688\.com$/.test(HOST);
  const IS_PDD = /(^|\.)(pinduoduo|yangkeduo)\.com$/.test(HOST);
  if (!IS_1688 && !IS_PDD) return;
  if (window.top !== window.self) return; // 只在顶层窗口挂 UI，避免 iframe 里重复一套工具栏

  const brandFont = document.createElement('link');
  brandFont.rel = 'stylesheet';
  try { brandFont.href = chrome.runtime.getURL('fonts.css'); } catch (e) { brandFont.href = 'https://www.shopsage.cc/fonts.css'; }
  if (brandFont.href) (document.head || document.documentElement).appendChild(brandFont);

  const selected = new Map();      // url -> product
  const apiItems = new Map();      // goodsId -> item（page-hook.js 递来的接口数据）
  let lastSignature = '';

  const clean = v => String(v == null ? '' : v).replace(/[\s​]+/g, ' ').trim();

  /* ── 与后台扩展的通信一律带保护 ─────────────────────────────────── */
  function alive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }
  function sendRuntime(msg) {
    if (!alive()) { toast('扩展已更新，请刷新本页面后再采集'); return; }
    try { chrome.runtime.sendMessage(msg); }
    catch (e) { toast('扩展已更新，请刷新本页面后再采集'); }
  }

  function toast(message) {
    document.querySelector('.ms-toast')?.remove();
    const el = document.createElement('div');
    el.className = 'ms-toast';
    el.textContent = message;
    document.documentElement.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  /* ── 存储 ───────────────────────────────────────────────────────── */
  async function saveProducts(products) {
    if (!alive()) { toast('扩展已更新，请刷新本页面后再采集'); return; }
    /* 2026-11-13（老板 #1）：本地库按登录账号分区，读写都走 MSStore，不再碰整包 products。
       没登录时采的条目落进「未归属」桶，ownerEmail 为空 ⇒ 后续一律不许同步（要同步请登录后重采）。 */
    let bucketKey, items, ownerEmail;
    try {
      const store = await window.MSStore.readAll();
      bucketKey = store.key;
      items = Array.isArray(store.mine) ? store.mine.slice() : [];
      ownerEmail = store.email;
    } catch (e) { toast('扩展已更新，请刷新本页面后再采集'); return; }
    const idx = new Map(items.map((i, n) => [i.url, n]));
    let added = 0, updated = 0, fullUpdated = 0;
    /* 内容完整度打分：诊断包一律算 0 分——空壳永远不能冒充「整页内容已采到」 */
    const scoreOf = (c) => (!c || c.__msDiag) ? 0 : [
      c.title, Array.isArray(c.images) && c.images.length, Array.isArray(c.skus) && c.skus.length,
      Array.isArray(c.props) && c.props.length, typeof c.descriptionHtml === 'string' && c.descriptionHtml.length,
      c.video && c.video.url, c.categoryId,
    ].filter(Boolean).length;
    for (const p of products) {
      if (!p || !p.url || !p.title) continue;
      if (!p.ownerEmail && ownerEmail) p.ownerEmail = ownerEmail;
      const c = contentForUrl(p.url);
      if (c) p.content = c;
      /* 列表页/DOM 没抓到价格或主图时，用详情页数据包里的官方值回填（带来源口径，不是猜）：
         实测有些详情页 DOM 结构变了导致价/图为空，但 window.context 里价格阶梯和主图组都在。 */
      if (c && !c.__msDiag) {
        if (p.price == null) {
          const ladder = Array.isArray(c.priceRange) ? c.priceRange : [];
          /* 取「起订量最低的那一档」当展示价：阶梯价越往下量单价越低，
             按第一档（起订量）算成本才是保守口径；之前直接取 ladder[0]，
             页面数组顺序一变就会拿大批量价去算利润（2026-11-11 修）。
             同一起订量里页面常给两套价：现价（可能含促销）与非促销原价。
             成本必须走【非促销原价】那一套——线上实测有商品把促销价 7.7 和原价 11~24 并列，
             取错就把成本低估三成（2026-11-11 生产探针实测）。只剩促销价时，
             如实标 priceNeedsReview，让界面继续提示「请核对采购价」，不假装这是确定成本。 */
          const priced = ladder.filter((x) => x && Number(x.price) > 0)
            .sort((a, b) => (Number(a.beginAmount) || 0) - (Number(b.beginAmount) || 0));
          const moq = priced.length ? (Number(priced[0].beginAmount) || 0) : 0;
          const moqRows = priced.filter((x) => (Number(x.beginAmount) || 0) === moq);
          const base = moqRows.find((x) => x.kind === 'original') || moqRows[0] || null;
          if (base) {
            p.price = Number(base.price);
            p.priceNeedsReview = base.kind !== 'original';
            p.priceAxis = base.kind === 'original' ? 'original' : 'promo';
            p.priceSource = '页面价格阶梯（window.context 官方数据）';
          }
        }
        // 主图组首图直接覆盖 DOM 抓到的图：DOM 在列表/推荐位上会抓错（实测抓到「牛头」图）
        if (Array.isArray(c.images) && c.images.length) { p.image = c.images[0]; p.imageSource = "1688 主图组首图（window.context）"; }
      }   // 详情页采集：整页内容随商品走（列表卡片 c 为 null，不挂）
      if (c) p.contentStatus = c.__msDiag ? 'DIAG' : (scoreOf(c) >= 3 ? 'FULL' : 'PARTIAL');
      const at = idx.get(p.url);
      if (at != null) {
        // 已在选品库：列表卡片重复采集不动；详情页重采时只允许「更完整」的内容替换，绝不抹掉已有底稿
        const previous = items[at];
        /* 同分时「新采的赢」：之前用 > 会让修好口径的重采永远写不进去（实测：
           旧条目存的是带 var offer_details= 外壳的描述，重采拿到干净 HTML 却因分数相同被丢弃）。
           但用户手工改过的采购价绝不能被覆盖。 */
        if (p.content && !p.content.__msDiag && scoreOf(p.content) >= scoreOf(previous.content) && scoreOf(p.content) > 0) {
          items[at] = { ...previous, ...p, price: previous.price || p.price };
          updated++;
          if (items[at].contentStatus === 'FULL') fullUpdated++;
        }
        continue;
      }
      items.unshift(p); idx.set(p.url, 0); added++;
    }
    try {
      await window.MSStore.writeBucket(bucketKey, items);
      toast(added ? `已采集 ${added} 个商品，选品库共 ${Math.min(items.length, 500)} 个`
        : fullUpdated ? '整页内容已补全，去后台编辑查看'
        : updated ? '内容有部分更新，去后台编辑页核对'
        : '商品已在选品库中');
    } catch (e) { toast('保存失败：' + (e && e.message ? e.message : e)); }
  }

  /* ── page-hook.js（MAIN world）递来的数据块/接口数据 ─────────────────
     不校验 ev.source：实测跨世界 postMessage 的 source 比较不可靠，
     载荷自带 __msPddApi 标识已足够判定来源。 */
  window.addEventListener('message', ev => {
    if (!ev.data || ev.data.__msPddApi !== 1) return;
    (Array.isArray(ev.data.items) ? ev.data.items : []).forEach(it => {
      if (it && it.goodsId && it.title && !apiItems.has(it.goodsId)) apiItems.set(it.goodsId, it);
    });
    scheduleRender();
  });

  /* ── 整页内容采集（妙手式编辑器的数据底座，2026-11-09）──────────────────
     page-hook 在详情页把整包注水 JSON（1688 __INIT_DATA__ / PDD rawData）递过来，
     这里归一化成编辑器要的文档：标题/主图组/SKU 表/属性/物流/详情图/原链。
     规格名能解析就解析（skuProps pid/name 对照 skuInfoMap 键），
     解析不出就保留原始键——绝不编一个规格名出来。 */
  let fullContent = null;   // { goodsId, host, doc }
  const fullChunks = new Map();

  function asUrlList(v) {
    if (typeof v === 'string') return v.trim() ? [v.trim()] : [];
    if (Array.isArray(v)) return v.map(x => (typeof x === 'string' ? x : (x && (x.url || x.img || x.src)) || '')).filter(Boolean).slice(0, 30);
    if (v && typeof v === 'object') return Object.values(v).map(x => (typeof x === 'string' ? x : (x && (x.url || x.img || x.src)) || '')).filter(Boolean).slice(0, 30);
    return [];
  }


  function bestEffortSkus(skuModel) {
    if (!skuModel || typeof skuModel !== 'object') return [];
    const props = Array.isArray(skuModel.skuProps) ? skuModel.skuProps : [];
    const map = (skuModel.skuInfoMap && typeof skuModel.skuInfoMap === 'object') ? skuModel.skuInfoMap : {};
    // pid → 属性名；vid → 选项名（vid 可能在 prop.values 数组里，也可能在逗号串里按序对应）
    const propName = {}, valueName = {};
    props.forEach(p => {
      const pid = String(p.pid != null ? p.pid : '');
      if (pid) propName[pid] = p.name || p.prop || pid;
      if (Array.isArray(p.values)) p.values.forEach(v => { if (v && v.vid != null) valueName[pid + ':' + v.vid] = v.name || v.value || v.vid; });
      else if (typeof p.value === 'string') {
        const vids = String(p.vids || '').split(',').filter(Boolean);
        const names = p.value.split(',').filter(Boolean);
        names.forEach((nm, i) => { const vid = vids[i] != null ? vids[i] : String(i); valueName[pid + ':' + vid] = nm; });
      }
    });
    const skus = [];
    Object.keys(map).slice(0, 300).forEach(key => {
      const sku = map[key] || {};
      const parts = String(key).split(';').map(part => {
        const [pid, vid] = part.split(':');
        return valueName[pid + ':' + vid] || propName[pid] || part;
      });
      const price = sku.price != null ? Number(sku.price) : (sku.priceInfo && sku.priceInfo[0] && Number(sku.priceInfo[0].price));
      skus.push({
        spec: parts.join(' / ') || key,
        price: Number.isFinite(price) && price > 0 ? price : null,
        stock: sku.quantity != null ? Number(sku.quantity) : (sku.canBookCount != null ? Number(sku.canBookCount) : null),
        rawKey: key.slice(0, 60),
      });
    });
    return skus;
  }

  function pickModules(data) {
    // data 的 key 是 13 位随机串，值里带模块名（@ali/tdmod-od-pc-attribute-new 等）——按内容找
    const out = {};
    if (!data || typeof data !== 'object') return out;
    Object.values(data).forEach(mod => {
      if (!mod || typeof mod !== 'object') return;
      const name = String(mod.name || mod.moduleName || '');
      if (name.includes('attribute')) out.props = mod;
      else if (name.includes('logistics')) out.logistics = mod;
      else if (name.includes('description')) out.desc = mod;
      else if (name.includes('main-pic')) out.pics = mod;
    });
    return out;
  }

  function detailSeller() {
    const selectors = ['[class*="company" i] [class*="name" i]', '[class*="shop" i] [class*="name" i]', '[class*="company" i]', '[class*="shop" i]'];
    for (const selector of selectors) {
      const text = clean(document.querySelector(selector)?.innerText || '').split('\n')[0];
      if (text && text.length < 180 && /公司|厂|店|商行/.test(text)) return text;
    }
    return '';
  }

  /** 阶梯归一：只认页面真实给的 price/beginAmount/endAmount(endingAmount)，并按起订量升序；没价就返回 null。 */
  function normalizeLadder(raw) {
    if (!Array.isArray(raw) || !raw.length) return null;
    const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : null; };
    const out = [];
    raw.forEach((r) => {
      if (!r || typeof r !== 'object') return;
      const price = n(r.price != null ? r.price : r.discountPrice);
      if (price == null || !(price > 0)) return;
      const beginAmount = n(r.beginAmount != null ? r.beginAmount : r.quantityBegin ?? r.startQuantity ?? null);
      const endAmount = r.endAmount != null ? n(r.endAmount) : (r.endingAmount != null ? n(r.endingAmount) : null);
      if (out.some((x) => x.price === price && x.beginAmount === beginAmount)) return;
      out.push({ price, beginAmount, endAmount, from: String(r.__from || 'globalData.skuPriceScale|priceRange').slice(0, 60) });
    });
    if (!out.length) return null;
    out.sort((a, b) => (a.beginAmount == null ? 0 : a.beginAmount) - (b.beginAmount == null ? 0 : b.beginAmount));
    return out.slice(0, 12);
  }

  /** 旧版页面的阶梯探针：页面 globalData 里到底有哪些带 price 字样的数组、字段名是什么。 */
  function legacyLadderProbe(g) {
    try {
      const keys = Object.keys(g || {});
      const priceArrays = keys
        .filter((k) => /price|scale|range|ladder/i.test(k) && Array.isArray(g[k]) && g[k].length)
        .slice(0, 10)
        .map((k) => ({ path: k, length: Math.min(g[k].length, 999), firstRowKeys: (g[k][0] && typeof g[k][0] === 'object') ? Object.keys(g[k][0]).slice(0, 14).map((s) => String(s).slice(0, 30)) : [typeof g[k][0]] }));
      return { tried: ['globalData.skuPriceScale', 'globalData.priceRange'], priceArrays, globalDataPriceKeys: keys.filter((k) => /price|scale|range/i.test(k)).slice(0, 20) };
    } catch (e) { return null; }
  }

  /* ─────────────────────────────────────────────────────────────────────────────
     2026-11-13 老板两条点名：①「拼多多要能像 1688 一样采全部信息」②「1688 采不到标题」。
     两条都按同一套纪律补：页面真给了才写，取不到就留 null 并把「试过哪些来源」如实记进 probe，
     这样下次一看就知道是页面确实没有、还是我们漏了 —— 绝不猜一个数填进格子。
     ───────────────────────────────────────────────────────────────────────────── */

  /** 站点后缀清洗：只剥「商品标题 - 阿里巴巴 / | 1688 / - 拼多多」这类尾巴，正文一个字不动。 */
  function stripSiteSuffix(t) {
    return String(t || '')
      .replace(/\s*[|｜]\s*(阿里巴巴|1688\.com|1688|拼多多|Pinduoduo|商品详情页)\s*$/i, '')
      .replace(/\s*[-–—]\s*(阿里巴巴|1688\.com|1688|拼多多|Pinduoduo)\s*$/i, '')
      .trim();
  }

  /** DOM/元数据里的标题兜底链：每个来源都记下来，全空时 probe 能看出页面到底给了什么。 */
  function pageTitleProbe() {
    const tried = [];
    const pick = (label, value) => {
      const v = stripSiteSuffix(clean(value));
      tried.push({ from: label, len: v.length });
      return v;
    };
    const order = [
      ['meta[property=og:title]', () => document.querySelector('meta[property="og:title"]')?.content],
      ['meta[itemprop=name]', () => document.querySelector('meta[itemprop="name"]')?.content],
      ['meta[name=title]', () => document.querySelector('meta[name="title"]')?.content],
      ['link[rel=canonical]+h1', () => document.querySelector('h1')?.innerText],
      ['json-ld.name', () => {
        try {
          const nodes = Array.from(document.querySelectorAll('script[type="application/ld+json"]')).slice(0, 6);
          for (const n of nodes) {
            const j = JSON.parse(String(n.textContent || '{}'));
            const cand = Array.isArray(j) ? j : [j];
            for (const c of cand) {
              const name = c && (c.name || (c.mainEntity && c.mainEntity.name));
              if (name && typeof name === 'string' && name.length > 6) return name;
            }
          }
        } catch (e) { /* JSON-LD 解析失败：如实进 probe，不猜 */ }
        return '';
      }],
      ['document.title', () => document.title],
    ];
    for (const [label, get] of order) {
      let v = '';
      try { v = pick(label, get() || ''); } catch (e) { v = ''; }
      // 「XX有限公司/旗舰店」这类公司名不是商品标题（1688 列表页实测会串味），一律不收
      if (v.length >= 6 && !/有限公司|公司$|旗舰店$|专营店$/.test(v)) return { title: v, from: label, tried };
    }
    return { title: '', from: null, tried };
  }

  /** 拼多多阶梯价/多件价：只认页面真给的数组键，取不到就 null + probe（与 1688 同一把尺）。 */
  function pddLadder(g) {
    const candidates = [
      ['skuPriceScale', g.skuPriceScale], ['priceRange', g.priceRange], ['priceTiers', g.priceTiers],
      ['bulkPrice', g.bulkPrice], ['promotionPriceList', g.promotionPriceList],
      ['sku.priceScale', (g.sku && g.sku.priceScale)], ['goods.priceScale', (g.goods && g.goods.priceScale)],
    ];
    const tried = candidates.map(([k]) => k);
    for (const [label, raw] of candidates) {
      const ladder = normalizeLadder(Array.isArray(raw) ? raw.map((r) => (r && typeof r === 'object' ? { ...r, __from: 'rawData.' + label } : r)) : raw);
      if (ladder) return { ladder, probe: { tried, hit: label } };
    }
    let probe;
    try {
      const keys = Object.keys(g || {});
      probe = {
        tried,
        hit: null,
        priceArrays: keys.filter((k) => /price|scale|range|ladder|tier|bulk/i.test(k) && Array.isArray(g[k]) && g[k].length)
          .slice(0, 10)
          .map((k) => ({ path: k, length: Math.min(g[k].length, 999), firstRowKeys: (g[k][0] && typeof g[k][0] === 'object') ? Object.keys(g[k][0]).slice(0, 14).map((s) => String(s).slice(0, 30)) : [typeof g[k][0]] })),
        priceKeys: keys.filter((k) => /price|scale|range|tier|bulk|quantity/i.test(k)).slice(0, 24),
      };
    } catch (e) { probe = { tried, hit: null, error: String(e && e.message || e).slice(0, 120) }; }
    return { ladder: null, probe };
  }

  /** 首个真数：页面没给就是 null，绝不拿 0 顶（销量/评价数这类「没有」和「0」必须分得开）。 */
  function firstNumber(obj, keys) {
    for (const k of keys) {
      const v = obj && obj[k];
      if (v == null || v === '') continue;
      const n = Number(typeof v === 'string' ? v.replace(/[^\d.]/g, '') : v);
      if (Number.isFinite(n)) return { value: n, from: k };
    }
    return { value: null, from: null };
  }

  function normalize1688(d) {
    const g = d.globalData || (d.offer_details && typeof d.offer_details === 'object' ? d.offer_details : d);
    const mods = pickModules(d.data);
    const titleFromModule = mods.title?.value?.title ?? mods.title?.value?.name ?? '';
    const seller = clean(g.companyName || g.sellerName || g.supplierName || g.shopName || g.company || detailSeller());
    const domTitle = clean(document.querySelector('[class*="od-title" i], [class*="offer-title" i], [class*="title-text" i], h1')?.innerText || '');
    const isCompanyTitle = value => /有限公司|公司$|旗舰店$|专营店$/.test(clean(value));
    // 2026-11-13 老板点名「1688 采不到标题」：原来只认 globalData 的几个键 + 一个 DOM 选择器，
    // 新版页面（注水里标题在别处 / 类名改了）就会交白卷。现在把元数据与 JSON-LD 也纳入兜底链，
    // 并且全落空时把「试过哪些来源、各拿到几个字」如实写进 titleProbe —— 下次一眼看出是页面真没有还是我们漏了。
    const metaTitle = pageTitleProbe();
    const titleChain = [g.title, g.subject, g.offerTitle, titleFromModule, (!isCompanyTitle(domTitle) ? domTitle : ''), metaTitle.title];
    const productTitle = clean(titleChain.find((v) => clean(v).length >= 6) || '');
    const titleSource = productTitle
      ? (['g.title', 'g.subject', 'g.offerTitle', 'module.title', 'dom.h1/od-title', 'meta/json-ld'][titleChain.findIndex((v) => clean(v).length >= 6)] || 'unknown')
      : null;
    const doc = {
      host: '1688',
      title: productTitle,
      titleSource,
      titleProbe: productTitle ? null : { tried: metaTitle.tried, note: '注水数据、模块、DOM 与元数据都没给出可用标题' },
      seller,
      images: asUrlList(g.images || g.imageList || g.detailImages || g.productImages),
      /* 旧版页面（globalData 那一套）的阶梯：只认页面真实给的键，取不到就是 null，不编。
         probe 如实记下「试过哪几个键、页面 globalData 里有哪些带 price 的数组」，
         这样阶梯没落库时能看出是页面真没给还是我们漏了（2026-11-11 定口径）。 */
      priceRange: normalizeLadder(g.skuPriceScale || g.priceRange || null),
      priceRangeProbe: legacyLadderProbe(g),
      category: clean(g.category || g.categoryName || g.categoryText) || null,
      skuProps: Array.isArray(g?.skuModel?.skuProps) ? g.skuModel.skuProps.slice(0, 6) : (Array.isArray(g.skuProps) ? g.skuProps.slice(0, 6) : []),
      skus: bestEffortSkus(g?.skuModel || { skuProps: g.skuProps || [], skuInfoMap: g.skuInfoMap || g.skuMap || {} }),
      props: Array.isArray(mods.props?.value?.props) ? mods.props.value.props.slice(0, 40)
        : (Array.isArray(mods.props?.props) ? mods.props.props.slice(0, 40) : []),
      logistics: mods.logistics ? { weight: mods.logistics.value?.weight ?? null, note: clean(mods.logistics.value?.logisticsTips || '').slice(0, 120) || null } : null,
      detailUrl: mods.desc?.value?.detailUrl || mods.desc?.value?.descUrl || mods.desc?.value?.url || g.detailUrl || g.descUrl || null,
      detailImages: [],
      descriptionHtml: String(mods.desc?.value?.html || mods.desc?.value?.content || mods.desc?.value?.description || g.descriptionHtml || g.description || '').slice(0, 200000),
      // 整包原文截断存档：归一化漏掉的字段以后还能从 raw 里挖，不丢原始数据
      raw: JSON.stringify(d).slice(0, 200000),
    };
    return doc;
  }

  function normalizePDD(d) {
    const rootGoods = d.goods && typeof d.goods === 'object' ? d.goods
      : d.store && d.store.goods ? d.store.goods
      : d.goodsDetail && typeof d.goodsDetail === 'object' ? d.goodsDetail
      : d;
    const g = rootGoods.goods && typeof rootGoods.goods === 'object' ? rootGoods.goods : rootGoods;
    const gallery = [g.thumbUrl, g.hdThumbUrl, g.goodsGallery, g.gallery, g.galleries,
      g.goodsImageList, g.goods_image_list, g.detailGallery, g.detail_gallery].flatMap(asUrlList);
    const imageList = Array.from(new Set(gallery.map(x => String(x).startsWith('//') ? 'https:' + x : x))).slice(0, 60);
    const skuSource = Array.isArray(g.skus) ? g.skus
      : (g.skus && typeof g.skus === 'object') ? Object.values(g.skus)
      : Array.isArray(g.skuList) ? g.skuList : [];
    const skus = skuSource.slice(0, 500).map(s => {
      const specs = Array.isArray(s.specs) ? s.specs.map(x => clean(x?.spec_value || x?.specValue || x?.name || x?.value || '')).filter(Boolean)
        : Array.isArray(s.specList) ? s.specList.map(x => clean(x?.spec_value || x?.name || x?.value || '')).filter(Boolean) : [];
      const rawPrice = s.normalPrice ?? s.groupPrice ?? s.price ?? s.marketPrice ?? null;
      const price = rawPrice == null ? null : Number(rawPrice) / (Number(rawPrice) >= 100 ? 100 : 1);
      return {
        skuId: String(s.skuId ?? s.sku_id ?? ''),
        spec: specs.join(' / ') || clean(String(s.spec || s.specsText || '').replace(/\^/g, ' / ')) || null,
        price: Number.isFinite(price) && price > 0 ? Math.round(price * 100) / 100 : null,
        stock: s.quantity == null && s.stock == null ? null : Number(s.quantity ?? s.stock),
        raw: s,
      };
    });
    const doc = {
      host: 'pdd',
      /* 2026-11-13 与 1688 同批补齐：标题也走兜底链（注水 → DOM → 元数据/JSON-LD），
         站点后缀「- 拼多多」这类尾巴一律剥掉，全落空时留 probe。 */
      title: (() => {
        const chain = [g.goodsName, g.goods_name, g.title, g.goods && g.goods.goodsName, pageTitleProbe().title];
        const hit = chain.map((v) => stripSiteSuffix(clean(v))).find((v) => v.length >= 6);
        return hit || '';
      })(),
      images: imageList,
      /* 老板点名「拼多多要像 1688 一样采全部信息」：以前这里写死 null，
         后端成本引擎永远只能读到「没阶梯」，利润就算不到多件单价。
         现在真去页面的候选键里找，找到就按 1688 同一结构落档，找不到就 null + probe 说明试过哪些键。 */
      priceRange: pddLadder(g).ladder,
      priceRangeProbe: pddLadder(g).probe,
      /* 销量与评价数：PDD 页面给的是 soldNum / commentCount 一族键，取不到一律 null（不是 0）。 */
      saleNum: firstNumber(g, ['soldNum', 'soldQuantity', 'goodsSaleCount', 'saleNum', 'totalSoldQuantity', 'soldQty', 'salesCount']).value,
      saleNumSource: firstNumber(g, ['soldNum', 'soldQuantity', 'goodsSaleCount', 'saleNum', 'totalSoldQuantity', 'soldQty', 'salesCount']).from,
      commentCount: firstNumber(g, ['commentCount', 'totalCommentCount', 'reviewCount', 'commentNum', 'goodsCommentCount']).value,
      priceNote: clean(g.priceTip || g.priceNote || g.priceDesc || g.skuOfferPriceTip || '') || null,
      categoryId: g.categoryId != null ? String(g.categoryId) : (g.leafCategoryId != null ? String(g.leafCategoryId) : null),
      category: clean(g.categoryName || (g.category && g.category.name)) || null,
      skuProps: Array.isArray(g.skuProps) ? g.skuProps : (Array.isArray(g.specs) ? g.specs : []),
      skus,
      props: Array.isArray(g.goodsProperties) ? g.goodsProperties
        : Array.isArray(g.properties) ? g.properties : Array.isArray(g.goods_property_list) ? g.goods_property_list : [],
      logistics: { weight: g.weight ?? g.goodsWeight ?? g.goods_weight ?? null, note: clean(g.deliveryInfo || g.logisticsTips || '') || null },
      detailUrl: null,
      detailImages: asUrlList(g.detailGallery || g.detail_gallery || g.detailImages || g.detail_images),
      descriptionHtml: String(g.goodsDesc || g.goods_desc || g.description || '').slice(0, 200000),
      raw: JSON.stringify(d).slice(0, 200000),
    };
    return doc;
  }

  /* 详情描述是懒加载的（1688 走 detailUrl 单独请求）：隔离世界在同一 1688 源上，
     直接 fetch 那个地址抠 <img>——拿不到就如实留空，不编。 */
  async function fetchDetailContent(detailUrl) {
    if (!detailUrl) return { images: [], html: '' };
    let timeout;
    try {
      const url = detailUrl.startsWith('//') ? 'https:' + detailUrl : detailUrl;
      const controller = new AbortController();
      timeout = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(url, { credentials: 'omit', signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) return { images: [], html: '' };
      const sourceHtml = await res.text();
      const doc = new DOMParser().parseFromString(sourceHtml, 'text/html');
      const images = Array.from(doc.querySelectorAll('img'))
        .map(im => im.getAttribute('src') || im.getAttribute('data-src') || '')
        .map(s => s.startsWith('//') ? 'https:' + s : s)
        .filter(s => /alicdn|img|jpg|png/i.test(s))
        .slice(0, 16);
      const description = doc.querySelector('#desc-lazyload-container,.module_description,.detail-content,[class*="description"]') || doc.body;
      const html = String(description?.innerHTML || '').slice(0, 200000);
      if (!html && !images.length) return { images: [], html: '' };
      return { images, html };
    } catch (e) { if (timeout) clearTimeout(timeout); return { images: [], html: '' }; }
  }

  async function acceptFull(msg) {
    let data = null;
    try {
      if (!msg || !msg.goodsId) return;
      try { data = JSON.parse(msg.raw); } catch (e) { return; }
      /* 0.9.8：page-hook 递回统一信封 {__msEnvelope, layout, host, data, extra}。
         新版 1688 数据包在 window.context（result.data.<模块>.fields），归一化交给 normalize.js
         ——它能拿真实页面样本离线跑回归（2026-11-09 实测 21/21 通过）；
         旧版 globalData/skuModel 那一套继续走 normalize1688，别把老布局打掉。
         extra.offerDetails 是详情描述 HTML（实测 offer_details.content，1.7KB/10 个 <img>）。 */
      const envelope = !!(data && data.__msEnvelope === 1);
      const packet = envelope ? data.data : data;
      const extra = envelope ? data.extra : null;
      let doc = null;
      if (msg.host === '1688') {
        if (window.MS_NORMALIZE && window.MS_NORMALIZE.looksLike1688Context(packet)) {
          doc = window.MS_NORMALIZE.from1688Context(packet, extra);
        }
        if (!doc || !(window.MS_NORMALIZE && window.MS_NORMALIZE.isRealDoc(doc))) doc = normalize1688(packet) || doc;
        if (doc && window.MS_NORMALIZE && !window.MS_NORMALIZE.isRealDoc(doc)) doc = null;
      } else if (msg.host === 'pdd') {
        doc = normalizePDD(packet);
        if (doc && window.MS_NORMALIZE && !window.MS_NORMALIZE.isRealDoc(doc)) doc = null;
      }
      if (!doc) {
        // 拿到了包但归一化出来是空壳——记成诊断，绝不当成「整页内容已采到」骗人
        lastDiag = {
          goodsId: String(msg.goodsId), stage: 'normalize', error: 'normalized_empty_doc',
          layout: envelope ? data.layout : 'legacy', url: location.href.slice(0, 160), ts: Date.now(),
        };
        try { document.documentElement.setAttribute('data-ms-diag', JSON.stringify(lastDiag).slice(0, 4000)); } catch (eDiag) { /* noop */ }
        return;
      }
      const current = fullContent && fullContent.goodsId === String(msg.goodsId) ? fullContent.doc : null;
      const score = value => (value.title ? 1 : 0) + (value.seller ? 1 : 0)
        + (Array.isArray(value.images) ? Math.min(value.images.length, 20) : 0)
        + (Array.isArray(value.skus) ? Math.min(value.skus.length, 20) : 0)
        + (Array.isArray(value.props) ? Math.min(value.props.length, 10) : 0)
        + (typeof value.descriptionHtml === 'string' ? Math.min(value.descriptionHtml.length / 1000, 30) : 0);
      if (current && score(doc) <= score(current)) {
        window.postMessage({ __msFullAck: 1, goodsId: String(msg.goodsId) }, '*');
        return;
      }
      if (current) {
        doc.title = doc.title || current.title;
        doc.seller = doc.seller || current.seller;
        doc.images = Array.from(new Set([...(current.images || []), ...(doc.images || [])])).slice(0, 60);
        doc.skus = doc.skus?.length ? doc.skus : (current.skus || []);
        doc.skuProps = doc.skuProps?.length ? doc.skuProps : (current.skuProps || []);
        doc.props = doc.props?.length ? doc.props : (current.props || []);
        doc.descriptionHtml = doc.descriptionHtml || current.descriptionHtml || '';
        doc.video = doc.video || current.video || null;
        doc.categoryId = doc.categoryId || current.categoryId || null;
        doc.weight = doc.weight && doc.weight.kg != null ? doc.weight : (current.weight || doc.weight);
        doc.raw = doc.raw || current.raw;
      }
      // 主数据先落地：整页内容立即可用，不等详情长图——生产实测 fetchDetailImages 会被
      // 1688 风控拖住几秒到几十秒，await 期间 popup 同步拿到的 content 是 null（2026-11-09 钉死）。
      const detailPromise = doc.detailUrl ? fetchDetailContent(String(doc.detailUrl)).then(result => {
        if (result.images.length) doc.detailImages = result.images;
        if (result.html && !doc.descriptionHtml) doc.descriptionHtml = result.html;
      }) : Promise.resolve();
      fullContent = { goodsId: String(msg.goodsId), host: doc.host, doc, detailPromise };
      window.postMessage({ __msFullAck: 1, goodsId: String(msg.goodsId) }, '*');
    } catch (e) {
      // 归一化抛错：把错误随诊断回报（老板重采后可从库里读真实报错），绝不让页面崩
      lastDiag = {
        goodsId: String((msg && msg.goodsId) || ''),
        error: e instanceof Error ? e.message : String(e),
        stage: 'normalize',
        url: (msg && msg.url) || '',
      };
    }
  }

  window.addEventListener('message', ev => {
    if (!ev.data || ev.data.__msFull !== 1) return;
    void acceptFull(ev.data);
  });
  window.addEventListener('message', ev => {
    const msg = ev.data;
    if (!msg || msg.__msFullChunk !== 1 || !msg.goodsId || !Number.isInteger(msg.index) || !Number.isInteger(msg.total)) return;
    if (msg.total < 2 || msg.total > 4 || msg.index < 0 || msg.index >= msg.total) return;
    const key = String(msg.goodsId);
    if (fullContent && fullContent.goodsId === key) return;
    let entry = fullChunks.get(key);
    if (!entry || entry.total !== msg.total) {
      entry = { total: msg.total, parts: new Array(msg.total), size: 0 };
      fullChunks.set(key, entry);
    }
    if (typeof msg.raw !== 'string' || entry.parts[msg.index] != null) return;
    entry.parts[msg.index] = msg.raw;
    entry.size += msg.raw.length;
    if (entry.size > 800000) { fullChunks.delete(key); return; }
    if (entry.parts.every(part => typeof part === 'string')) {
      fullChunks.delete(key);
      void acceptFull({ __msFull: 1, goodsId: key, host: msg.host, raw: entry.parts.join('') });
    }
  });
  let lastDiag = null;   // 详情页缺数据包时的诊断回报

  window.addEventListener('message', ev => {
    if (!ev.data || ev.data.__msDiag !== 1) return;
    lastDiag = { goodsId: String(ev.data.goodsId || ''), candidates: ev.data.candidates || [], ready: ev.data.ready, url: ev.data.url };
  });

  /** 当前详情页的整页内容（给「采集到选品库」和同步 payload 挂上）；没有就是 null，不编。 */
  function contentForUrl(url) {
    if (!fullContent) {
      // 没抓到整页内容时回诊断包（带 __msDiag 标记，采集端与后端都绝不把它当底稿存）
      try {
        const gid = String(((url || '').match(/offer\/(\d{6,})/) || (url || '').match(/goods_?id=(\d{6,})/i) || ['', ''])[1] || '');
        if (lastDiag && lastDiag.goodsId === gid) return { __msDiag: true, diag: lastDiag };
      } catch (e) { /* noop */ }
      return null;
    }
    try {
      // 只取捕获组（纯数字 goodsId）。之前用 filter(Boolean).find(Boolean) 会取到
      // 整个匹配串 "offer/106539746982"，与 page-hook 的 goodsId（纯数字）永远对不上，
      // 导致 popup 同步链路 content 恒为 null——已用生产真实页面钉死。
      const m = (url || '').match(/offer\/(\d{6,})/) || (url || '').match(/goods_?id=(\d{6,})/i);
      const gid = m ? m[1] : '';
      return fullContent.goodsId === gid ? fullContent.doc : null;
    } catch (e) { return null; }
  }

  async function contentForUrlAsync(url) {
    const doc = contentForUrl(url);
    if (!doc || doc.__msDiag) return doc;
    try { await fullContent?.detailPromise; } catch (e) { /* preserve the captured base document */ }
    // PDD 主图通常在 goods 数据里；1688 图组可能只在延迟描述片段中，归一到统一图片字段。
    if (fullContent && Array.isArray(fullContent.doc.detailImages) && fullContent.doc.detailImages.length) {
      fullContent.doc.images = Array.from(new Set([...(fullContent.doc.images || []), ...fullContent.doc.detailImages])).slice(0, 60);
    }
    return contentForUrl(url);
  }

  function apiProducts() {
    const origin = location.origin;
    return Array.from(apiItems.values()).map(it => ({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2),
      title: it.title,
      price: (window.MS_SHAPE && it.rawPrice != null && it.rawPrice > 0)
        ? Math.round(window.MS_SHAPE.toYuan(it.rawPrice, null) * 100) / 100
        : null,
      priceNeedsReview: true,
      priceSource: '页面数据价（MAIN world 取数，单位由 goods-shape 判定）',
      currency: 'CNY',
      image: it.image || '',
      url: origin + '/goods.html?goods_id=' + encodeURIComponent(it.goodsId),
      platform: '拼多多', source: '拼多多', specs: '',
      salesTip: it.salesTip || '', capturePath: '接口钩子',
      capturedAt: new Date().toISOString()
    }));
  }

  /** 当前页可采商品 = 数据块/DOM 结果 ∪ 接口钩子结果（按 url 去重，前者优先，因为它带可见价）。 */
  function snapshot() {
    const cap = (window.MS_CAPTURE ? window.MS_CAPTURE() : []).filter(Boolean);
    const byUrl = new Map(cap.map(p => [p.url, p]));
    apiProducts().forEach(p => { if (!byUrl.has(p.url)) byUrl.set(p.url, p); });
    return Array.from(byUrl.values());
  }

  /* ── 卡片元素定位 ───────────────────────────────────────────────── */
  /** url -> 卡片元素。拼多多必须让 capture.js 带着全部标题一起判，
   *  否则每件商品都会向上找到同一个列表容器（实测：20 件同价、只挂上 1 个按钮）。 */
  function buildCardIndex(products) {
    const idx = new Map();
    if (IS_1688 && window.MS_OFFER_CARDS_1688) {
      try { window.MS_OFFER_CARDS_1688().forEach((card, url) => idx.set(url, card)); } catch (e) { /* noop */ }
      return idx;
    }
    if (window.MS_CAPTURE_WITH_CARDS) {
      try { window.MS_CAPTURE_WITH_CARDS().forEach(x => { if (x && x.product && x.card) idx.set(x.product.url, x.card); }); } catch (e) { /* noop */ }
    }
    return idx;
  }

  function mountCardControls(products) {
    const cards = buildCardIndex(products);
    let mounted = 0;
    for (const p of products) {
      const card = cards.get(p.url);
      if (!card || !card.isConnected || card.querySelector('.ms-card-controls')) continue;
      const cs = getComputedStyle(card);
      if (cs.position === 'static') card.style.position = 'relative';
      const wrap = document.createElement('div');
      wrap.className = 'ms-card-controls';
      const label = document.createElement('label');
      const box = document.createElement('input');
      box.type = 'checkbox'; box.setAttribute('aria-label', '选择商品'); box.checked = selected.has(p.url);
      box.addEventListener('change', () => { box.checked ? selected.set(p.url, p) : selected.delete(p.url); updateCount(); });
      label.append(box, document.createTextNode('选'));
      const btn = document.createElement('button');
      btn.type = 'button'; btn.textContent = '采集商品';
      btn.addEventListener('click', ev => { ev.preventDefault(); ev.stopPropagation(); saveProducts([p]); });
      wrap.addEventListener('click', ev => ev.stopPropagation());
      wrap.append(label, btn);
      card.appendChild(wrap);
      mounted++;
    }
    return mounted;
  }

  function updateCount() {
    const el = document.getElementById('ms-selected-count');
    if (el) el.textContent = `已选 ${selected.size}`;
    const id = document.getElementById('ms-found-count');
    if (id) id.textContent = `本页识别 ${lastCount} 件`;
  }

  let lastCount = 0;

  function ensureToolbar() {
    if (document.querySelector('.ms-toolbar')) return;
    const bar = document.createElement('div');
    bar.className = 'ms-toolbar';
    const found = document.createElement('span'); found.id = 'ms-found-count'; found.className = 'ms-found';
    const count = document.createElement('span'); count.id = 'ms-selected-count';
    const b1 = document.createElement('button'); b1.textContent = '采集选中';
    b1.onclick = () => selected.size ? saveProducts(Array.from(selected.values())) : toast('请先勾选商品');
    const b2 = document.createElement('button'); b2.textContent = '采集本页';
    b2.onclick = () => {
      const items = snapshot();
      if (!items.length) { toast('本页没识别到商品。可能还没加载完，或该页结构已变——请把网址反馈给 ShopSage。'); return; }
      saveProducts(items);
    };
    const b3 = document.createElement('button'); b3.className = 'ms-light'; b3.textContent = '打开选品库';
    b3.onclick = () => sendRuntime({ type: 'OPEN_LIBRARY' });
    bar.append(found, count, b1, b2, b3);
    document.documentElement.appendChild(bar);
  }

  function ensureDetailButton(product) {
    let btn = document.querySelector('.ms-detail-button');
    if (!btn) {
      btn = document.createElement('button');
      btn.className = 'ms-detail-button';
      btn.textContent = '采集到选品库';
      document.documentElement.appendChild(btn);
    }
    btn.onclick = () => saveProducts([product]);
  }

  function isDetailPage() {
    if (IS_1688) return /\/offer\/\d+/.test(location.pathname);
    return /goods\.html|\/goods\/|detail/i.test(location.pathname) && !!new URL(location.href).searchParams.get('goods_id');
  }

  function render() {
    const products = snapshot();
    lastCount = products.length;
    const sig = products.length + '|' + apiItems.size + '|' + products.map(p => p.url).join(',');
    if (sig === lastSignature && document.querySelector('.ms-toolbar')) return;
    lastSignature = sig;

    if (isDetailPage()) {
      ensureDetailButton(products[0] || { title: '', price: null, url: location.href, platform: IS_1688 ? '1688' : '拼多多', currency: 'CNY' });
    } else {
      mountCardControls(products);
    }
    if (products.length || !IS_1688) { ensureToolbar(); }
    updateCount();
  }

  let timer;
  function scheduleRender() { clearTimeout(timer); timer = setTimeout(render, 700); }

  render();
  new MutationObserver(scheduleRender).observe(document.documentElement, { childList: true, subtree: true });
  // React 重渲染会把我们插进去的节点抹掉，所以留一条低频兜底重扫（不再是 2.5 秒全量重扫）
  setInterval(() => { lastSignature = ''; render(); }, 9000);

  // 整页内容出口：popup / 选品库的同步 payload 从这里取（详情页才有，列表页是 null）
  window.MS_CONTENT = { forUrl: contentForUrl, forUrlAsync: contentForUrlAsync };
})();
