/**
 * ShopSage 选品助手 · 页面侧取数器（MAIN world，document_start）
 *
 * 2026-11-08 实测结论（决定了这个文件的写法）：
 *   在 mobile.yangkeduo.com 搜索页注入探针后统计到 22 个内联 <script>，其中 0 个文本里含 goods_id。
 *   也就是说「抠内联脚本文本」这条路在拼多多上是走不通的 —— 商品数据挂在页面的 window 对象上
 *   （_SSR_ / __INITIAL_STATE__ 这类），而 content script 跑在 ISOLATED world，看不见页面的 window。
 *   所以取数必须放到 MAIN world 里做，再把结果用 postMessage 递回隔离世界。
 *
 * 三条取数路径，全都要，谁先命中算谁：
 *   A. 直接读页面 window 上的注水数据对象（首屏）
 *   B. 包 fetch / XMLHttpRequest，抓列表接口与详情接口的响应（翻页、下滑加载、SPA 内跳转）
 *   C. 周期重扫 window（PDD 是异步把数据挂上去的，document_start 时常常还没有）
 *
 * 铁律：本脚本跑在商家正在浏览的真实页面里。全程 try/catch，只读不改，任何异常都不许外溢、
 *       不许改请求、不许阻断渲染。扫描深度与条数封顶，别把页面拖慢。
 */
(function () {
  'use strict';
  if (window.__msHooked) return;
  window.__msHooked = true;

  var MAX_ITEMS = 80;
  var MAX_TEXT = 3000000;
  var MAX_FULL_CHARS = 800000;
  var allItems = new Map();        // goodsId -> item，累积全量，每次变化整份递过去
  var lastFullSentAt = 0;
  var fullAckId = '';

  /** 整份递，不在发送端去重。
   *  教训：之前发送端用 posted 集合去重、只发增量，结果拼多多在 content script 监听器装好之前
   *  就把首批 20 条发出去了 —— 那些数据永久丢失（实测 apiItems=0 但 posted=20）。
   *  接收端本来就按 goodsId 去重，发送端只管把当前全量重发。 */
  function emit(items, origin) {
    var changed = false;
    (items || []).forEach(function (it) {
      if (!it || !it.goodsId || !it.title) return;
      if (!allItems.has(it.goodsId)) { allItems.set(it.goodsId, it); changed = true; }
    });
    if (!changed) return false;
    postAll(origin);
    return true;
  }

  function postAll(origin) {
    if (!allItems.size) return;
    try {
      window.postMessage({
        __msPddApi: 1,
        origin: String(origin || '').slice(0, 160),
        items: Array.from(allItems.values()).slice(0, 200)
      }, '*');
    } catch (e) { /* 序列化失败就放弃这一批，绝不影响页面 */ }
  }

  function clean(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }

  /** 字段识别统一走 goods-shape.js（归一化键名，goods_id/goodsId/goodsID 全认），
   *  这样页面世界和隔离世界用的是同一套口径，不会两边算出不一样的商品。 */
  function find(node) {
    if (window.MS_SHAPE && typeof window.MS_SHAPE.findItems === 'function') {
      return window.MS_SHAPE.findItems(node, MAX_ITEMS);
    }
    return [];
  }

  /* ── 路径 A / C：读页面自己的注水数据 ─────────────────────────────── */
  function candidateGlobalNames() {
    var names = ['_SSR_', '__INITIAL_STATE__', '__NEXT_DATA__', 'rawData', '__DATA__', '__CDR__', 'g_initialProps', '__INITIAL_DATA__'];
    try {
      var keys = Object.keys(window);
      for (var i = 0; i < keys.length && names.length < 40; i++) {
        var k = keys[i];
        if (names.indexOf(k) >= 0) continue;
        if (/^(SSR|_SSR|__.*SSR.*|.*INITIAL.*|.*_DATA_.*|g_initialProps)$/.test(k)) names.push(k);
      }
    } catch (e) { /* 拿不到 keys 就用固定名单 */ }
    return names;
  }

  function scanGlobals() {
    var names = candidateGlobalNames();
    for (var i = 0; i < names.length; i++) {
      try {
        var v = window[names[i]];
        if (!v || typeof v !== 'object') continue;
        var items = find(v);
        if (items.length) emit(items, 'window.' + names[i]);
      } catch (e) { /* 跨源 getter 之类，跳过 */ }
    }
  }

  /* ── 整页内容采集（妙手式编辑器的数据底座，2026-11-09 老板定口径）─────────
     1688 详情页整包在 window.__INIT_DATA__（globalData.images 主图组、globalData.skuModel
     的 skuProps+skuInfoMap SKU 表、data.@ali/tdmod-* 属性/物流/描述模块）；
     拼多多在 window.rawData。编辑页要改的是整页内容，不是成本那几格——
     所以详情页把整包 JSON 递回隔离世界（≤2.5MB 封顶），归一化在隔离世界做。 */
  function goodsIdOf() {
    try {
      var h = location.href;
      var m = h.match(/offer\/(\d{6,})/) || h.match(/goods_?id=(\d{6,})/i) || h.match(/goods\.html\?goodsId=(\d{6,})/i);
      return m ? m[1] : '';
    } catch (e) { return ''; }
  }

  var lastFullSig = '';
  var sniffStats = null;

  function textSignature(text) {
    var hash = 2166136261;
    // 限制每次扫描成本，均匀采样约 4K 字符；哈希只负责区分页面数据快照，不做安全校验。
    var step = Math.max(1, Math.floor(text.length / 4096));
    for (var i = 0; i < text.length; i += step) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return (hash >>> 0).toString(16);
  }

  /** 主文档内联 <script> 嗅探：找含 globalData+sku 的大段文本，抠 {..} parse。
   *  只读不碰 DOM，parse 失败直接跳过该脚本，绝不影响页面。
   *  返回 { data, stats }——stats 随诊断进 DB，抓不到时能看到为什么。 */
  function sniffInlineJson() {
    var stats = { scanned: 0, candidates: [], parsed: false, key: '', err: '' };
    try {
      var scripts = document.scripts || [];
      for (var i = 0; i < scripts.length; i++) {
        var s = scripts[i];
        var t = '';
        try { if (s.src || !s.textContent) continue; t = String(s.textContent); } catch (e) { continue; }
        stats.scanned++;
        if (t.length < 2000 || t.indexOf('globalData') < 0 || t.indexOf('sku') < 0) continue;
        // 头 300 字节随诊断进库（上限 3 个）——拿到真实形态才能写出正确的提取（2026-11-09）
        if (stats.candidates.length < 3) stats.candidates.push({ idx: i, len: t.length, head: t.slice(0, 300) });
        var start = t.indexOf('{');
        if (start < 0) { stats.err = 'no_braces'; continue; }
        // 平衡括号提取（忽略字符串内的括号）——「first{ 到 last}」会被脚本尾部的 IIFE 打断（parse_assign_fail 的根因）
        var jsonText = extractBalanced(t, start);
        if (!jsonText) { stats.err = 'unbalanced'; continue; }
        var parsed = null;
        try { parsed = JSON.parse(jsonText); } catch (e1) { parsed = null; stats.err = 'parse_fail'; }
        if (parsed && typeof parsed === 'object' && (parsed.globalData || parsed.data)) {
          stats.parsed = true; stats.key = 'script#' + i;
          return { data: parsed, stats: stats };
        }
      }
    } catch (e3) { stats.err = String(e3 && e3.message || e3).slice(0, 100); }
    return { data: null, stats: stats };
  }

  /** 从 start 起做平衡花括号匹配，忽略引号内的内容；返回完整 JSON 文本或 null。 */
  function extractBalanced(t, start) {
    var depth = 0, inStr = false, quote = '', esc = false;
    for (var i = start; i < t.length; i++) {
      var ch = t.charAt(i);
      if (inStr) {
        if (esc) { esc = false; }
        else if (ch === '\\') { esc = true; }
        else if (ch === quote) { inStr = false; }
        continue;
      }
      if (ch === '"' || ch === "'") { inStr = true; quote = ch; continue; }
      if (ch === '{') { depth++; }
      else if (ch === '}') {
        depth--;
        if (depth === 0) return t.slice(start, i + 1);
      }
    }
    return null;
  }

  var fullPayloadAcked = false;
  function postFull() {
    try {
      var host = location.hostname || '';
      var data = null, tag = '', extra = null;
      if (/1688\.com$/.test(host)) {
        /* 0.9.8 用 CDP 直连真实详情页测出来的事实（offer 1085755976709，样本 70,175B 已存档）：
           数据包挂在 window.context，结构 = context.result.data.<模块名>.fields；
           内联脚本 #20 是 `window.context=(function(){...})(...)` 的 IIFE，
           对它做 JSON.parse / 平衡括号提取永远失败（实测 Expected property name @script#20）——
           所以嗅探这条路只留作旧版页面兜底，绝不再当主路径。
           window.offer_details 不是数据包，它是详情描述 HTML（实测 1,737B、含 10 个 <img>），
           单独作为 extra.offerDetails 递回去。 */
        try {
          var c = window.context;
          if (c && c.result && c.result.data && typeof c.result.data === 'object') { data = c; tag = '1688-context'; }
        } catch (eC0) { /* 跨源 getter */ }
        try {
          var od = window.offer_details;
          if (od && typeof od === 'object') {
            var odHtml = typeof od.content === 'string' ? od.content : '';
            if (odHtml.length > 200) extra = { offerDetails: { content: odHtml.slice(0, 200000) } };
          }
        } catch (eC1) { /* noop */ }
        if (!data) {
          // 旧版页面：数据包名可能带后缀，按前缀模糊扫
          var names = Object.keys(window);
          for (var i = 0; i < names.length && !data; i++) {
            if (!/^__INIT_DATA/.test(names[i])) continue;
            try {
              var v = window[names[i]];
              if (v && typeof v === 'object' && (v.globalData || v.data)) { data = v; tag = '1688-legacy'; }
            } catch (e0) { /* 跨源 getter */ }
          }
          // 结构特征兜底：认结构不认名字，绝不因名字对不上就丢整页
          if (!data) {
            for (var j = 0; j < names.length && !data; j++) {
              try {
                var w = window[names[j]];
                if (!w || typeof w !== 'object' || Array.isArray(w)) continue;
                var gd = w.globalData && typeof w.globalData === 'object' ? w.globalData : null;
                if (gd && (gd.images || gd.skuModel || gd.title)) { data = w; tag = '1688-legacy'; }
              } catch (e1) { /* 跨源 getter */ }
            }
          }
          if (!data) {
            var sniff = sniffInlineJson();
            sniffStats = sniff.stats;
            if (sniff.data) { data = sniff.data; tag = '1688-sniff'; }
          }
        }
      } else if (/yangkeduo\.com$/.test(host) || /pinduoduo\.com$/.test(host)) {
        // 优先接口捕获的整包 → 注水 rawData（须含商品结构）→ DOM 兜底
        if (pddDetail && looksLikePddDetail(pddDetail)) { data = pddDetail; tag = 'pdd-api'; }
        else if (window.rawData && looksLikePddDetail(window.rawData)) { data = window.rawData; tag = 'pdd'; }
        else { data = pddDomFallback(); tag = 'pdd-dom'; }
      }
      var goodsId = goodsIdOf();
      if (!goodsId) return;
      if (!data || typeof data !== 'object') {
        // 诊断：详情页没找到数据包——同时写 DOM（data-ms-diag，跨世界可读）和 postMessage，
        // 消息通道实测会因时序丢失，DOM 属性不会（2026-11-09 生产钉死）
        if (/offer\/\d+/.test(location.pathname)) {
          try {
            var diag = {
              goodsId: goodsId,
              url: location.href.slice(0, 160),
              ready: document.readyState,
              scripts: document.scripts.length,
              hooked: true,
              hasContext: !!(window.context && window.context.result),
              contextKeys: (() => { try { return Object.keys((window.context && window.context.result && window.context.result.data) || {}).slice(0, 40); } catch (e) { return []; } })(),
              ts: Date.now(),
              sniff: sniffStats,
              candidates: Object.keys(window).filter(function (k) { return /INIT|DATA|sku|goods|offer|context/i.test(k); }).slice(0, 40),
            };
            document.documentElement.setAttribute('data-ms-diag', JSON.stringify(diag).slice(0, 4000));
            if (!window.__msDiagSent) {
              window.__msDiagSent = true;
              try { window.postMessage(Object.assign({ __msDiag: 1 }, diag), '*'); } catch (e2) { /* noop */ }
            }
          } catch (e5) { /* noop */ }
        }
        return;
      }
      /* 统一信封：新版把 {data, extra} 一起递回去，归一化在隔离世界做（能拿真实样本离线测） */
      var payload = { __msEnvelope: 1, layout: tag, goodsId: goodsId, host: /1688\.com$/.test(host) ? '1688' : 'pdd', data: data, extra: extra || null };
      var text = JSON.stringify(payload);
      if (text.length < 30) return;
      // 只按长度去重会漏掉同长度的商品详情更新（标题/SKU/描述变了但字节数没变）。
      var sig = goodsId + ':' + text.length + ':' + textSignature(text);
      if (sig === lastFullSig && fullPayloadAcked && fullAckId === goodsId) return;
      if (sig === lastFullSig && Date.now() - lastFullSentAt < 3000) return;
      if (text.length > MAX_FULL_CHARS) {
        document.documentElement.setAttribute('data-ms-diag', JSON.stringify({ goodsId: goodsId, stage: 'full_payload', error: '商品详情数据超过 800 KB 安全上限', size: text.length }));
        return;
      }
      lastFullSig = sig;
      lastFullSentAt = Date.now();
      fullPayloadAcked = false;
      // 分块传输，不能截断 JSON 字符串：截断后 JSON.parse 失败会让整页详情静默丢失。
      var chunkSize = 200000;
      var total = Math.ceil(text.length / chunkSize);
      if (total === 1) {
        window.postMessage({ __msFull: 1, goodsId: goodsId, host: payload.host, raw: text }, '*');
      } else {
        for (var cIdx = 0; cIdx < total; cIdx++) {
          window.postMessage({ __msFullChunk: 1, goodsId: goodsId, host: payload.host, index: cIdx, total: total, raw: text.slice(cIdx * chunkSize, (cIdx + 1) * chunkSize) }, '*');
        }
      }
    } catch (e) { /* 绝不影响页面 */ }
  }

  /* ── 路径 B：接口响应 ─────────────────────────────────────────────── */
  // 2026-11-14：拼多多 H5 详情页的 window.rawData 已只剩首页/商城模块（实测 Reflect.ownKeys=[store]），
  // 商品整包改走异步接口。这里把详情接口 JSON 捕获下来喂给 postFull，不再只依赖 rawData。
  var pddDetail = null;
  function looksLikePddDetail(o) {
    if (!o || typeof o !== 'object') return false;
    var g = o.goods || (o.store && (o.store.initDataObj && o.store.initDataObj.goods || o.store.goods)) || o;
    return !!(g && (g.skuList || g.sku || g.images || g.gallery || g.goodsName || g.title));
  }
  function tryText(text, origin) {
    if (!text || text.length > MAX_TEXT || !/goods_?id/i.test(text)) return;
    try {
      var parsed = JSON.parse(text);
      var items = find(parsed);
      if (items.length) emit(items, origin);
      if (goodsIdOf() && looksLikePddDetail(parsed)) { pddDetail = parsed; try { postFull(); } catch (e) { /* noop */ } }
    } catch (e) { /* 不是 JSON，忽略 */ }
  }

  /* DOM 提取（2026-11-14 真页面 CDP 实测重写）：PDD 详情接口已加密（encrypt_status:3，goods 空壳），
     接口/注水都拿不到明文，只能读渲染 DOM。锚点用**语义类名/稳定属性**（sku-specs-key、aria-label、
     enable-select、goods-container-v2、pdd-lazy-image），不用混淆类名（m4HArFRm 之类会变）。
     两个商品实测：标题/价格/9主图/SKU规格(款式×颜色)/参数(品牌/发货地/包装)/详情图 全部采全。 */
  function pddDomFallback() {
    try {
      var out = { goods: {} };
      var g = out.goods;
      var root = document.querySelector('.goods-container-v2') || document.body;

      // 标题：enable-select 语义类；兜底 document.title（非通用"拼多多"时）
      var titleEl = root.querySelector('.enable-select') || document.querySelector('.enable-select');
      g.goodsName = titleEl ? clean(titleEl.textContent) : (document.title && document.title !== '拼多多' ? clean(document.title) : '');

      // 价格：PDD 把 ¥ 与整数/小数拆成多 span，找含 ¥ 的块重建 textContent 取第一个价
      var allSpans = root.querySelectorAll('span');
      for (var i = 0; i < allSpans.length; i++) {
        var tx = allSpans[i].textContent || '';
        if (tx.indexOf('¥') >= 0 && /\d/.test(tx)) {
          var pm = tx.replace(/\s+/g, '').match(/¥(\d+(?:\.\d+)?)/);
          if (pm) { g.price = Number(pm[1]); break; }
        }
      }

      // 主图：轮播 background-image + img（pddpic 域），去重取前 9
      var gallery = [];
      function pushUrl(u) {
        if (!u) return;
        u = u.replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
        if (u.indexOf('//') === 0) u = 'https:' + u;
        if (/pddpic\.com/.test(u) && gallery.indexOf(u) < 0) gallery.push(u);
      }
      var bgEls = root.querySelectorAll('[style*="background-image"]');
      for (var b = 0; b < bgEls.length; b++) {
        var st = bgEls[b].getAttribute('style') || '';
        var mm = st.match(/background-image:\s*url\((["']?)([^"')]+)\1\)/);
        if (mm) pushUrl(mm[2]);
      }
      var topImgs = root.querySelectorAll('img');
      for (var k = 0; k < topImgs.length; k++) {
        var s = topImgs[k].getAttribute('src') || topImgs[k].getAttribute('data-src') || '';
        if (/pddpic\.com/.test(s)) pushUrl(s);
      }
      g.images = gallery.slice(0, 9);

      // SKU 规格：span.sku-specs-key（语义类）=规格名；同组 div[role=button][aria-label]=选项值
      var skuProps = [];
      var keys = root.querySelectorAll('.sku-specs-key');
      for (var p = 0; p < keys.length; p++) {
        var keyName = clean(keys[p].textContent);
        var group = keys[p].parentElement;
        var opts = group ? group.querySelectorAll('div[role="button"][aria-label]') : [];
        var values = [];
        for (var q = 0; q < opts.length; q++) {
          var v = clean(opts[q].getAttribute('aria-label'));
          if (v && values.indexOf(v) < 0) values.push(v);
        }
        if (keyName && values.length) skuProps.push({ name: keyName, values: values });
      }
      g.skuProps = skuProps;
      var selMatch = (root.textContent || '').match(/已选[：:]\s*([^\n]+?)(?=款式|颜色|确定|$)/);
      if (selMatch) g.selectedSpec = clean(selMatch[1]);

      // 商品参数：div[tabindex=-1][aria-label]，两个 aria-hidden 子 div = 键/值
      var props = [];
      var paramEls = root.querySelectorAll('div[tabindex="-1"][aria-label]');
      for (var r = 0; r < paramEls.length; r++) {
        var children = paramEls[r].querySelectorAll('div[aria-hidden="true"]');
        if (children.length >= 2) {
          var pk = clean(children[0].textContent), pv = clean(children[1].textContent);
          if (pk && pv) props.push({ key: pk, value: pv });
        }
      }
      g.props = props;

      // 详情图：img.pdd-lazy-image 且只收商品图（mms-goods-image），天然排除头像/营销图
      var detailImages = [];
      var lazy = root.querySelectorAll('img.pdd-lazy-image, img[data-src]');
      for (var t = 0; t < lazy.length; t++) {
        var du = lazy[t].getAttribute('data-src') || lazy[t].getAttribute('src') || '';
        if (du.indexOf('//') === 0) du = 'https:' + du;
        if (/mms-goods-image/.test(du) && detailImages.indexOf(du) < 0) detailImages.push(du);
      }
      g.detailImages = detailImages.slice(0, 60);

      if (g.goodsName || g.price || g.images.length || skuProps.length) return out;
    } catch (e) { /* noop */ }
    return null;
  }

  try {
    var nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') {
      window.fetch = function () {
        var args = arguments, url = '';
        try { url = String((args[0] && args[0].url) || args[0] || ''); } catch (e) { /* noop */ }
        var p = nativeFetch.apply(this, args);
        try {
          if (p && p.then) p.then(function (res) {
            try {
              if (!res || !res.clone) return;
              res.clone().text().then(function (t) { try { tryText(t, url); } catch (e) { /* noop */ } }, function () { /* noop */ });
            } catch (e) { /* noop */ }
          }, function () { /* noop */ });
        } catch (e) { /* noop */ }
        return p;
      };
    }
  } catch (e) { /* 包不上就算了 */ }

  try {
    var X = window.XMLHttpRequest;
    if (X && X.prototype && !X.prototype.__msPatched) {
      X.prototype.__msPatched = true;
      var open = X.prototype.open, send = X.prototype.send;
      X.prototype.open = function (m, u) { try { this.__msUrl = String(u || ''); } catch (e) { /* noop */ } return open.apply(this, arguments); };
      X.prototype.send = function () {
        var self = this;
        try {
          self.addEventListener('load', function () {
            try {
              if (self.responseType === '' || self.responseType === 'text') tryText(self.responseText, self.__msUrl);
            } catch (e) { /* noop */ }
          });
        } catch (e) { /* noop */ }
        return send.apply(this, arguments);
      };
    }
  } catch (e) { /* noop */ }

  /* 周期性把已攒到的商品整份重递一遍：
     content script 在 document_idle 才装监听器，而拼多多可能在它装好之前就把首批数据挂上 window。
     实测踩过这个坑 —— 发送端去重导致那批数据永久丢失（apiItems=0 但 posted=20）。 */
  function resend() { try { postAll('resend'); } catch (e) { /* noop */ } }

  window.addEventListener('message', function (ev) {
    if (ev.data && ev.data.__msFullAck === 1 && ev.data.goodsId) {
      fullAckId = String(ev.data.goodsId);
      if (fullAckId === goodsIdOf()) fullPayloadAcked = true;
    }
  });

  scanGlobals();
  resend();
  document.addEventListener('DOMContentLoaded', function () { try { scanGlobals(); resend(); } catch (e) { /* noop */ } });
  window.addEventListener('load', function () { try { scanGlobals(); resend(); } catch (e) { /* noop */ } });

  /* 拼多多是异步把数据挂上 window 的，而且下滑加载会往同一个对象里追加商品，
     所以要持续重扫。前 30 秒每 1.5 秒一次，之后降频到 6 秒，别一直高频占主线程。
     每轮都顺带整份重递一次，晚装的监听器也能补上数据。 */
  var fast = 20;
  var tick = setInterval(function () {
    try {
      scanGlobals();
      postFull();
      resend();
      if (--fast <= 0) {
        clearInterval(tick);
        setInterval(function () { try { scanGlobals(); postFull(); resend(); } catch (e) { /* noop */ } }, 6000);
      }
    } catch (e) { /* noop */ }
  }, 1500);
})();
