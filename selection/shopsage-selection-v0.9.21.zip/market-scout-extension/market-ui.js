/**
 * ShopSage 选品助手 · 市场与成本面板（popup 与选品库共用一份，避免两处各写一套对不上）
 *
 * 规则（按老板 2026-11-08 口径）：客人能自己填的就用自己填的；填不了、也没填的，
 * 才用 ShopSage 底层规则库算出来给他；规则库也没收录的，明标「未收录 · 需您填写」，
 * 绝不拿 0 或默认值冒充，利润结论自动降级为「信息不足」。
 */
(function (root) {
  'use strict';
  var R = root.SS_RULES;
  if (!R) { console.error('market-ui.js 需要 rules.js 先加载'); return; }

  var $ = function (id) { return document.getElementById(id); };
  var overridden = new Set();   // 用户手动改过的字段，规则值永不覆盖
  var els = {};

  var ACCESS_LABEL = {
    cross_border: '中国卖家可跨境直发',
    local_only: '仅本土店（需当地主体）',
    invite_only: '邀请制开通'
  };

  function val(id) { var e = els[id] || $(id); return e ? String(e.value || '').trim() : ''; }
  function numVal(id) { var n = Number(val(id)); return Number.isFinite(n) && val(id) !== '' ? n : null; }

  function chip(text, kind) {
    return '<span class="ms-chip ms-chip-' + (kind || 'muted') + '">' + esc(text) + '</span>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c];
    });
  }

  /* ── 初始化：填平台下拉 + 国家候选，绑事件 ───────────────────────── */
  function init(map) {
    els = map || {};

    var sel = $('marketplace');
    if (sel && !sel.dataset.msBuilt) {
      sel.dataset.msBuilt = '1';
      var intended = sel.value;          // 先记住页面里写死的默认平台，重建选项后要还原
      sel.innerHTML = '';
      var groupMain = document.createElement('optgroup');
      groupMain.label = 'ShopSage 规则库已收录';
      R.PLATFORMS.filter(function (p) { return p.supported; }).forEach(function (p) {
        var o = document.createElement('option'); o.value = p.key; o.textContent = p.name; groupMain.appendChild(o);
      });
      var groupOther = document.createElement('optgroup');
      groupOther.label = '规则库未收录（运费扣点需自行填写）';
      [['AMAZON', 'Amazon'], ['SHOPIFY', 'Shopify 独立站'], ['EBAY', 'eBay'], ['ETSY', 'Etsy'],
       ['WALMART', 'Walmart'], ['TEMU', 'Temu'], ['OTHER', '其他']].forEach(function (p) {
        var o = document.createElement('option'); o.value = p[0]; o.textContent = p[1]; groupOther.appendChild(o);
      });
      sel.append(groupMain, groupOther);
      /* 清空重建后浏览器会把选中项落到第一个（Shopee）——实测踩过。
         必须显式还原页面写死的默认平台，还原不了才退回 TikTok Shop。 */
      if (intended && Array.prototype.some.call(sel.options, function (o) { return o.value === intended; })) sel.value = intended;
      else sel.value = 'TIKTOK_SHOP';
    }

    /* 目标国家：改成真下拉（平台开通了哪些国家就列哪些，选一个就行），
       另留「其他 / 自行输入」给规则库没覆盖的市场。 */
    rebuildCountry(val('marketplace') || 'TIKTOK_SHOP', val('country'));

    if (!$('weightG') || !$('sellerType') || !$('msCostFields')) {
      console.warn('market-ui: 页面缺少 #msCostFields 锚点（weightG / sellerType 容器），规则派生仍可运行，但精准重量与店型不可填');
    }

    ['marketplace', 'country', 'countrySelect', 'transportMode', 'currency', 'shipping', 'feeRate', 'purchasePrice', 'targetPrice', 'weightG', 'otherPct', 'sellerType']
      .forEach(function (id) {
        var e = els[id] || $(id);
        if (!e || e.dataset.msBound) return;
        e.dataset.msBound = '1';
        e.addEventListener('input', function () {
          if (['shipping', 'feeRate', 'purchasePrice', 'targetPrice', 'otherPct'].indexOf(id) >= 0) overridden.add(id);
          if (id === 'currency') { e.dataset.msLocked = '1'; overridden.add('currency'); }
          refresh(id === 'marketplace' || id === 'country' || id === 'countrySelect' || id === 'weightG' ? true : false);
        });
        e.addEventListener('change', function () {
          if (id === 'marketplace') { rebuildCountry(val('marketplace'), countryValue()); rebuildTransport(); }
          if (id === 'countrySelect') { toggleCustomInput(); rebuildTransport(); }
          if (id === 'marketplace' || id === 'country' || id === 'countrySelect' || id === 'weightG' || id === 'sellerType') refresh(true);
        });
      });

    var force = $('msRecompute');
    if (force) force.onclick = function () {
      ['shipping', 'feeRate', 'currency'].forEach(function (k) { overridden.delete(k); });
      if ($('currency')) delete $('currency').dataset.msLocked;
      refresh(true);
    };

    refresh(true);
  }

  /* ── 目标国家：平台开通国家下拉 + 自定义输入 ─────────────────────── */
  var CUSTOM = '__custom__';

  /** 国家当前生效值：下拉选了真实市场就用它，选了「其他」就用文本框里的手输值。 */
  function countryValue() {
    var sel = $('countrySelect'), txt = $('country');
    if (sel && sel.style.display !== 'none') {
      return sel.value === CUSTOM ? (txt ? String(txt.value || '').trim() : '') : String(sel.value || '').trim();
    }
    return txt ? String(txt.value || '').trim() : '';
  }

  /** 按平台重建国家下拉。老板口径：平台开了哪些国家就都能选——我们服务很多卖家，
   *  不同卖家挂在不同市场，不能只给一个写死的默认国。 */
  function rebuildCountry(platform, current) {
    var sel = $('countrySelect'), txt = $('country');
    if (!sel) return;
    var list = R.MARKETS[platform] || [];
    sel.innerHTML = '';

    var cur = R.resolveCountry(platform, current);
    if (!list.length) {
      // 规则库未收录的平台：没有「开通国家」可列，直接给文本框自己填
      sel.style.display = 'none';
      if (txt) { txt.style.display = ''; txt.placeholder = '该平台无规则库，请自行输入国家名或代码'; }
      return;
    }

    var other = document.createElement('option');
    other.value = CUSTOM; other.textContent = '其他 / 自行输入国家…';
    sel.appendChild(other);
    list.forEach(function (m) {
      var o = document.createElement('option');
      o.value = m.name;
      o.textContent = m.name + '（' + m.code + '）· ' + m.currency
        + (m.access === 'local_only' ? ' · 仅本土店' : (m.access === 'invite_only' ? ' · 邀请制' : ''));
      sel.appendChild(o);
    });

    if (cur && list.some(function (m) { return m.code === cur.code; })) {
      sel.value = cur.name;                 // 之前选的市场在这个平台也开了 → 保留
      sel.style.display = '';
      if (txt) txt.style.display = 'none';
    } else if (current && current.trim()) {
      sel.value = CUSTOM;                   // 手输过的国家不在新平台清单里 → 转自定义
      sel.style.display = '';
      if (txt) { txt.style.display = ''; txt.value = current; }
    } else {
      sel.selectedIndex = 1;                // 默认选该平台的第一个市场（不落在「其他」上）
      sel.style.display = '';
      if (txt) txt.style.display = 'none';
    }
  }

  /** 运输方式下拉：随国家走——官方/海运/铁路，有什么列什么。 */
  function rebuildTransport(platform, countryText, current) {
    var sel = $('transportMode');
    if (!sel) return;
    var c = R.resolveCountry(platform, countryText);
    var modes = R.shippingModes(c ? c.code : countryText);
    sel.innerHTML = '';
    modes.forEach(function (m) {
      var o = document.createElement('option');
      o.value = m.key; o.textContent = m.label;
      sel.appendChild(o);
    });
    var ok = modes.some(function (m) { return m.key === current; });
    sel.value = ok ? current : modes[0].key;

    /* 铁路为什么不在下拉里——直接讲清楚：无通道 / 待询价，而不是让商家以为我们漏了。 */
    var note = sel.parentNode.querySelector('.ms-transport-note');
    if (!note) {
      note = document.createElement('small');
      note.className = 'ms-transport-note';
      sel.parentNode.appendChild(note);
    }
    var why = R.railNote ? R.railNote(c ? c.code : countryText) : null;
    note.textContent = why || '';
    note.style.display = why ? '' : 'none';
  }

  function toggleCustomInput() {
    var sel = $('countrySelect'), txt = $('country');
    if (!sel || !txt) return;
    txt.style.display = (sel.style.display !== 'none' && sel.value === CUSTOM) ? '' : 'none';
    if (txt.style.display === 'none') txt.value = '';
  }

  /* ── 一次刷新：联动国家候选 → 派生成本 → 出利润结论 ─────────────── */
  function refresh(derive) {
    var platform = val('marketplace') || 'TIKTOK_SHOP';
    var countryText = countryValue();
    var market = R.resolveCountry(platform, countryText);

    var state = R.resolve({
      platform: platform,
      country: market ? market.code : countryText,
      currency: val('currency') || '',
      weightBand: val('weightBand') || '0-1',
      weightG: parseFloat(val('weightG')) || 0,
      sellerType: val('sellerType') || '',
      transportMode: val('transportMode') || 'official'
    });

    if (derive) {
      rebuildTransport(platform, countryValue(), val('transportMode'));
      if (market && !$('currency').dataset.msLocked) {
        $('currency').value = market.currency;
      }
      /* 关键：规则算不出来时必须把字段清空，不能留着上一个国家的旧值——
         实测踩过：泰国切到西班牙，运费框还留着 ¥8，口径却写「未收录」，
         利润拿错的 8 去算。字段与口径必须永远一致。 */
      if (!overridden.has('feeRate')) {
        $('feeRate').value = state.fee.pct != null ? state.fee.pct : '';
        $('feeRate').placeholder = state.fee.pct != null ? '规则库自动填' : '该市场规则库未收录，请自填';
      }
      if (!overridden.has('shipping')) {
        $('shipping').value = state.shipping.costCny != null ? state.shipping.costCny : '';
        $('shipping').placeholder = state.shipping.costCny != null ? '规则库自动填' : '该市场规则库未收录，请自填';
      }
    }

    renderProvenance(state);
    renderProfit(state);
    return state;
  }

  function renderProvenance(state) {
    var box = $('msRuleSource');
    if (!box) return;

    /* 有问题的事（平台没收录、国家不在清单、费率缺失）永远摆在明面上，不折起来 */
    var urgent = [];
    if (!state.platformSupported) {
      urgent.push('<div class="ms-src-row ms-src-warn"><b>平台规则库未收录</b>'
        + '<span>费率/运费表目前只覆盖 Shopee、TikTok Shop、Lazada、Ozon。这个平台的运费扣点请自己填，我们不代算。</span></div>');
    }
    if (!state.market && state.country) {
      urgent.push('<div class="ms-src-row ms-src-warn"><b>该国家不在本平台已开通市场里</b>'
        + '<span>按「' + esc(state.countryName || state.country) + '」自由输入计算，规则库可能没有对应费率与运费。</span></div>');
    }
    if (state.fee.pct == null && !overridden.has('feeRate')) {
      urgent.push('<div class="ms-src-row ms-src-missing"><b>综合扣点：规则库未收录</b><span>' + esc(state.fee.reason) + '</span></div>');
    }
    if (state.shipping.costCny == null && !overridden.has('shipping')) {
      urgent.push('<div class="ms-src-row ms-src-missing"><b>跨境运费：规则库未收录</b><span>' + esc(state.shipping.reason) + '</span></div>');
    }

    /* 正常情况的口径说明默认折成一行，要点开才看全量 —— 不然右栏拖得比页面还长 */
    var detail = [];
    if (state.market) {
      detail.push('<div class="ms-src-row"><b>' + esc(state.market.name) + '（' + esc(state.market.code) + '）</b>'
        + '<span>' + esc(ACCESS_LABEL[state.market.access] || '') + ' · 结算币种 ' + esc(state.market.currency)
        + (state.bandNote ? ' · ' + esc(state.bandNote) : '') + '</span></div>');
    }
    if (state.fee.pct != null) {
      detail.push('<div class="ms-src-row"><b>综合扣点 ' + state.fee.pct + '%</b><span>'
        + chip(state.fee.quality === 'CONFIRMED' ? '已核实' : '估算', state.fee.quality === 'CONFIRMED' ? 'ok' : 'warn')
        + chip('置信 ' + state.fee.confidence, state.fee.confidence === 'HIGH' ? 'ok' : 'warn')
        + esc(state.fee.basis) + ' · 数据日 ' + esc(state.fee.verified)
        + (overridden.has('feeRate') ? ' · <u>已改用您填写的值</u>' : '')
        + (state.fee.note ? ' · ' + esc(state.fee.note) : '') + '</span></div>');
    } else if (overridden.has('feeRate')) {
      detail.push('<div class="ms-src-row"><b>综合扣点 ' + esc(val('feeRate')) + '%</b><span><u>您填写的值</u>（规则库该市场未收录）</span></div>');
    }
    if (state.shipping.costCny != null) {
      detail.push('<div class="ms-src-row"><b>跨境运费 ¥' + state.shipping.costCny + '</b><span>'
        + chip('市场参考·低置信', 'warn')
        + esc(state.shipping.band) + ' ≈ ' + esc(state.shipping.localAmount) + ' ' + esc(state.shipping.localCurrency)
        + ' · ' + esc(state.shipping.source)
        + (overridden.has('shipping') ? ' · <u>已改用您填写的值</u>' : '')
        + ' · ' + esc(state.shipping.note) + '</span></div>');
    } else if (overridden.has('shipping')) {
      detail.push('<div class="ms-src-row"><b>跨境运费 ¥' + esc(val('shipping')) + '</b><span><u>您填写的值</u>（规则库该市场未收录）</span></div>');
    }
    detail.push('<div class="ms-src-row ms-src-note"><span>规则库快照 ' + R.SNAPSHOT_DATE
      + ' · 汇率为带日期的参考值（非实时）· 估算口径，正式结算以平台后台账单为准。</span>'
      + '<button type="button" id="msRecompute" class="ms-mini">按规则重算</button></div>');

    var f = state.fee, s = state.shipping;
    var summary = '口径与来源：'
      + (f.pct != null ? '扣点 ' + f.pct + '%' : (overridden.has('feeRate') ? '扣点 ' + esc(val('feeRate')) + '%（自填）' : '扣点未收录'))
      + ' · '
      + (s.costCny != null ? '运费 ¥' + s.costCny : (overridden.has('shipping') ? '运费 ¥' + esc(val('shipping')) + '（自填）' : '运费未收录'))
      + ' · 快照 ' + R.SNAPSHOT_DATE;

    box.innerHTML = urgent.join('')
      + '<details class="ms-src-fold"><summary>' + summary + '</summary><div class="ms-src-body">' + detail.join('') + '</div></details>';

    var btn = $('msRecompute');
    if (btn) btn.onclick = function () { overridden.delete('shipping'); overridden.delete('feeRate'); refresh(true); };
  }

  function renderProfit(state) {
    var box = $('msProfit');
    if (!box) return;
    var purchase = numVal('purchasePrice');
    var target = numVal('targetPrice');
    var shipping = numVal('shipping');
    var fee = numVal('feeRate');
    var other = numVal('otherPct');

    var p = R.profit({
      purchaseCny: purchase, targetPrice: target,
      targetCurrency: val('currency') || (state.currency || 'CNY'),
      shippingCny: shipping, feePct: fee, otherPct: other
    });

    if (p.missing && p.missing.length) {
      box.className = 'ms-profit ms-profit-incomplete';
      box.innerHTML = '<div class="ms-profit-verdict">信息不足</div>'
        + '<div class="ms-profit-why">还缺：' + esc(p.missing.join('、'))
        + '。缺任何一项我们都不硬出利润结论——填上或让规则库补上即可。</div>';
      return;
    }

    var cls = p.verdict === '值得测试' ? 'good' : (p.verdict === '谨慎测试' ? 'mid' : 'bad');
    box.className = 'ms-profit ms-profit-' + cls;
    box.innerHTML = '<div class="ms-profit-verdict">' + esc(p.verdict) + '</div>'
      + '<table class="ms-profit-table"><tbody>'
      + row('折算收入', '¥' + p.revenueCny)
      + row('− 采购价', '¥' + (purchase == null ? '—' : purchase))
      + row('− 运费', '¥' + (shipping == null ? '—' : shipping))
      + row('− 平台扣点 ' + fee + '%', '¥' + p.feeCny)
      + row('− 其他成本 ' + (other == null ? state.otherBufferPct : other) + '%（退货/广告/仓储）', '¥' + p.otherCny)
      + row('<b>净利润</b>', '<b>¥' + p.profitCny + '</b>')
      + row('毛利率', p.marginPct + '%')
      + row('投产比 ROI', p.roiPct + '%')
      + row('保本售价', esc(fmtPrice(p.breakEvenPrice, state.currency)))
      + row('30% 毛利建议售价', esc(fmtPrice(R.suggestPrice({
          purchaseCny: purchase, shippingCny: shipping, feePct: fee, otherPct: other,
          targetCurrency: state.currency || val('currency'), targetMarginPct: 30
        }), state.currency)))
      + '</tbody></table>'
      + '<div class="ms-profit-why">' + esc(p.threshold) + ' · 汇率 1 CNY = ' + p.fx.perCny + ' '
      + esc(state.currency || val('currency')) + '（' + esc(p.fx.tier === 'A' ? 'er-api 参考' : '规则库静态参考') + ' · ' + esc(p.fx.asOf) + '）</div>';

    function row(k, v) { return '<tr><td>' + k + '</td><td>' + v + '</td></tr>'; }
  }

  function fmtPrice(v, currency) {
    if (v == null || !Number.isFinite(v)) return '算不出（费率/汇率缺口过大）';
    return (v >= 1000 ? Math.round(v) : Math.round(v * 100) / 100) + ' ' + (currency || '');
  }

  /** 供 popup / library 拼请求体时取同一份口径。 */
  function requestMarket() {
    var platform = val('marketplace') || 'TIKTOK_SHOP';
    var countryText = countryValue();
    var market = R.resolveCountry(platform, countryText);
    return {
      country: market ? market.name : countryText,
      countryCode: market ? market.code : null,
      marketplace: platform,
      currency: val('currency') || (market ? market.currency : null),
      targetPrice: numVal('targetPrice'),
      sellerType: val('sellerType') || null,
      weightBand: val('weightBand') || '0-1',
      weightG: parseFloat(val('weightG')) || 0,
      transportMode: val('transportMode') || 'official'
    };
  }

  function requestCosts() {
    return {
      purchasePrice: numVal('purchasePrice'),
      shipping: numVal('shipping'),
      platformFeeRate: numVal('feeRate'),
      otherCostRate: numVal('otherPct'),
      transportMode: val('transportMode') || 'official',
      shippingSource: overridden.has('shipping') ? 'USER' : 'RULE_OR_MISSING',
      feeRateSource: overridden.has('feeRate') ? 'USER' : 'RULE_OR_MISSING'
    };
  }

  root.MSMarket = { init: init, refresh: refresh, requestMarket: requestMarket, requestCosts: requestCosts };
})(typeof window !== 'undefined' ? window : this);
