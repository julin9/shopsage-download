/* 自动生成，别手改：node scripts/gen-plugin-fee-baseline.cjs
 * 来源：services/api/src/cost/fee-baseline.ts + fee-calculator.ts（版本 2026-11-14.v4）
 * 共 39 行（平台×国家×店型），其中未知 2 行、含待后台核实项(LOW) 23 行。
 * 插件只读这里的 compositePct，不再自己算基数 —— 数字由服务端同一段代码产出，这才叫闭环。
 * 注意：产物里不写 generatedAt。生成时间每次不同会让文件在两次构建之间被判定为有改动，
 * 于是发版预检「有未提交改动」直接 abort（2026-11-14 真撞上）。版本以 fee-baseline 的 version 为准。
 */
(function (root) {
  'use strict';
  root.MS_FEE_BASELINE = {
  "version": "2026-11-14.v4",
  "rows": [
    {
      "platform": "TIKTOK_SHOP",
      "market": "US",
      "shopType": "cb_pop",
      "currency": "USD",
      "available": true,
      "compositePct": 6,
      "referencePriceLocal": 25,
      "totalPer100": 1.5,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        }
      ],
      "freight": {
        "overseasWarehouseLastMile": {
          "perTicket": 3.5,
          "currency": "USD",
          "status": "E",
          "source": "tiktok费用表（2026-11）",
          "note": "海外仓一件代发尾程 $3–4/包裹"
        },
        "seaLcl": {
          "pricePerCbm": 3000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（行情中值，待真实运价覆盖）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "UK",
      "shopType": "cb_pop",
      "currency": "GBP",
      "available": true,
      "compositePct": 13.3,
      "referencePriceLocal": 20,
      "totalPer100": 2.66,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.99,
          "currency": "GBP",
          "status": "P",
          "source": "tiktok费用表（2026-11）",
          "note": "存档：买家端标准配送 £3.99（含 VAT）。卖家运费已走官方4PL价卡（tiktok-intl-freight，2026-11-01生效，按重量档挂号费+每公斤）"
        },
        "seaLcl": {
          "pricePerCbm": 3000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "DE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.71,
      "referencePriceLocal": 25,
      "totalPer100": 2.68,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "FR",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.8,
      "referencePriceLocal": 25,
      "totalPer100": 2.7,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "IT",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.98,
      "referencePriceLocal": 25,
      "totalPer100": 2.75,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ES",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "referencePriceLocal": 25,
      "totalPer100": 2.72,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "IE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 11.07,
      "referencePriceLocal": 25,
      "totalPer100": 2.77,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "AT",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.8,
      "referencePriceLocal": 25,
      "totalPer100": 2.7,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "BE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "referencePriceLocal": 25,
      "totalPer100": 2.72,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "NL",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "referencePriceLocal": 25,
      "totalPer100": 2.72,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "PL",
      "shopType": "cb_pop",
      "currency": "PLN",
      "available": true,
      "compositePct": 11.07,
      "referencePriceLocal": 120,
      "totalPer100": 13.28,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "CZ",
      "shopType": "cb_pop",
      "currency": "CZK",
      "available": true,
      "compositePct": 10.89,
      "referencePriceLocal": 100,
      "totalPer100": 10.89,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "GR",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 11.16,
      "referencePriceLocal": 25,
      "totalPer100": 2.79,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "PT",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 11.07,
      "referencePriceLocal": 25,
      "totalPer100": 2.77,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "HU",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 11.43,
      "referencePriceLocal": 25,
      "totalPer100": 2.86,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "市场参考：EU 现为3PL模式（商家自选顺丰/递四方等官方认证物流商），无统一平台4PL价卡；此法国示例€3.15/包裹+€7.60/kg仅估算，待真实3PL报价覆盖。2026-07-01起欧盟取消150欧以下免税，每件征3欧固定关税"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "JP",
      "shopType": "cb_pop",
      "currency": "JPY",
      "available": true,
      "compositePct": 13,
      "referencePriceLocal": 3500,
      "totalPer100": 455,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.077,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（到门口径）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "MX",
      "shopType": "cb_pop",
      "currency": "MXN",
      "available": true,
      "compositePct": 23.5,
      "referencePriceLocal": 400,
      "totalPer100": 94,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 2.3,
          "currency": "USD",
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "待补：墨西哥2026-10-21价卡重构（拆跨境段+本地段、下调运费），新价卡为图片待提取；旧首重$2.3仅参考。体积重/8000泡比1.5，SFP服务费8%封顶40MXN"
        },
        "seaLcl": {
          "pricePerCbm": 4800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "BR",
      "shopType": "cb_pop",
      "currency": "BRL",
      "available": true,
      "compositePct": 17.5,
      "referencePriceLocal": 80,
      "totalPer100": 14,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 2300,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（原值 4800 约为行情两倍，已修正）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "MY",
      "shopType": "cb_pop",
      "currency": "MYR",
      "available": true,
      "compositePct": 24.84,
      "referencePriceLocal": 40,
      "totalPer100": 9.94,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.0378,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0378,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "TH",
      "shopType": "cb_pop",
      "currency": "THB",
      "available": true,
      "compositePct": 23.66,
      "referencePriceLocal": 250,
      "totalPer100": 59.16,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.04,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.0321,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        },
        {
          "key": "commerceGrowthFee",
          "label": "商业增长费",
          "base": "product_price_excl_ship_tax",
          "rate": 0.0803,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "VN",
      "shopType": "cb_pop",
      "currency": "VND",
      "available": true,
      "compositePct": 26.8,
      "referencePriceLocal": 300000,
      "totalPer100": 80400,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.14,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "PH",
      "shopType": "cb_pop",
      "currency": "PHP",
      "available": true,
      "compositePct": 17.84,
      "referencePriceLocal": 500,
      "totalPer100": 89.2,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.05,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0224,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        },
        {
          "key": "shippingServiceFee",
          "label": "物流服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0.055,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "SG",
      "shopType": "cb_pop",
      "currency": "SGD",
      "available": true,
      "compositePct": 13.08,
      "referencePriceLocal": 20,
      "totalPer100": 2.62,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.04905,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0327,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ID",
      "shopType": "cb_pop",
      "currency": "IDR",
      "available": false,
      "compositePct": null,
      "referencePriceLocal": null,
      "totalPer100": 0,
      "confidence": "LOW",
      "unknown": true,
      "reason": "该平台在此国家没有这个店型通道（例：TikTok 印尼无跨境 POP），必须换店型或按本土店重算",
      "lines": [],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（原值 950 约为行情一半，已修正）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ID",
      "shopType": "local",
      "currency": "IDR",
      "available": true,
      "compositePct": 15.33,
      "referencePriceLocal": 150000,
      "totalPer100": 23000,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.145,
          "status": "P"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "order_total_incl_ship_tax",
          "rate": 0.11,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "SG",
      "shopType": "cb_sls",
      "currency": "SGD",
      "available": true,
      "compositePct": 24.45,
      "referencePriceLocal": 20,
      "totalPer100": 4.89,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.03,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 40,
          "firstPrice": 1.26,
          "stepG": 10,
          "additionalPrice": 0.15,
          "currency": "SGD",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "官方费用与SLS费率底稿 2026-11-14 https://solutions.shopee.cn/sellers/pricing-simulator/",
          "effectiveFrom": "2026-11-13",
          "note": "官方模拟器普货标准国际派送藏价；买家运费 SGD 1.87 为买家侧不计卖家成本；快速渠道首重 1.25；重货 ≤100g 2.34+0.60/100g；以藏价与运费计算工具实时值为准"
        },
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "SG",
      "shopType": "cb_overseas_warehouse",
      "currency": "SGD",
      "available": true,
      "compositePct": 19.45,
      "referencePriceLocal": 20,
      "totalPer100": 3.89,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.11,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.03,
          "status": "P"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "cb_sls",
      "currency": "MYR",
      "available": true,
      "compositePct": 27.64,
      "referencePriceLocal": 40,
      "totalPer100": 11.06,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1836,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0378,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 20,
          "firstPrice": 8.5,
          "stepG": 10,
          "additionalPrice": 0.7,
          "currency": "MYR",
          "volumetricDivisor": 6000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡存档：实际计算已走官方模拟器价卡（shopee-sls-cards.generated）"
        },
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "cb_overseas_warehouse",
      "currency": "MYR",
      "available": true,
      "compositePct": 24.4,
      "referencePriceLocal": 40,
      "totalPer100": 9.76,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1512,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0378,
          "status": "P"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "local",
      "currency": "MYR",
      "available": true,
      "compositePct": 7.85,
      "referencePriceLocal": 40,
      "totalPer100": 3.14,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.03,
          "status": "P"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.035,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "TH",
      "shopType": "cb_sls",
      "currency": "THB",
      "available": true,
      "compositePct": 32.4,
      "referencePriceLocal": 250,
      "totalPer100": 81.01,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.2247,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0321,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.0535,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 65,
          "stepG": 10,
          "additionalPrice": 5,
          "currency": "THB",
          "volumetricDivisor": 6000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡：首重 10g 65 THB + 5/10g（存档；实际计算已走官方模拟器价卡）"
        },
        "seaLcl": {
          "pricePerCbm": 800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "VN",
      "shopType": "cb_sls",
      "currency": "VND",
      "available": true,
      "compositePct": 30.83,
      "referencePriceLocal": 300000,
      "totalPer100": 92496,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.18,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.054,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 55000,
          "stepG": 10,
          "additionalPrice": 4000,
          "currency": "VND",
          "volumetricDivisor": 5000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡：首重 10g 55000 VND + 4000/10g（存档；实际计算已走官方模拟器价卡）"
        },
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "VN",
      "shopType": "local",
      "currency": "VND",
      "available": true,
      "compositePct": 6,
      "referencePriceLocal": 300000,
      "totalPer100": 18000,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "P"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "PH",
      "shopType": "cb_sls",
      "currency": "PHP",
      "available": true,
      "compositePct": 14.24,
      "referencePriceLocal": 500,
      "totalPer100": 71.2,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.12,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0224,
          "status": "C"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 90,
          "stepG": 10,
          "additionalPrice": 7,
          "currency": "PHP",
          "volumetricDivisor": 5000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡：首重 10g 90 PHP + 7/10g（存档；实际计算已走官方模拟器价卡）"
        },
        "seaLcl": {
          "pricePerCbm": 950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "ID",
      "shopType": "cb_sls",
      "currency": "IDR",
      "available": false,
      "compositePct": null,
      "referencePriceLocal": null,
      "totalPer100": 0,
      "confidence": "LOW",
      "unknown": true,
      "reason": "该平台在此国家没有这个店型通道（例：TikTok 印尼无跨境 POP），必须换店型或按本土店重算",
      "lines": [],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "TW",
      "shopType": "cb_sls",
      "currency": "TWD",
      "available": true,
      "compositePct": 16.5,
      "referencePriceLocal": 500,
      "totalPer100": 82.5,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.14,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.025,
          "status": "C"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 140,
          "stepG": 10,
          "additionalPrice": 8,
          "currency": "TWD",
          "volumetricDivisor": 5000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；TODO-10：另有「首重 0.5kg」口径（插件按 45 TWD 算），两套差约 3 倍，待官方价卡定一"
        },
        "seaLcl": {
          "pricePerCbm": 1000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "BR",
      "shopType": "cb_sls",
      "currency": "BRL",
      "available": true,
      "compositePct": 23,
      "referencePriceLocal": 80,
      "totalPer100": 18.4,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.02,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 45,
          "stepG": 10,
          "additionalPrice": 5,
          "currency": "BRL",
          "volumetricDivisor": 6000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡：首重 10g 45 BRL + 5/10g（存档；实际计算已走官方模拟器价卡）"
        },
        "seaLcl": {
          "pricePerCbm": 2300,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MX",
      "shopType": "cb_sls",
      "currency": "MXN",
      "available": true,
      "compositePct": 51.5,
      "referencePriceLocal": 400,
      "totalPer100": 206,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.02,
          "status": "C"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.335,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 120,
          "stepG": 10,
          "additionalPrice": 8,
          "currency": "MXN",
          "volumetricDivisor": 6000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "旧虾皮费用表值；底稿本轮仅核验 SG 示例且旧卡差约 10 倍，本行须以官方模拟器/藏价与运费计算工具复核后方可用；旧卡：首重 10g 120 MXN + 8/10g（存档；实际计算已走官方模拟器价卡）"
        },
        "seaLcl": {
          "pricePerCbm": 4800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "AR",
      "shopType": "cb_sls",
      "currency": "ARS",
      "available": true,
      "compositePct": 21,
      "referencePriceLocal": 100,
      "totalPer100": 21,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.05,
          "status": "C"
        },
        {
          "key": "crossBorderFee",
          "label": "跨境服务费",
          "base": "product_price_excl_ship_tax",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {}
    }
  ],
  "officialSea": {
    "cards": [
      {
        "market": "TH",
        "region": "Zone A",
        "channel": "Standard",
        "currency": "THB",
        "firstWeightG": 10,
        "costFirst": 0.4,
        "costStepG": 10,
        "costStep": 0.4,
        "buyerFlat": 23,
        "sellerFirst": 23.4,
        "sellerStep": 0.4
      },
      {
        "market": "TH",
        "region": "Zone B",
        "channel": "Standard",
        "currency": "THB",
        "firstWeightG": 10,
        "costFirst": 0.4,
        "costStepG": 10,
        "costStep": 0.4,
        "buyerFlat": 36,
        "sellerFirst": 36.4,
        "sellerStep": 0.4
      },
      {
        "market": "TH",
        "region": "Zone C",
        "channel": "Standard",
        "currency": "THB",
        "firstWeightG": 10,
        "costFirst": 0.4,
        "costStepG": 10,
        "costStep": 0.4,
        "buyerFlat": 79,
        "sellerFirst": 79.4,
        "sellerStep": 0.4
      },
      {
        "market": "TH",
        "region": "大曼谷",
        "channel": "Express",
        "transport": "空运",
        "currency": "THB",
        "firstWeightG": 10,
        "costFirst": 0.4,
        "costStepG": 10,
        "costStep": 0.4,
        "buyerFlat": 40,
        "sellerFirst": 40.4,
        "sellerStep": 0.4
      },
      {
        "market": "TH",
        "region": "外府",
        "channel": "Express",
        "transport": "空运",
        "currency": "THB",
        "firstWeightG": 10,
        "costFirst": 0.4,
        "costStepG": 10,
        "costStep": 0.4,
        "buyerFlat": 70,
        "sellerFirst": 70.4,
        "sellerStep": 0.4
      },
      {
        "market": "VN",
        "region": "Zone A",
        "channel": "Standard",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 15000,
        "sellerFirst": 15500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "Zone B",
        "channel": "Standard",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 17000,
        "sellerFirst": 17500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "Zone C",
        "channel": "Standard",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 17000,
        "sellerFirst": 17500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "Zone D",
        "channel": "Standard",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 30000,
        "sellerFirst": 30500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "河内",
        "channel": "Express",
        "transport": "空运",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 23000,
        "sellerFirst": 23500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "北部",
        "channel": "Express",
        "transport": "空运",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 32000,
        "sellerFirst": 32500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "中部",
        "channel": "Express",
        "transport": "空运",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 35000,
        "sellerFirst": 35500,
        "sellerStep": 500
      },
      {
        "market": "VN",
        "region": "南部",
        "channel": "Express",
        "transport": "空运",
        "currency": "VND",
        "firstWeightG": 10,
        "costFirst": 500,
        "costStepG": 10,
        "costStep": 500,
        "buyerFlat": 35000,
        "sellerFirst": 35500,
        "sellerStep": 500
      },
      {
        "market": "PH",
        "region": "马尼拉",
        "channel": "Standard",
        "currency": "PHP",
        "firstWeightG": 10,
        "costFirst": 5,
        "costStepG": 10,
        "costStep": 4.5,
        "buyerFlat": 40,
        "sellerFirst": 45,
        "sellerStep": 4.5
      },
      {
        "market": "PH",
        "region": "其他区",
        "channel": "Standard",
        "currency": "PHP",
        "firstWeightG": 10,
        "costFirst": 5,
        "costStepG": 10,
        "costStep": 4.5,
        "buyerFlat": 60,
        "sellerFirst": 65,
        "sellerStep": 4.5
      },
      {
        "market": "MY",
        "region": "西马",
        "channel": "Standard",
        "currency": "MYR",
        "firstWeightG": 30,
        "costFirst": 0.06,
        "costStepG": 10,
        "costStep": 0.08,
        "buyerFlat": 4.9,
        "sellerFirst": 4.96,
        "sellerStep": 0.08
      },
      {
        "market": "MY",
        "region": "东马",
        "channel": "Standard",
        "currency": "MYR",
        "firstWeightG": 30,
        "costFirst": 0.06,
        "costStepG": 10,
        "costStep": 0.08,
        "buyerFlat": 10,
        "sellerFirst": 10.06,
        "sellerStep": 0.08
      },
      {
        "market": "MY",
        "region": "西马",
        "channel": "Express",
        "transport": "空运",
        "currency": "MYR",
        "firstWeightG": 30,
        "costFirst": 0.06,
        "costStepG": 10,
        "costStep": 0.08,
        "buyerFlat": 4.9,
        "sellerFirst": 4.96,
        "sellerStep": 0.08
      },
      {
        "market": "MY",
        "region": "东马",
        "channel": "Express",
        "transport": "空运",
        "currency": "MYR",
        "firstWeightG": 30,
        "costFirst": 0.06,
        "costStepG": 10,
        "costStep": 0.08,
        "buyerFlat": 8,
        "sellerFirst": 8.06,
        "sellerStep": 0.08
      },
      {
        "market": "SG",
        "region": "全境",
        "channel": "Standard",
        "currency": "SGD",
        "firstWeightG": 40,
        "costFirst": 0.98,
        "costStepG": 10,
        "costStep": 0.15,
        "buyerFlat": 0,
        "sellerFirst": 0.98,
        "sellerStep": 0.15
      }
    ],
    "effective": {
      "MY": "2026-10-30",
      "PH": "2026-10-20",
      "TH": "2026-09-24",
      "VN": "2026-09-24",
      "SG": "2026-04-01"
    },
    "source": "TikTok Shop 商家学习中心《【东南亚】跨境物流运费价格表》公告（knowledge_id=6837847978411778，Updated 2026-11-03）内嵌官方价卡图"
  },
  "marketFreight": {
    "rates": [
      {
        "market": "TH",
        "seaUsdPerCbm": 60,
        "seaRange": [
          41,
          90
        ],
        "railUsdPerCbm": 90,
        "source": "天津宝利航2026-07(55-75)+恒盛通2026-03(41-61)"
      },
      {
        "market": "VN",
        "seaUsdPerCbm": 55,
        "seaRange": [
          37,
          80
        ],
        "railUsdPerCbm": 82,
        "source": "天津宝利航2026-07(55-75)+恒盛通2026-03(37-67)"
      },
      {
        "market": "MY",
        "seaUsdPerCbm": 90,
        "seaRange": [
          24,
          110
        ],
        "railUsdPerCbm": 135,
        "source": "天津宝利航2026-07(80-110)+恒盛通2026-03(巴生4-24,取偏高保守)"
      },
      {
        "market": "SG",
        "seaUsdPerCbm": 100,
        "seaRange": [
          80,
          223
        ],
        "railUsdPerCbm": 150,
        "source": "天津宝利航2026-07(80-110)+恒盛通2026-03(143-223,取中)"
      },
      {
        "market": "PH",
        "seaUsdPerCbm": 125,
        "seaRange": [
          110,
          176
        ],
        "railUsdPerCbm": 187,
        "source": "天津宝利航2026-07(110-140)+恒盛通2026-03(135-176)"
      },
      {
        "market": "ID",
        "seaUsdPerCbm": 125,
        "seaRange": [
          110,
          270
        ],
        "railUsdPerCbm": 187,
        "source": "天津宝利航2026-07(110-140)+恒盛通2026-03(雅加达190-270,取中)"
      }
    ],
    "note": "市场预估（货代行情区间中值，港到港拼箱，不含目的港费/清关/派送）；铁路为海运×1.5推算。非官方价卡，须以真实货代报价覆盖。"
  },
  "shopeeSls": {
    "cards": [
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 40.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2022-08-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.87,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-11-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 40,
            "fee": 1.26,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-03"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "Collection Point (Overseas) (买家自取渠道)",
        "channelCn": "Collection Point (Overseas) (买家自取渠道)",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-07-18"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 40.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 40,
            "fee": 1.26,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-01"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "Pick Locker (Overseas)",
        "channelCn": "Pick Locker (Overseas)（自提柜渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 40.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2022-08-24"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 40,
            "fee": 1.26,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-07-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-07-01"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (Sea Shipping) （海运渠道）",
        "channelCn": "Doorstep Delivery (Sea Shipping) （海运渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "Express Doorstep Delivery (International)",
        "channelCn": "Express Doorstep Delivery (International) (快速渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 40,
            "fee": 1.25,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 40.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2024-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.87,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-11-01"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Normal",
        "channel": "SPX Express Lockers (Overseas)",
        "channelCn": "SPX Express Lockers (Overseas)（SPX自提柜渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 40,
            "fee": 1.26,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 40.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-12-01"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Heavy",
        "channel": "Standard Delivery (International)",
        "channelCn": "Standard Delivery (International)   (标准渠道-重货)",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 0.6,
            "effective": "2022-03-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.34,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.87,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-01-01"
          }
        ]
      },
      {
        "market": "SG",
        "currency": "SGD",
        "cargo": "Heavy",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  (快速渠道-重货）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.34,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 0.6,
            "effective": "2024-01-20"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.87,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-07-15"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International)  (标准渠道-重货)",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-07-01"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International)  (标准渠道-重货)",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-07-01"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International)  (标准渠道-重货)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International)  (标准渠道-重货)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道-重货）",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-04-22"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2024-04-22"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-04-22"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道-重货）",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-06-18"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2024-06-18"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-06-18"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2024-06-18"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道-重货）",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Heavy",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道-重货）",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 100,
            "fee": 2.1,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 1.1,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Special",
        "channel": "Economy Delivery",
        "channelCn": "Sea Shipping（海运大件渠道）",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-12"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 1000,
            "fee": 7.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": null,
            "fee": null,
            "unitG": 1000,
            "stepFee": 5,
            "effective": "2023-04-12"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Special",
        "channel": "Economy Delivery",
        "channelCn": "Sea Shipping（海运大件渠道）",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-12"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 1000,
            "fee": 7.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": null,
            "fee": null,
            "unitG": 1000,
            "stepFee": 5,
            "effective": "2023-04-12"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Self Collection (Shopee Xpress)",
        "channelCn": "Self Collection (Shopee Xpress) (买家自提渠道)",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-18"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Self Collection (Shopee Xpress)",
        "channelCn": "Self Collection (Shopee Xpress) (买家自提渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-12-09"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-18"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Self Collection (Shopee Xpress)",
        "channelCn": "Self Collection (Shopee Xpress) (买家自提渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-12-09"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-06-18"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道）",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道）",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道）",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Express Delivery (International)",
        "channelCn": "Express Delivery (International)  （快速渠道）",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 4.9,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 8,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (International Sea Shipping)",
        "channelCn": "Doorstep Delivery (International Sea Shipping) (海运经济渠道)",
        "zone": "Zone KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (International Sea Shipping)",
        "channelCn": "Doorstep Delivery (International Sea Shipping) (海运经济渠道)",
        "zone": "Zone Non-KV",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (International Sea Shipping)",
        "channelCn": "Doorstep Delivery (International Sea Shipping) (海运经济渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (International Sea Shipping)",
        "channelCn": "Doorstep Delivery (International Sea Shipping) (海运经济渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 1.5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MY",
        "currency": "MYR",
        "cargo": "Normal",
        "channel": "Doorstep Delivery (Brunei) (文莱渠道)",
        "channelCn": "Doorstep Delivery (Brunei) (文莱渠道)",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.15,
            "effective": "2026-01-12"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 800,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-12"
          },
          {
            "side": "Buyer",
            "kind": "Increment",
            "startG": 800.01,
            "endG": null,
            "fee": null,
            "unitG": 250,
            "stepFee": 2.2,
            "effective": "2026-01-12"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Express International Delivery (特快渠道 - 内地)",
        "channelCn": "Express International Delivery (特快渠道 - 内地)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 40,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Express International Delivery (特快渠道 - 内地)",
        "channelCn": "Express International Delivery (特快渠道 - 内地)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Express International Delivery (特快渠道 - 内地)",
        "channelCn": "Express International Delivery (特快渠道 - 内地)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 95,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Fast International Delivery",
        "channelCn": "Fast International Delivery (快速渠道)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-06-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2024-06-12"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Fast International Delivery",
        "channelCn": "Fast International Delivery (快速渠道)",
        "zone": "Zone B（部分地区）",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 36,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 79,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道-南宁仓)*",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 22,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道-南宁仓)*",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 29,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道-南宁仓)*",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 79,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Fast International Delivery  (快速渠道-南宁仓)*",
        "channelCn": "Fast International Delivery  (快速渠道-南宁仓)*",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-10-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 22,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-10-10"
          }
        ]
      },
      {
        "market": "TH",
        "currency": "THB",
        "cargo": "Normal",
        "channel": "Fast International Delivery  (快速渠道-南宁仓)*",
        "channelCn": "Fast International Delivery  (快速渠道-南宁仓)*",
        "zone": "Zone B (部分地区)",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 0,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-10-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 29,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-10-10"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Standard International (标准渠道 - 内地)",
        "channelCn": "Standard International (标准渠道 - 内地)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 40,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Standard International (标准渠道 - 内地)",
        "channelCn": "Standard International (标准渠道 - 内地)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Standard International (标准渠道 - 内地)",
        "channelCn": "Standard International (标准渠道 - 内地)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-02-16"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Standard International (标准渠道 - 内地)",
        "channelCn": "Standard International (标准渠道 - 内地)",
        "zone": "Zone D",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-02-16"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Economy International (Sea Shipping)",
        "channelCn": "Economy International (海运经济渠道)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-03-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50,
            "endG": 140,
            "fee": 0,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2026-03-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 140.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.9,
            "effective": "2026-03-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Economy International (Sea Shipping)",
        "channelCn": "Economy International (海运经济渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-25"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-04-25"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": 140,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2023-04-25"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 140.02,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.9,
            "effective": "2023-04-25"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Economy International (Sea Shipping)",
        "channelCn": "Economy International (海运经济渠道)",
        "zone": "Zone D",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-06-05"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-06-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": 140,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2023-06-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 140.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.9,
            "effective": "2023-06-05"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Economy International (Sea Shipping)",
        "channelCn": "Economy International (海运经济渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": -0.01,
            "endG": 50,
            "fee": 22.99,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-03-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": 140,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2026-03-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 140.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.9,
            "effective": "2026-03-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-03-01"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International (快速渠道 - 内地)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 40,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-06-19"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-06-19"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2024-06-19"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International (快速渠道 - 内地)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-10-21"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-10-21"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2024-10-21"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International (快速渠道 - 内地)",
        "zone": "Zone C（部分地区）",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "PH",
        "currency": "PHP",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International (快速渠道 - 内地)",
        "zone": "Zone D（部分地区）",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 50,
            "fee": 23,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 50.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4.5,
            "effective": "2025-12-09"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International",
        "channelCn": "Standard International （标准渠道）",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International",
        "channelCn": "Standard International （标准渠道）",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International",
        "channelCn": "Standard International （标准渠道）",
        "zone": "Zone B1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International",
        "channelCn": "Standard International （标准渠道）",
        "zone": "Zone B2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 30000,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道-南宁仓）",
        "channelCn": "Standard International （标准渠道-南宁仓）",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 10000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 750,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道-南宁仓）",
        "channelCn": "Standard International （标准渠道-南宁仓）",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 750,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道-南宁仓）",
        "channelCn": "Standard International （标准渠道-南宁仓）",
        "zone": "Zone B1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.1,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2025-10-12"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 17750,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-01"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道-南宁仓）",
        "channelCn": "Standard International （标准渠道-南宁仓）",
        "zone": "Zone B2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 30000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 750,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道 - 高价值)",
        "channelCn": "Standard International （标准渠道 - 高价值)",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道 - 高价值)",
        "channelCn": "Standard International （标准渠道 - 高价值)",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道 - 高价值)",
        "channelCn": "Standard International （标准渠道 - 高价值)",
        "zone": "Zone B1",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Standard International （标准渠道 - 高价值)",
        "channelCn": "Standard International （标准渠道 - 高价值)",
        "zone": "Zone B2",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 30000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International （快速渠道）",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2025-12-03"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Express International",
        "channelCn": "Express International （快速渠道）",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2025-12-03"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Express International-NN （快速渠道-南宁仓）",
        "channelCn": "Express International-NN （快速渠道-南宁仓）",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 750,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2025-12-03"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 10000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Express International-NN （快速渠道-南宁仓）",
        "channelCn": "Express International-NN （快速渠道-南宁仓）",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 750,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 750,
            "effective": "2025-12-03"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-12-03"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Locker-Standard International （自提柜）渠道",
        "channelCn": "Locker-Standard International （自提柜）渠道",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15000,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Locker-Standard International （自提柜）渠道",
        "channelCn": "Locker-Standard International （自提柜）渠道",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Locker-Standard International （自提柜）渠道",
        "channelCn": "Locker-Standard International （自提柜）渠道",
        "zone": "Zone B1",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Normal",
        "channel": "Locker-Standard International （自提柜）渠道",
        "channelCn": "Locker-Standard International （自提柜）渠道",
        "zone": "Zone B2",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 900,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 900,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 30000,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Heavy",
        "channel": "Standard Express",
        "channelCn": "Standard Express （标准渠道）",
        "zone": "Zone A1",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 250.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 4500,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15000,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-09-12"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 250,
            "fee": 22500,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Heavy",
        "channel": "Standard Express",
        "channelCn": "Standard Express （标准渠道）",
        "zone": "Zone A2",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 250.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 4500,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 250,
            "fee": 22500,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Heavy",
        "channel": "Standard Express",
        "channelCn": "Standard Express （标准渠道）",
        "zone": "Zone B1",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 250.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 4500,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 250,
            "fee": 22500,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "VN",
        "currency": "VND",
        "cargo": "Heavy",
        "channel": "Standard Express",
        "channelCn": "Standard Express （标准渠道）",
        "zone": "Zone B2",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 250.01,
            "endG": null,
            "fee": null,
            "unitG": 100,
            "stepFee": 4500,
            "effective": "2021-01-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17000,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 250,
            "fee": 22500,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 7-11",
        "channelCn": "蝦皮海外 - 7-11",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 全家",
        "channelCn": "蝦皮海外 - 全家",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 宅配（空運）",
        "channelCn": "蝦皮海外 - 宅配（空運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 70,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 蝦皮店到店",
        "channelCn": "蝦皮海外 - 蝦皮店到店",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-05-01"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-05-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2024-05-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2024-05-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2499.99,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2024-05-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2024-05-01"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 宅配（海運）",
        "channelCn": "蝦皮海外 - 宅配（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-08-23"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - OK MART（海運）",
        "channelCn": "蝦皮海外 - OK MART（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 10,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-04-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-10-31"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 7-11（海運）",
        "channelCn": "蝦皮海外 - 7-11（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500,
            "endG": 999.99,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2023-09-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-04-01"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 快速到貨（蝦皮店到店）",
        "channelCn": "蝦皮海外 - 快速到貨（蝦皮店到店）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Normal",
        "channel": "蝦皮海外 - 蝦皮店到店 （海運）",
        "channelCn": "蝦皮海外 - 蝦皮店到店 （海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 25,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 30,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 7-11",
        "channelCn": "蝦皮海外 - 7-11",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 全家",
        "channelCn": "蝦皮海外 - 全家",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 宅配 （空運）",
        "channelCn": "蝦皮海外 - 宅配 （空運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 70,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-09"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-05-09"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 蝦皮店到店",
        "channelCn": "蝦皮海外 - 蝦皮店到店",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-05-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-05-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-05-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-05-12"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-05-12"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-02-01"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 宅配（海運）",
        "channelCn": "蝦皮海外 - 宅配（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-08-23"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-08-23"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - OK MART（海運）",
        "channelCn": "蝦皮海外 - OK MART（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 10,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-04-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2022-10-31"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2022-10-31"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 7-11（海運）",
        "channelCn": "蝦皮海外 - 7-11（海運）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-04-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2023-09-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2023-09-05"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 快速到貨（蝦皮店到店）",
        "channelCn": "蝦皮海外 - 快速到貨（蝦皮店到店）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 60,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "TW",
        "currency": "TWD",
        "cargo": "Special",
        "channel": "蝦皮海外 - 蝦皮店到店 （海運）",
        "channelCn": "蝦皮海外 - 蝦皮店到店 （海運）",
        "zone": "全部地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 500,
            "fee": 45,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 500.01,
            "endG": 1000,
            "fee": null,
            "unitG": 500,
            "stepFee": 40,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1000.01,
            "endG": 1500,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 1500.01,
            "endG": 2000,
            "fee": null,
            "unitG": 500,
            "stepFee": 50,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2000.01,
            "endG": 2500,
            "fee": null,
            "unitG": 500,
            "stepFee": 60,
            "effective": "2026-01-05"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 2500.01,
            "endG": null,
            "fee": null,
            "unitG": 500,
            "stepFee": 70,
            "effective": "2026-01-05"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 15,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-04-01"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Normal",
        "channel": "Expresso padrão",
        "channelCn": "Expresso padrão （标准渠道）",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-11-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 13,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-03-01"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Normal",
        "channel": "Expresso padrão",
        "channelCn": "Expresso padrão （标准渠道）",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-11-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 17,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-03-01"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Normal",
        "channel": "Expresso padrão",
        "channelCn": "Expresso padrão （标准渠道）",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2021-01-01"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2021-11-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 19,
            "unitG": null,
            "stepFee": null,
            "effective": "2023-03-01"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Special",
        "channel": "Envio especial",
        "channelCn": "Envio especial (特貨渠道)",
        "zone": "Zone A",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30.01,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 20,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Special",
        "channel": "Envio especial",
        "channelCn": "Envio especial (特貨渠道)",
        "zone": "Zone B",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30.01,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 24,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "BR",
        "currency": "BRL",
        "cargo": "Special",
        "channel": "Envio especial",
        "channelCn": "Envio especial (特貨渠道)",
        "zone": "Zone C",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 5,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30.01,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 1.4,
            "effective": "2025-02-26"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 0.9,
            "effective": "2025-02-26"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 26,
            "unitG": null,
            "stepFee": null,
            "effective": "2025-02-26"
          }
        ]
      },
      {
        "market": "MX",
        "currency": "MXN",
        "cargo": "Normal",
        "channel": "Estandar Rapido （标准渠道）",
        "channelCn": "Estandar Rapido （标准渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 21.2,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-01-10"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 2.8,
            "effective": "2024-01-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-07-03"
          }
        ]
      },
      {
        "market": "MX",
        "currency": "MXN",
        "cargo": "Special",
        "channel": "Envio Estandar- Productos Especiales （特货渠道）",
        "channelCn": "Envio Estandar- Productos Especiales （特货渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30.01,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 5,
            "effective": "2022-11-18"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4,
            "effective": "2022-11-18"
          },
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 41.2,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-01-10"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-07-03"
          }
        ]
      },
      {
        "market": "MX",
        "currency": "MXN",
        "cargo": "Special",
        "channel": "所有地区",
        "channelCn": "所有地区",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 30,
            "fee": 41.2,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-08-13"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 30.01,
            "endG": 100,
            "fee": null,
            "unitG": 10,
            "stepFee": 5,
            "effective": "2024-08-13"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 100.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 4,
            "effective": "2024-08-13"
          },
          {
            "side": "Buyer",
            "kind": "Flat",
            "startG": null,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2024-08-13"
          }
        ]
      },
      {
        "market": "AR",
        "currency": "ARS",
        "cargo": "Normal",
        "channel": "Expreso estándar  （标准渠道）",
        "channelCn": "Expreso estándar  （标准渠道）",
        "zone": "所有地区",
        "modes": [
          {
            "side": "Seller",
            "kind": "WeightRange",
            "startG": 0,
            "endG": 10,
            "fee": 4562,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-09-16"
          },
          {
            "side": "Seller",
            "kind": "Increment",
            "startG": 10.01,
            "endG": null,
            "fee": null,
            "unitG": 10,
            "stepFee": 393,
            "effective": "2026-09-16"
          },
          {
            "side": "Buyer",
            "kind": "WeightRange",
            "startG": 0,
            "endG": null,
            "fee": 0,
            "unitG": null,
            "stepFee": null,
            "effective": "2026-09-16"
          }
        ]
      }
    ],
    "defaults": {
      "SG": {
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "所有地区"
      },
      "MY": {
        "cargo": "Normal",
        "channel": "Standard Doorstep Delivery (International)",
        "channelCn": "Standard Doorstep Delivery (International) (标准渠道)",
        "zone": "Zone KV"
      },
      "TH": {
        "cargo": "Normal",
        "channel": "Standard International Delivery",
        "channelCn": "Standard International Delivery (标准渠道)",
        "zone": "Zone A"
      },
      "PH": {
        "cargo": "Normal",
        "channel": "Standard International (标准渠道 - 内地)",
        "channelCn": "Standard International (标准渠道 - 内地)",
        "zone": "Zone A"
      },
      "VN": {
        "cargo": "Normal",
        "channel": "Standard International",
        "channelCn": "Standard International （标准渠道）",
        "zone": "Zone A1"
      },
      "TW": {
        "cargo": "Normal",
        "channel": "蝦皮海外 - 7-11",
        "channelCn": "蝦皮海外 - 7-11",
        "zone": "所有地区"
      },
      "BR": {
        "cargo": "Normal",
        "channel": "Expresso padrão",
        "channelCn": "Expresso padrão （标准渠道）",
        "zone": "Zone A"
      },
      "MX": {
        "cargo": "Normal",
        "channel": "Estandar Rapido （标准渠道）",
        "channelCn": "Estandar Rapido （标准渠道）",
        "zone": "所有地区"
      },
      "AR": {
        "cargo": "Normal",
        "channel": "Expreso estándar  （标准渠道）",
        "channelCn": "Expreso estándar  （标准渠道）",
        "zone": "所有地区"
      }
    },
    "snapshot": "2026-11-14",
    "source": "Shopee 官方 SLS 定价模拟器 API /sls/site-config（solutions.shopee.cn）"
  },
  "tiktokIntl": {
    "cards": [
      {
        "market": "UK",
        "marketName": "英国",
        "currency": "GBP",
        "channel": "Standard",
        "cargoType": "普货",
        "firstWeightG": 50,
        "volumetricDivisor": 8000,
        "volumetricRatioThreshold": 1.5,
        "maxWeightKg": 30,
        "maxSizeCm": [
          60,
          40,
          40
        ],
        "buyerFlat": 3.99,
        "buyerFlatNote": "买家支付运费含VAT",
        "effective": "2026-11-01",
        "sourceUrl": "https://seller.tiktokglobalshop.com/university/essay?knowledge_id=6837847978247938",
        "bands": [
          {
            "maxKg": 0.45,
            "perParcel": 2.1,
            "perKg": 5.75
          },
          {
            "maxKg": 1,
            "perParcel": 1.95,
            "perKg": 6
          },
          {
            "maxKg": 2,
            "perParcel": 1.95,
            "perKg": 6
          },
          {
            "maxKg": 30,
            "perParcel": 1.95,
            "perKg": 6.75
          }
        ],
        "note": "运费=perParcel+perKg×计费重kg；按档取率；50g首重不足按50g；2026-11-01生效"
      },
      {
        "market": "UK",
        "marketName": "英国",
        "currency": "GBP",
        "channel": "Standard",
        "cargoType": "特货",
        "firstWeightG": 50,
        "volumetricDivisor": 8000,
        "volumetricRatioThreshold": 1.5,
        "maxWeightKg": 30,
        "maxSizeCm": [
          60,
          40,
          40
        ],
        "buyerFlat": 3.99,
        "effective": "2026-11-01",
        "sourceUrl": "https://seller.tiktokglobalshop.com/university/essay?knowledge_id=6837847978247938",
        "bands": [
          {
            "maxKg": 0.45,
            "perParcel": 2.1,
            "perKg": 6.65
          },
          {
            "maxKg": 1,
            "perParcel": 2.2,
            "perKg": 6.55
          },
          {
            "maxKg": 2,
            "perParcel": 1.5,
            "perKg": 7.35
          },
          {
            "maxKg": 30,
            "perParcel": 1.5,
            "perKg": 7.35
          }
        ],
        "note": "特货=含电含磁；运费=perParcel+perKg×计费重kg"
      },
      {
        "market": "UK",
        "marketName": "英国",
        "currency": "GBP",
        "channel": "Standard",
        "cargoType": "敏货",
        "firstWeightG": 50,
        "volumetricDivisor": 8000,
        "volumetricRatioThreshold": 1.5,
        "maxWeightKg": 30,
        "maxSizeCm": [
          60,
          40,
          40
        ],
        "buyerFlat": 3.99,
        "effective": "2026-11-01",
        "sourceUrl": "https://seller.tiktokglobalshop.com/university/essay?knowledge_id=6837847978247938",
        "bands": [
          {
            "maxKg": 0.45,
            "perParcel": 2.1,
            "perKg": 6.65
          },
          {
            "maxKg": 1,
            "perParcel": 2.2,
            "perKg": 6.55
          },
          {
            "maxKg": 2,
            "perParcel": 1.5,
            "perKg": 7.35
          },
          {
            "maxKg": 30,
            "perParcel": 1.5,
            "perKg": 7.35
          }
        ],
        "note": "敏货=液体粉末膏状颗粒凝胶化妆品日化；运费=perParcel+perKg×计费重kg"
      },
      {
        "market": "JP",
        "marketName": "日本",
        "currency": "JPY",
        "channel": "Standard",
        "cargoType": "普货",
        "firstWeightG": 50,
        "volumetricDivisor": 8000,
        "volumetricRatioThreshold": 1.5,
        "maxWeightKg": 30,
        "maxSizeCm": [
          60,
          50,
          40
        ],
        "effective": "2026-04-24",
        "sourceUrl": "https://seller.tiktokglobalshop.com/university/essay?identity=1&knowledge_id=6411933700818705&role=1",
        "bands": [
          {
            "maxKg": 0.5,
            "perParcel": 545,
            "perKg": 340
          },
          {
            "maxKg": 1,
            "perParcel": 560,
            "perKg": 340
          },
          {
            "maxKg": 2,
            "perParcel": 590,
            "perKg": 340
          },
          {
            "maxKg": 5,
            "perParcel": 590,
            "perKg": 405
          },
          {
            "maxKg": 10,
            "perParcel": 590,
            "perKg": 415
          },
          {
            "maxKg": 20,
            "perParcel": 590,
            "perKg": 425
          },
          {
            "maxKg": 30,
            "perParcel": 590,
            "perKg": 435
          }
        ],
        "note": "运费=perParcel+perKg×计费重kg；50g起重按g计费；2026-04-24生效"
      },
      {
        "market": "JP",
        "marketName": "日本",
        "currency": "JPY",
        "channel": "Standard",
        "cargoType": "特货",
        "firstWeightG": 50,
        "volumetricDivisor": 8000,
        "volumetricRatioThreshold": 1.5,
        "maxWeightKg": 30,
        "maxSizeCm": [
          60,
          50,
          40
        ],
        "effective": "2026-04-24",
        "sourceUrl": "https://seller.tiktokglobalshop.com/university/essay?identity=1&knowledge_id=6411933700818705&role=1",
        "bands": [
          {
            "maxKg": 0.5,
            "perParcel": 555,
            "perKg": 400
          },
          {
            "maxKg": 1,
            "perParcel": 580,
            "perKg": 420
          },
          {
            "maxKg": 2,
            "perParcel": 610,
            "perKg": 420
          },
          {
            "maxKg": 5,
            "perParcel": 610,
            "perKg": 510
          },
          {
            "maxKg": 10,
            "perParcel": 610,
            "perKg": 525
          },
          {
            "maxKg": 20,
            "perParcel": 610,
            "perKg": 535
          },
          {
            "maxKg": 30,
            "perParcel": 610,
            "perKg": 545
          }
        ],
        "note": "特货/敏货同价；运费=perParcel+perKg×计费重kg"
      }
    ],
    "source": "TikTok Shop 商家大学官方物流价卡文章（seller.tiktokglobalshop.com/university）"
  }
};
})(typeof window !== 'undefined' ? window : this);
