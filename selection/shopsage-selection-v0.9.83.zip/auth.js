/**
 * ShopSage 选品助手 · 登录与后台请求 v3（2026-11-09）
 *
 * 老板口径：① 插件登录要像生图网站一样用官网一键登录，不再输密码；
 *           ② 不要经常重新登录（之前 15 分钟就掉线的体验很差）。
 *
 * 这版两条都从根上解决，且仍然只用官网这一套账号地基（无第二套凭据表）：
 *
 *  一键登录（主路径）：
 *    插件打开官网中转页 /extension/handoff?ext=<插件ID> → 官网登录态签发 60 秒一次性票据
 *    （aud=shopsage-extension）→ 页面 chrome.runtime.sendMessage 直接递给插件 →
 *    插件拿票据 POST /api/v1/extension/handoff → 换 access + refresh 令牌（响应体）。
 *    刷新令牌 7 天轮换，从此 7 天内打开插件直接可用；官网登出即作废。
 *
 *  静默续期（次路径兜底）：
 *    access token 15 分钟；临期用刷新令牌 POST /api/v1/auth/refresh（放请求体，
 *    不依赖第三方 Cookie——之前走 Cookie 的路被跨源 SameSite 掐死，这就是反复掉线的根因）。
 *    后台轮换：旧的作废、新的回到响应体，插件跟着更新存储。
 *
 *  密码登录保留为兜底（官网 Cookie 被清了/插件刚装）。
 *  密码与刷新令牌的存放：刷新令牌存 chrome.storage（第一方客户端，等同移动端做法）；
 *  密码永不落盘；官网后台退出登录，服务端会话作废，插件同步下线。
 */
(function (root) {
  'use strict';

  var DEFAULT_BASE = 'https://www.shopsage.cc';
  var ACCESS_TTL_MS = 12 * 60 * 1000;   // 官网 15 分钟，提前 3 分钟续
  var STORE_KEYS = ['backendUrl', 'email', 'accessToken', 'tokenAt', 'refreshToken', 'userName'];

  function baseOf(url) {
    return String(url || '').trim().replace(/\/+$/, '') || DEFAULT_BASE;
  }

  function state() {
    return chrome.storage.local.get({
      backendUrl: '', email: '', accessToken: '', tokenAt: 0, refreshToken: '', userName: ''
    });
  }

  function isConnected(s) {
    return !!(s && (s.accessToken || s.refreshToken));
  }

  /** 裸请求：返回 {status, data}，不抛错。 */
  async function raw(path, init, base) {
    var res = await fetch(baseOf(base) + path, {
      method: (init && init.method) || 'GET',
      credentials: 'include',
      headers: Object.assign(
        { 'Content-Type': 'application/json', 'x-app-locale': 'zh' },
        (init && init.headers) || {}
      ),
      body: init && init.body
    }).catch(function () {
      throw new Error('连不上 ShopSage 官网，请检查网络后重试');
    });
    var data = await res.json().catch(function () { return {}; });
    return { status: res.status, data: data };
  }

  function errOf(data, status, fallback) {
    var m = (data && (data.message || (data.data && data.data.message))) || '';
    return m || fallback || ('后台返回 ' + status);
  }

  /** 官网后台全局信封 {success,data}——不拆包调用方拿到的是空壳。 */
  function unwrap(envelope) {
    if (envelope && typeof envelope === 'object' &&
        Object.prototype.hasOwnProperty.call(envelope, 'success') &&
        Object.prototype.hasOwnProperty.call(envelope, 'data')) {
      return envelope.data;
    }
    return envelope;
  }

  /** 用刷新令牌换新令牌（后台轮换：旧的作废）。优先请求体；没有刷新令牌时试官网 Cookie。 */
  async function renew() {
    var s = await state();
    var body = s.refreshToken ? { refreshToken: s.refreshToken } : {};
    var r = await raw('/api/auth/refresh', { method: 'POST', body: JSON.stringify(body) });
    if (r.status !== 200) {
      if (r.data && r.data.code === 'INVALID_REFRESH_TOKEN') throw new Error('EXPIRED');
      throw new Error('RENEW_FAILED');
    }
    var payload = unwrap(r.data) || {};
    var accessToken = payload.accessToken;
    var refreshToken = payload.refreshToken || s.refreshToken || '';
    if (!accessToken) throw new Error('EXPIRED');
    await chrome.storage.local.set({
      accessToken: accessToken,
      refreshToken: refreshToken,
      tokenAt: Date.now(),
      userName: (payload.user && (payload.user.name || payload.user.email)) || s.userName || s.email || '',
    });
    return accessToken;
  }

  /** 临期自动续；续不动 = 真掉线，如实 NEED_LOGIN。 */
  async function validToken() {
    var s = await state();
    if (!s.accessToken && !s.refreshToken) throw new Error('NEED_LOGIN');
    if (s.accessToken && Date.now() - Number(s.tokenAt || 0) < ACCESS_TTL_MS) return s.accessToken;
    try {
      return await renew();
    } catch (e) {
      if (e.message === 'EXPIRED' || e.message === 'RENEW_FAILED') {
        await chrome.storage.local.remove(['accessToken', 'tokenAt']);
        throw new Error('NEED_LOGIN');
      }
      throw e;
    }
  }

  /* ── 拼图滑块验证码（账号密码登录用；对齐后端 /api/auth/slider-captcha） ── */
  async function sliderIssue() {
    var s = await state(); var base = baseOf(s.backendUrl);
    var r = await raw('/api/auth/slider-captcha', { method: 'GET' }, base);
    if (r.status !== 200) throw new Error(errOf(r.data, r.status, '安全验证加载失败，请稍后重试'));
    var d = unwrap(r.data) || {};
    return d.id ? { id: d.id, bg: d.bg, piece: d.piece, pieceY: Number(d.pieceY || 56), maxSlide: Number(d.maxSlide || 268) } : null;
  }

  async function sliderVerify(id, x) {
    var s = await state(); var base = baseOf(s.backendUrl);
    var r = await raw('/api/auth/slider-captcha/verify', { method: 'POST', body: JSON.stringify({ id: id, x: Math.round(x) }) }, base);
    var d = unwrap(r.data) || {};
    if (r.status === 200 && d.ok) return { passToken: d.passToken || null };
    throw new Error(errOf(r.data, r.status, '滑动验证未完成，请重试'));
  }

  function svgDataUri(svg) {
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(String(svg || ''));
  }

  function openSliderModal(opts) {
    opts = opts || {};
    var modal = document.getElementById('msSliderModal');
    var host = document.getElementById('msSliderHost');
    var closeBtn = document.getElementById('msSliderClose');
    if (!modal || !host) {
      if (opts.onVerified) opts.onVerified(null);
      return function () {};
    }

    var cancelled = false;
    var timer = null;
    var puzzle = null;
    var x = 0;
    var status = 'idle';
    var drag = null;
    var imageEl = null;
    var pieceEl = null;
    var trackEl = null;
    var fillEl = null;
    var handleEl = null;
    var tipEl = null;

    function clearTimer() {
      if (timer) { window.clearTimeout(timer); timer = null; }
    }

    function finish(passToken) {
      if (cancelled) return;
      cancelled = true;
      clearTimer();
      modal.classList.add('hidden');
      host.innerHTML = '';
      if (opts.onVerified) opts.onVerified(passToken);
    }

    function cancel() {
      if (cancelled) return;
      cancelled = true;
      clearTimer();
      modal.classList.add('hidden');
      host.innerHTML = '';
      if (opts.onCancel) opts.onCancel();
    }

    function paint() {
      if (!puzzle || !trackEl || !imageEl || !pieceEl || !fillEl || !handleEl || !tipEl) return;
      var trackW = trackEl.clientWidth || 320;
      var handleTravel = Math.max(1, trackW - 40);
      var fraction = puzzle.maxSlide > 0 ? x / puzzle.maxSlide : 0;
      var handleLeft = fraction * handleTravel;
      pieceEl.style.left = (x / 320 * 100) + '%';
      fillEl.style.width = Math.round(handleLeft + 40) + 'px';
      handleEl.style.left = Math.round(handleLeft) + 'px';
      trackEl.classList.toggle('ok', status === 'ok');
      trackEl.classList.toggle('fail', status === 'fail');
      tipEl.textContent = status === 'verifying' ? '验证中…' :
        status === 'ok' ? '验证通过' :
        status === 'fail' ? '没对齐，已换一张' :
        '拖动滑块，完成拼图';
    }

    function load() {
      status = 'idle';
      x = 0;
      drag = null;
      host.innerHTML = '<div class="ms-slider-loading">正在加载安全验证…</div>';
      sliderIssue().then(function (p) {
        if (cancelled) return;
        if (!p) { finish(null); return; }
        puzzle = p;
        host.innerHTML =
          '<div class="ms-slider-image">' +
            '<img class="ms-slider-bg" alt="滑动拼图验证" draggable="false" src="' + svgDataUri(p.bg) + '">' +
            '<img class="ms-slider-piece" alt="" draggable="false" src="' + svgDataUri(p.piece) + '">' +
            '<div class="ms-slider-ok hidden"><span>验证通过</span></div>' +
          '</div>' +
          '<div class="ms-slider-track">' +
            '<div class="ms-slider-fill"></div>' +
            '<div class="ms-slider-tip">拖动滑块，完成拼图</div>' +
            '<button class="ms-slider-handle" type="button" aria-label="滑动验证">' +
              '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>' +
            '</button>' +
          '</div>';
        imageEl = host.querySelector('.ms-slider-image');
        pieceEl = host.querySelector('.ms-slider-piece');
        var okEl = host.querySelector('.ms-slider-ok');
        trackEl = host.querySelector('.ms-slider-track');
        fillEl = host.querySelector('.ms-slider-fill');
        handleEl = host.querySelector('.ms-slider-handle');
        tipEl = host.querySelector('.ms-slider-tip');
        pieceEl.style.top = ((p.pieceY - 9) / 160 * 100) + '%';
        if (okEl) okEl.classList.add('hidden');
        paint();
      }).catch(function (e) {
        if (cancelled) return;
        host.innerHTML = '<div class="ms-slider-loading">' + (e && e.message ? e.message : '安全验证加载失败') + '</div>';
        clearTimer();
        timer = window.setTimeout(function () { cancel(); }, 1200);
      });
    }

    function onPointerDown(e) {
      if (!puzzle || status === 'ok' || status === 'verifying') return;
      try { handleEl.setPointerCapture(e.pointerId); } catch (err) {}
      drag = { startClientX: e.clientX, startX: x };
      e.preventDefault();
    }

    function onPointerMove(e) {
      if (!drag || !puzzle || status === 'ok' || status === 'verifying') return;
      var trackW = trackEl && trackEl.clientWidth ? trackEl.clientWidth : 320;
      var travel = Math.max(1, trackW - 40);
      var fraction = (drag.startX + (e.clientX - drag.startClientX)) / travel;
      x = Math.max(0, Math.min(puzzle.maxSlide, fraction * puzzle.maxSlide));
      paint();
    }

    async function onPointerUp() {
      if (!drag || !puzzle || status === 'ok' || status === 'verifying') { drag = null; return; }
      drag = null;
      var sentX = Math.round(x);
      if (sentX <= 1) return;
      status = 'verifying';
      paint();
      try {
        var res = await sliderVerify(puzzle.id, sentX);
        if (cancelled) return;
        status = 'ok';
        paint();
        var okEl = host.querySelector('.ms-slider-ok');
        if (okEl) okEl.classList.remove('hidden');
        clearTimer();
        timer = window.setTimeout(function () { finish(res.passToken); }, 600);
      } catch (e) {
        if (cancelled) return;
        status = 'fail';
        paint();
        clearTimer();
        timer = window.setTimeout(load, 700);
      }
    }

    if (closeBtn) closeBtn.onclick = cancel;
    modal.addEventListener('click', function (e) { if (e.target === modal) cancel(); });
    host.addEventListener('pointerdown', function (e) {
      if (e.target === handleEl || (handleEl && handleEl.contains(e.target))) onPointerDown(e);
    });
    host.addEventListener('pointermove', onPointerMove);
    host.addEventListener('pointerup', onPointerUp);
    host.addEventListener('pointercancel', onPointerUp);
    modal.classList.remove('hidden');
    load();
    return cancel;
  }

  /** 账号密码登录（兜底路径）。密码不落盘。sliderPassToken=拼图验证一次性令牌。 */
  async function login(email, password, sliderPassToken) {
    email = String(email || '').trim();
    if (!email || !password) throw new Error('请填邮箱和密码');
    var s = await state();
    var base = baseOf(s.backendUrl);
    var body = { email: email, password: password };
    if (sliderPassToken) body.sliderPassToken = String(sliderPassToken);
    var r = await raw('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(body)
    }, base);
    if (r.status !== 200) { var _e = errOf(r.data, r.status, '登录失败，请检查邮箱和密码'); var _err = new Error(_e); _err.code = (r.data && (r.data.code || (r.data.data && r.data.data.code))) || ''; throw _err; }
    var payload = unwrap(r.data) || {};
    var user = payload.user || {};
    if (!payload.accessToken) throw new Error('官网没有返回登录凭证');

    // 密码登录也补换一枚刷新令牌：登录响应只带 Cookie（跨源拿不到），走一次 refresh 换出令牌对的另一半
    var refreshToken = '';
    try {
      var rr = await raw('/api/auth/refresh', { method: 'POST', body: '{}' }, base);
      if (rr.status === 200) {
        var rp = unwrap(rr.data) || {};
        accessToken2Check(rp);
        refreshToken = rp.refreshToken || '';
        payload.accessToken = rp.accessToken || payload.accessToken;
      }
    } catch (e) { /* 换不出就先只有 15 分钟 access——如实不编 */ }

    await chrome.storage.local.set({
      backendUrl: base,
      email: email,
      userName: user.name || user.email || email,
      accessToken: payload.accessToken,
      refreshToken: refreshToken,
      tokenAt: Date.now(),
    });
    return { email: email, name: user.name || user.email || email, hasRenew: !!refreshToken };
  }

  function accessToken2Check(rp) { /* 占位：refresh 响应的形状校验走 unwrap 之外不做强校验 */ }

  /** 退出：让官网把会话作废（有刷新令牌就带上），再清本地。 */
  async function logout() {
    var s = await state();
    var base = baseOf(s.backendUrl);
    try {
      if (s.refreshToken) {
        await raw('/api/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: s.refreshToken }) }, base);
      }
    } catch (e) { /* 够不着也要让用户能退出本地 */ }
    await chrome.storage.local.remove(STORE_KEYS);
  }

  /** 统一后台请求：临期自动续（401 再续一次重试），401 = 请重新登录。 */
  async function backendFetch(path, init) {
    var s = await state();
    if (!s.accessToken && !s.refreshToken) throw new Error('NEED_LOGIN');
    var base = baseOf(s.backendUrl);
    var token = await validToken();

    var r = await raw(path, {
      method: (init && init.method) || 'GET',
      headers: { Authorization: 'Bearer ' + token },
      body: init && init.body
    }, base);

    if (r.status === 401) {
      var renewed = null;
      try { renewed = await renew(); } catch (e) { /* 续不上就走 NEED_LOGIN */ }
      if (!renewed) throw new Error('NEED_LOGIN');
      r = await raw(path, {
        method: (init && init.method) || 'GET',
        headers: { Authorization: 'Bearer ' + renewed },
        body: init && init.body
      }, base);
      if (r.status === 401) throw new Error('NEED_LOGIN');
    }
    if (r.status >= 400) throw new Error(errOf(r.data, r.status, '后台返回 ' + r.status));
    return unwrap(r.data);
  }

  function friendlyError(message) {
    if (message === 'NEED_LOGIN') return '登录已失效，请重新登录（可用官网一键登录，几秒完成）。';
    if (message === 'RENEW_FAILED') return '暂时无法自动续期，请重新登录一次。';
    return message || '操作没有成功，请重试。';
  }

  /* ── 一键登录：官网中转页把一次性票据递进来 ───────────────────────── */

  /** 拿到 {accessToken, refreshToken, user} 后统一落盘并广播登录态变化。 */
  async function applyTokens(payload, base) {
    if (!payload.accessToken || !payload.refreshToken) throw new Error('官网没有返回完整令牌');
    var user = payload.user || {};
    await chrome.storage.local.set({
      backendUrl: base,
      email: user.email || '',
      userName: user.name || user.email || '',
      accessToken: payload.accessToken,
      refreshToken: payload.refreshToken,
      tokenAt: Date.now(),
    });
    // 通知打开着的页面（登录闸门/选品库）刷新登录态
    try { window.dispatchEvent(new Event('ms-auth-changed')); } catch (e) { /* noop */ }
    return { email: user.email || '', name: user.name || user.email || '' };
  }

  async function handoff(ticket) {
    if (!ticket) throw new Error('缺少登录票据');
    var s = await state();
    var base = baseOf(s.backendUrl);
    var r = await raw('/api/v1/extension/handoff', {
      method: 'POST',
      body: JSON.stringify({ ticket: String(ticket) })
    }, base);
    if (r.status !== 200) throw new Error(errOf(r.data, r.status, '一键登录失败，请回插件重试'));
    return applyTokens(unwrap(r.data) || {}, base);
  }

  /*
   * ── 换电脑登录（2026-11-13）───────────────────────────────────────
   * 一键登录靠官网页面把票据「递」给本机插件（chrome.runtime.sendMessage）。
   * 换一台电脑就递不到：插件刚装、扩展 ID 变了、或浏览器还没建立通道，
   * 页面会报 "Receiving end does not exist" —— 老板反馈的「换电脑同步不了」就是这个。
   * 补一条不依赖浏览器通信的路：旧电脑生成 8 位登录码 → 新电脑手动输入兑换，
   * 换出来的是同一套 access/refresh 令牌，不新增第二套账号体系。
   */

  /** 旧电脑（已登录）调：向服务端要一枚一次性登录码。 */
  async function requestLoginCode() {
    var d = await backendFetch('/api/extension/handoff/code', { method: 'POST', body: '{}' });
    var out = d || {};
    if (!out.code) throw new Error('官网没有返回登录码，请稍后重试');
    return { code: String(out.code), expiresInSec: Number(out.expiresInSec || 300) };
  }

  /** 新电脑调：把登录码换成令牌（这个请求本身不需要任何登录态）。 */
  async function loginWithCode(code) {
    var clean = String(code || '').toUpperCase().replace(/[\s-]/g, '');
    if (clean.length !== 8) throw new Error('登录码是 8 位字母数字，请核对后再输入');
    var s = await state();
    var base = baseOf(s.backendUrl);
    var r = await raw('/api/v1/extension/handoff/redeem', {
      method: 'POST',
      body: JSON.stringify({ code: clean })
    }, base);
    if (r.status !== 200) throw new Error(errOf(r.data, r.status, '登录码无效或已过期，请回原来那台电脑重新生成'));
    return applyTokens(unwrap(r.data) || {}, base);
  }

  /** 官网中转页（shopsage.cc 域）通过 externally_connectable 递票据进来。 */
  if (root.chrome && root.chrome.runtime && root.chrome.runtime.onMessageExternal) {
    root.chrome.runtime.onMessageExternal.addListener(function (msg, sender, sendResponse) {
      var okSender = sender && sender.url && /https:\/\/([a-z0-9-]+\.)?shopsage\.cc\//.test(sender.url);
      if (!okSender || !msg || msg.type !== 'shopsage-handoff' || !msg.ticket) {
        sendResponse({ ok: false, error: '来源或消息不符合' });
        return true;
      }
      handoff(msg.ticket).then(
        function (r) { sendResponse({ ok: true, email: r.email }); },
        function (e) { sendResponse({ ok: false, error: e && e.message ? e.message : String(e) }); }
      );
      return true;   // 异步应答
    });
  }

  function wirePasswordEye() {
    var input = document.getElementById('msGatePassword');
    var eye = document.getElementById('msGateEye');
    if (!input || !eye) return;
    var EYE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
    var EYE_OFF = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
    function paint() {
      var shown = input.type === 'text';
      eye.innerHTML = shown ? EYE_OFF : EYE;
      eye.setAttribute('aria-label', shown ? '隐藏密码' : '显示密码');
      eye.setAttribute('data-shown', shown ? '1' : '0');
    }
    eye.onclick = function () { input.type = input.type === 'text' ? 'password' : 'text'; paint(); };
    paint();
  }

  function friendlyError(message) {
    if (message === 'NEED_LOGIN') return '登录已失效，请重新登录（可用官网一键登录，几秒完成）。';
    if (message === 'RENEW_FAILED') return '暂时无法自动续期，请重新登录一次。';
    return message || '操作没有成功，请重试。';
  }

  /**
   * 登录闸门：顶部一颗「用官网账号一键登录」主按钮（打开官网中转页，几秒完成），
   * 账号密码表单收成兜底折叠。没登录只见登录框，登录成功才出正文。
   */
  async function mountGate(opts) {
    var gate = document.getElementById('msGate');
    var main = document.getElementById('msMain');
    var s = await state();
    wirePasswordEye();

    function render(on) {
      if (gate) gate.classList.toggle('hidden', !!on);
      if (main) main.classList.toggle('hidden', !on);
      var chip = document.getElementById('msAccount');
      if (chip) chip.textContent = on ? (s.userName || s.email || '已登录') : '未登录';
      var out = document.getElementById('msLogout');
      if (out) out.style.display = on ? '' : 'none';
    }

    var oneBtn = document.getElementById('msOneClick');
    if (oneBtn) {
      oneBtn.onclick = function () {
        var msg = document.getElementById('msGateMsg');
        if (msg) { msg.textContent = '正在打开官网连接页…'; }
        try {
          chrome.tabs.create({ url: baseOf(s.backendUrl) + '/extension/handoff?ext=' + chrome.runtime.id });
        } catch (e) { if (msg) msg.textContent = '打开官网连接页失败：' + e.message; }
      };
    }

    var btn = document.getElementById('msGateLogin');
    var msg = document.getElementById('msGateMsg');
    if (btn) {
      var doLogin = async function (sliderPassToken) {
        var email = document.getElementById('msGateEmail');
        var pass = document.getElementById('msGatePassword');
        btn.disabled = true;
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = '正在登录…'; }
        try {
          var r = await login(email ? email.value : '', pass ? pass.value : '', sliderPassToken);
          if (pass) pass.value = '';
          s = await state();
          render(true);
          if (msg) {
            msg.className = 'ms-gate-msg ok';
            msg.textContent = r.hasRenew
              ? '已登录，7 天内打开插件直接可用。'
              : '已登录；此次没能建立 7 天续期，下次打开需重新登录一次。';
          }
          if (opts && opts.onConnected) opts.onConnected();
        } catch (e) {
          if (msg) { msg.className = 'ms-gate-msg err'; msg.textContent = friendlyError(e.message); }
        } finally {
          btn.disabled = false;
        }
      };

      btn.onclick = function () {
        var email = document.getElementById('msGateEmail');
        var pass = document.getElementById('msGatePassword');
        if (!email || !String(email.value || '').trim() || !pass || !pass.value) {
          if (msg) { msg.className = 'ms-gate-msg err'; msg.textContent = '请填邮箱和密码'; }
          return;
        }
        btn.disabled = true;
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = '请完成安全验证…'; }
        openSliderModal({
          onVerified: function (passToken) { doLogin(passToken); },
          onCancel: function () {
            btn.disabled = false;
            if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = ''; }
          }
        });
      };
      var passEl = document.getElementById('msGatePassword');
      if (passEl) passEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') btn.click(); });
    }

    /*
     * 换电脑登录 · 新电脑这一侧：输入旧电脑上生成的 8 位登录码。
     * （一键登录递不过来时才需要它，所以放在一键登录按钮下面，不当主路径。）
     */
    var codeBtn = document.getElementById('msGateCodeLogin');
    var codeInput = document.getElementById('msGateCode');
    if (codeBtn && codeInput) {
      codeBtn.onclick = async function () {
        codeBtn.disabled = true;
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = '正在校验登录码…'; }
        try {
          // 成功时 applyTokens 会派发 ms-auth-changed，由下面那个统一监听刷新闸门，
          // 这里不再自己 render，避免两处异步互相盖掉（一次渲染只认一处）。
          await loginWithCode(codeInput.value);
          codeInput.value = '';
          if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = ''; }
        } catch (e) {
          if (msg) { msg.className = 'ms-gate-msg err'; msg.textContent = friendlyError(e.message); }
        } finally {
          codeBtn.disabled = false;
        }
      };
      codeInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') codeBtn.click(); });
    }

    /*
     * 换电脑登录 · 旧电脑这一侧：生成一次性登录码（5 分钟有效，用一次即失效）。
     * 这段在「已登录」的正文区，闸门那句提示已经看不见了，所以用自己的提示位，
     * 没有 msDeviceCodeMsg 时才退回闸门提示。
     */
    var genBtn = document.getElementById('msDeviceCode');
    var genOut = document.getElementById('msDeviceCodeOut');
    var genMsg = document.getElementById('msDeviceCodeMsg') || msg;
    var genTimer = null;
    function stopCodeCountdown() {
      if (genTimer) { clearInterval(genTimer); genTimer = null; }
    }
    function say(text, kind) {
      if (!genMsg) return;
      genMsg.className = kind === 'err' ? 'ms-gate-msg err' : 'ms-gate-msg';
      genMsg.textContent = text;
    }
    if (genBtn && genOut) {
      genBtn.onclick = async function () {
        stopCodeCountdown();
        genBtn.disabled = true;
        genOut.textContent = '';
        genOut.className = 'device-code';
        say('正在生成…');
        try {
          var r = await requestLoginCode();
          var left = Math.max(1, Number(r.expiresInSec || 300));
          var paint = function () {
            var m = Math.floor(left / 60);
            var ss = String(left % 60);
            if (ss.length < 2) ss = '0' + ss;
            genOut.textContent = r.code.slice(0, 4) + ' ' + r.code.slice(4) + ' · 剩 ' + m + ':' + ss;
            genOut.className = 'device-code' + (left <= 30 ? ' warn' : '');
          };
          paint();
          genOut.onclick = function () {
            try {
              navigator.clipboard.writeText(r.code);
              say('已复制，去新电脑的插件登录框里粘贴即可（只能用一次）。');
            } catch (e) {
              say('没能复制到剪贴板，照着上面的码手输也一样。');
            }
          };
          say('把这串码输到新电脑的插件登录框里（只能用一次）。点码可复制。');
          genTimer = setInterval(function () {
            left--;
            if (left <= 0) {
              stopCodeCountdown();
              genOut.textContent = '已过期，请重新生成';
              genOut.className = 'device-code warn';
              genOut.onclick = null;
              return;
            }
            paint();
          }, 1000);
        } catch (e) {
          genOut.textContent = '';
          say(friendlyError(e.message), 'err');
        } finally {
          genBtn.disabled = false;
        }
      };
    }

    var out = document.getElementById('msLogout');
    if (out) {
      out.onclick = async function () {
        await logout();
        s = await state();
        render(false);
        if (msg) { msg.className = 'ms-gate-msg'; msg.textContent = ''; }
        if (opts && opts.onDisconnected) opts.onDisconnected();
      };
    }

    // 一键登录完成（官网中转页递票据回来）→ 立即刷新闸门为已登录
    window.addEventListener('ms-auth-changed', async function () {
      s = await state();
      render(isConnected(s));
      if (isConnected(s) && opts && opts.onConnected) opts.onConnected();
    });

    var on = isConnected(s);
    render(on);
    return on;
  }

  /*
   * 归属账号（2026-11-12 生产实证补的洞）：
   * 本地选品库存在 chrome.storage.local，是「按这台浏览器的扩展安装」存的，不分登录账号；
   * 退出登录只清凭据（STORE_KEYS），不清 products。于是换账号登录后，上一个账号采的商品
   * 还留在列表里，再点「同步到后台」就把 A 的供应商原链、采购价、SKU 成本写进了 B 的采集箱。
   * 生产里已经有痕迹：offer 1077415354664 同一条 02:11 进 test@shopsage.cc、02:59 进 815936687@qq.com。
   * 修法：采集时记下归属邮箱，同步/分析前双端校验；不匹配就拒绝并说清原因，绝不"顺手合并"或改归属。
   */
  function currentEmail() {
    return chrome.storage.local.get({ email: '' }).then(function (s) {
      return String((s && s.email) || '').trim().toLowerCase();
    });
  }

  /**
   * 纯函数：条目归属与当前账号是否一致。
   * 2026-11-13 改口径：老数据没有归属 ⇒ **不再放行**。以前是「允许同步 + 提示建议重采」,
   * 而换账号登录时当前账号就是那个"别人"，于是一条 0.9.12 之前采的旧数据照样能写进新账号的采集箱
   * ——闸门等于没关。现在一律拒绝，要同步就重新采集一次把归属补上（多点一次，不跨账号写数据）。
   */
  function ownerGuard(itemEmail, nowEmail) {
    var item = String(itemEmail || '').trim().toLowerCase();
    var now = String(nowEmail || '').trim().toLowerCase();
    if (!item) return { ok: false, known: false, reason: 'unowned' };
    if (!now) return { ok: false, reason: 'not_logged_in' };
    return item === now ? { ok: true, known: true } : { ok: false, reason: 'other_account', owner: item };
  }

  root.SSAuth = {
    DEFAULT_BASE: DEFAULT_BASE,
    state: state, isConnected: isConnected, login: login, logout: logout,
    renew: renew, validToken: validToken, backendFetch: backendFetch,
    handoff: handoff, mountGate: mountGate, baseOf: baseOf, friendlyError: friendlyError,
    ownerGuard: ownerGuard, currentEmail: currentEmail,
    requestLoginCode: requestLoginCode, loginWithCode: loginWithCode,
  };
})(typeof window !== 'undefined' ? window : this);
