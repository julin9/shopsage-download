/*
 * MSStore · 本地选品库按登录账号分区（2026-11-13，老板点名 #1「A 账号采的，B 登录还有 A 的数据」）
 *
 * 为什么必须动存储层：`chrome.storage.local` 是【按这台浏览器的扩展安装】存的，
 * 0.9.12 之前只有一个 `products` 数组、不分登录账号；退出登录只清凭据不清 products。
 * 于是同一台电脑换账号登录后，上一个账号采的商品还在列表里，一点「同步到后台」
 * 就把 A 的供应商原链、采购价、SKU 成本写进 B 的采集箱。
 * 生产里已经有痕迹：offer 1077415354664 同一条 02:11 进 test@shopsage.cc、02:59 进 815936687@qq.com。
 *
 * 三条规矩（都不靠口头约定）：
 *  1) 库按账号分键：products:v1:<邮箱>；未登录时读写都落在 products:v1:__unassigned__，
 *     绝不把别人的桶展示给当前账号；
 *  2) 旧的整包 `products` 只迁移一次，整批进「未归属」桶 —— 未归属的条目【永不参与同步】，
 *     要同步就重新采集一次把归属补上（宁可让用户多点一次，也不跨账号写数据）；
 *  3) 迁移与分键只在这一个文件里算，其他文件不许再直接读写 products。
 */
(function (root) {
  'use strict';

  const PREFIX = 'products:v1:';
  const UNASSIGNED = PREFIX + '__unassigned__';
  const LEGACY = 'products';
  const MIG_FLAG = 'productsPartitionedAt';
  const MAX_ITEMS = 500;

  const norm = (v) => String(v == null ? '' : v).trim().toLowerCase();

  /** 当前登录账号邮箱（小写去空格）。没登录返回空串——空串一律按「未归属」处理。 */
  async function currentEmail() {
    try {
      const s = await chrome.storage.local.get({ email: '' });
      return norm(s && s.email);
    } catch (e) { return ''; }
  }

  /** 账号 → 存储键。没登录就用未归属桶，绝不猜「应该是上一个账号」。 */
  function keyFor(email) {
    const e = norm(email);
    return e ? PREFIX + e : UNASSIGNED;
  }

  /**
   * 一次性迁移：把老的整包 products 挪进「未归属」桶并删掉旧键。
   * 挪过去的条目 ownerEmail 保持原样（多数是空），由 ownerGuard 一律拦在同步之外。
   */
  async function migrate() {
    let st;
    try { st = await chrome.storage.local.get({ [MIG_FLAG]: '', [LEGACY]: [] }); }
    catch (e) { return false; }
    if (st[MIG_FLAG]) return false;
    const legacy = Array.isArray(st[LEGACY]) ? st[LEGACY] : [];
    if (legacy.length) {
      let cur;
      try { cur = await chrome.storage.local.get({ [UNASSIGNED]: [] }); } catch (e) { cur = { [UNASSIGNED]: [] }; }
      const bucket = Array.isArray(cur[UNASSIGNED]) ? cur[UNASSIGNED] : [];
      const seen = new Set(bucket.map((x) => (x && x.url) || '').filter(Boolean));
      const moved = legacy.filter((x) => x && x.url && !seen.has(x.url))
        .map((x) => Object.assign({}, x, { ownerEmail: norm(x.ownerEmail), unassignedReason: 'legacy' }));
      await chrome.storage.local.set({
        [UNASSIGNED]: bucket.concat(moved).slice(0, MAX_ITEMS),
        [MIG_FLAG]: new Date().toISOString(),
      });
      await chrome.storage.local.remove(LEGACY);
      return moved.length > 0;
    }
    await chrome.storage.local.set({ [MIG_FLAG]: new Date().toISOString() });
    return false;
  }

  /**
   * 读当前账号的库。
   * 返回 { email, key, mine, unassigned, all }：
   *  · mine = 这个账号自己采的（可同步）；
   *  · unassigned = 旧版没归属的（只展示、不同步）；未登录时两者是同一个桶。
   */
  async function readAll() {
    await migrate();
    const email = await currentEmail();
    const key = keyFor(email);
    let st;
    try {
      st = await chrome.storage.local.get({ [key]: [], [UNASSIGNED]: [] });
    } catch (e) {
      return { email, key, mine: [], unassigned: [], all: [] };
    }
    const mine = Array.isArray(st[key]) ? st[key] : [];
    const unassigned = (email && key !== UNASSIGNED)
      ? (Array.isArray(st[UNASSIGNED]) ? st[UNASSIGNED] : [])
      : [];
    return { email, key, mine, unassigned, all: mine.concat(unassigned) };
  }

  /** 只写当前账号的桶（未归属桶单独走 writeUnassigned，不许被普通写入覆盖）。 */
  async function write(list) {
    const key = keyFor(await currentEmail());
    await chrome.storage.local.set({ [key]: (Array.isArray(list) ? list : []).slice(0, MAX_ITEMS) });
    return key;
  }

  async function writeBucket(key, list) {
    if (!key) return key;
    await chrome.storage.local.set({ [key]: (Array.isArray(list) ? list : []).slice(0, MAX_ITEMS) });
    return key;
  }

  /** 采集那一刻的归属：没登录就是空串，条目进未归属桶、后续一律不许同步。 */
  async function stampOwner(item) {
    const email = await currentEmail();
    return Object.assign({}, item, { ownerEmail: email, ownerStampedAt: new Date().toISOString() });
  }

  root.MSStore = {
    PREFIX, UNASSIGNED, LEGACY, MAX_ITEMS,
    currentEmail, keyFor, migrate, readAll, write, writeBucket, stampOwner,
  };
})(typeof window !== 'undefined' ? window : this);
