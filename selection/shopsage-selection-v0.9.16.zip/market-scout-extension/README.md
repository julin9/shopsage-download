# ShopSage 选品助手（Chrome 扩展）

Manifest V3 扩展，v0.6.2。从 1688 和拼多多采集商品 → 同步到 ShopSage 后台「采集箱」→ 看运费/扣点/利润与 AI 分析 → 进发布流程。

## v0.6.2 变更（2026-11-09）· 运费数据补齐 + 两个算法 bug

1. **海运表补到 25/25 市场全覆盖**，并修正三个明显偏离行情的旧值：
   印尼 950 → **1950**（原值约为行情一半，会把印尼利润算虚高）；
   巴西 4800 → **2352**（原值约为 DAP 上限两倍，疑为混进了巴西进口税）；
   沙特 3400 → **1600**；另新增 文莱 1200 / 阿根廷 1000 / 俄罗斯 1000（莫斯科线）。
   统一口径：**中国→目的国 双清到门，¥/CBM，不含平台扣点、不含进口关税**。
2. **铁路不再硬造数字**：纯铁路只收真实存在通道的市场——新增 泰国 1450（中老泰全铁）、越南 450（凭祥—同登—河内），
   原中欧班列 10 国 + 俄罗斯保留；另开一档 **联运（海运+目的国铁路）**：美国 1300（IPI 内陆铁路）、
   沙特 1600（吉达陆桥）、墨西哥 870（曼萨尼约+Ferromex）。
   7 个市场（台湾、日本、印尼、菲律宾、文莱、巴西、阿根廷）**物理上没有对华铁路通道**，
   界面直接写明原因，不塞假价；马来西亚 / 新加坡通道真实存在但公开渠道查不到成交单价，标「待询价」。
3. **每个单价都带来源**（站点 + 报价日期 + 置信度），收进 `FREIGHT_SRC`，在「口径与来源」折叠里可见，可回溯。
4. **修了两个会让比较失去意义的算法 bug**：
   - 重量档取上限时用了 `Number('5 kg（首重）')` → NaN → 兜回 1kg，导致 0–1 与 2–5 档算出同一个运费；现从 `key` 取上限。
   - 海运/铁路把拼箱「最低一票 ¥300/¥500」当成单件成本下限，结果所有国家都被压成 ¥300、比较完全失效；
     整票门槛按票收费、不属于单件成本，现只写进来源说明，不参与计算。

## v0.6.1 变更（2026-11-09）· 修「登录页根本打不开」

老板实测截图：选品库整页只剩顶栏一条，登录框和正文都不见。

根因是我在 v0.6.0 重写 `auth.js` 的 `mountGate()` 时把可见性判断写反了——
`gate` 和 `main` 两块都用了 `toggle('hidden', !on)`，于是「没登录」时两块同时被隐藏，
页面就只剩顶栏。登录请求根本没机会发出，跟后台、跟官网都没关系。

同时更正我自己上一轮的验证口径：那三张「真截图」是用预览脚本**手工把登录框改成可见**再截的，
只证明了 CSS 排版，没有证明 JS 那条切换路径——所以它没抓到这个 bug。
这一版改成跑真实脚本的诊断页（注入 chrome API 桩 + 错误陷阱），未登录 / 已登录两态各截一张，
并补了 18 条闸门可见性回归（`test-gate`），两态的 class、高度、chip、退出按钮都逐条断言。

## v0.6.0 变更（2026-11-09）

老板这一轮提了三件事：登录页太小、字体大小粗细要按官方标准化、登录不进去要跟官方数据库同步（同一个账号闭合）。

1. **登录真的走官网账号了**（原来是「登录不进去」的根因，两条都中）：
   - 插件原先没有 `www.shopsage.cc` 的主机权限，跨域请求被浏览器直接拦掉，登录请求根本发不出去；
     现在 `host_permissions` 加了 `https://*.shopsage.cc/*`，并加 `cookies` 权限。
   - 插件原先登录完还要调一次 `/api/v1/extension/session/device` 换「180 天设备令牌」，
     那个接口只存在于没发版的分支里，线上返回 404 → 永远登不进去。**这套自造的第二套凭据已经整体删掉**
     （表 `extension_devices`、`extension-device.guard.ts`、CORS 放行都撤了）。
   - 现在就是官网那一个账号：`POST /api/auth/login` → 官网签发的 access token（15 分钟）→
     临期用官网的刷新令牌 `POST /api/auth/refresh` 静默续期（刷新令牌只从浏览器 Cookie 现读，不进本地存储）→
     退出时调 `POST /api/auth/logout` 让服务端作废会话。租户、权限、积分、店铺全部与官网后台一致，
     后台接口统一走全站 `JwtAuthGuard`，不存在绕过租户守卫的第二条路。
   - 官网后台有全局 `{success,data}` 信封，插件端统一拆包（漏拆的表现就是「一直加载中、一条报错都没有」）。
   - 浏览器若拦住了续期 Cookie，登录框会明说「约 15 分钟后需重新登录一次」，不假装续上了。
2. **登录页按官方 login 页重做并放大**：48px 品牌标 + 24px 页标题（官网 `.t-page-title` 同档）+ 14px 标签与输入 +
   全宽登录按钮 + 密码显隐眼睛（矢量 SVG）+ 注册/忘记密码；卡片弹窗 560px、整页 620px，内边距 36px，不再是原来那个 400px 小卡。
3. **全站字号字重按官网《排版标准 v2》标准化**：`ui.css` 直接抄官网 token（12/13/14/15/16/18/20/24px 与对应行高），
   字重只留 400/500/600，控件尺寸 input/button 40px、compact 32px、卡片内边距 24px 全部与官网同名同值；
   9/10/11px 小字清零，版式层不再用 `!important` 互抢（只有注入别人页面的 `content.css` 保留）。
   配套补上 MiSans **Medium(500)** 与缺失的 baht(฿) 子集（源文件与官网 `misans-v3` 同一批内容指纹，仍全自托管），
   并加 `font-synthesis:none` —— 之前只挂 400/600，500 会掉回 400，标签和正文一样粗、层级看不见。
4. **成本细则栅格修好**：`#msCostFields` 原本是外层两列栅格里的一个子格，被压成半宽再二等分，
   下拉只剩一格宽、标签折两行；现在整块横跨两列，与上方字段对齐。
5. **点数不再写死假数字**：删掉「约 10 点」这种界面里写死的报价，改明标「点数结算未接入插件 · 以后台账单为准」。

后端配套（分支 `feat/extension-inbox`，worktree `E:\shopsage-extension-inbox`，**未提交、未发版**）：
只加一张表 `extension_collected_products`（`extension_devices` 已随第二套凭据一起撤掉）、
`services/api/src/extension/*` 三个文件（控制器全部 `JwtAuthGuard`）、
`POST /api/v1/extension/products|analyze` + `GET/PATCH/DELETE /api/v1/extension/inbox`、
前端页 `apps/web/app/selection/inbox/page.tsx` + 导航项「采集箱」。`main.ts` 的 CORS 改动已回滚，与线上版本零 diff。
**线上实测（2026-11-09）**：`/api/auth/login`、`/api/auth/refresh`、`/api/auth/logout` 都已存在（401/200 正常应答）；
`/api/extension/products|inbox|analyze` 现在仍是 404 —— 要发版才通，插件端已就绪。

## v0.5.0 变更（2026-11-09）
1. **页面自适应宽度**：选品库容器放宽到 1860px，宽屏多铺卡片；右侧「市场与成本」栏加宽到 400px。
2. **右栏瘦身**：正常口径说明默认折成一行「口径与来源：扣点 x% · 运费 ¥y · 快照 日期」，点开才看全量；有问题的事（平台未收录、费率缺失）仍摆在明面。
3. **目标国家改为按平台开通市场可选**：选 TikTok Shop 就列出它开的 21 个市场，选 Shopee 列 11 个，选 Lazada 列 6 个、Ozon 1 个；另留「其他 / 自行输入国家…」给规则库没覆盖的市场。币种/扣点/运费跟着变。
4. **登录做到最前端**：没登录先只见登录框，登录成功才出正文（v0.6.0 把这条做真了，见上）。
5. **后台新增「采集箱」**（`AI商品选品 → 采集箱`）：插件同步的商品落在这里，可跑服务端 AI 分析、入围/移除，报告留档。

## 安装
1. 直接用本机的 `market-scout-extension` 文件夹（已解压，里面有 `manifest.json`）。
2. Chrome 打开 `chrome://extensions`，开启「开发者模式」。
3. 点「加载已解压的扩展程序」，选中 `market-scout-extension` **文件夹**（不要选 ZIP，也不要只选 `manifest.json`）。
4. 安装或每次更新后，**必须刷新已经打开的 1688 / 拼多多标签页**（`Ctrl+Shift+R`），否则旧标签页跑的还是旧脚本。

刷新后：拼多多/1688 列表页每张商品卡右上角出现「采集商品」，页面左下角出现「本页识别 N 件 / 采集选中 / 采集本页 / 打开选品库」；商品详情页出现「采集到选品库」。同步按钮快速提交基础商品，不再后台等待打开隐藏详情页；要补齐规格与描述时，在来源详情页点击「采集到选品库」后再同步，已采商品会以更完整详情更新。

## 代码结构（0.4.0 重构后）

| 文件 | 世界 | 职责 |
|---|---|---|
| `goods-shape.js` | MAIN + ISOLATED | 商品对象识别的唯一口径。键名归一化后再比对，`goods_id` / `goodsId` / `goodsID` 全认 |
| `page-hook.js` | MAIN | 读页面 `window.rawData` / `__INITIAL_PROPS__` 等注水数据；包 `fetch`/`XHR` 抓翻页与下滑加载；整份 postMessage 递回隔离世界 |
| `capture.js` | ISOLATED | 取数入口 `MS_CAPTURE()`：解析内联脚本数据块 → 桥回 DOM 卡片 → 定价格口径；1688 走原选择器 |
| `content.js` | ISOLATED | 只负责把商品变成页面上的按钮和工具栏 |
| `rules.js` | 弹窗/选品库 | ShopSage 底层规则库的只读快照（平台→市场、综合扣点、跨境首重运费、参考汇率、利润与判定阈值） |
| `market-ui.js` | 弹窗/选品库 | 平台↔国家↔币种联动、自动派生运费扣点、来源标注、实时利润表 |

## 采集口径（拼多多，实测钉死）
`mobile.yangkeduo.com/search_result.html` 整页 DOM 里 **没有任何带 `goods_id` 的 `<a>`**，商品卡是 `div` + JS 跳转；`goods_id` 只出现在内联脚本 `window.rawData = {...}` 的数据块里。真实结构是：

```
window.rawData.stores.store.data.ssrListData.list[]     // 一屏 20 条
  ├─ goodsID        商品 ID（注意是大写 ID，不是 goods_id 也不是 goodsId）
  ├─ goodsName      标题
  ├─ price          价格，单位「分」（43790 = ¥437.90）
  ├─ imageUrl       主图（每件唯一 hash 文件名）
  └─ salesTip       销量话术
```

所以取数走数据块，不猜 DOM 文本；卡片按钮靠**主图 hash** 反查卡片元素（标题在 DOM 里被拆成多个文本节点，靠文本匹配不可靠）。

## 价格口径
拼多多列表页显示的多是**券后/活动价**，数据块 `price` 是原价。插件两个都留：`price` = 平台数据价（主价），`visiblePrice` = 页面可见价，两者不一致时标「请核对用哪个」，**不替商家拍板取哪一个**。

## 运费 / 扣点 / 利润（rules.js）
口径全部来自 ShopSage 后端，`rules.js` 是这些文件的导出快照（**改后端必须同步这里**，快照日期 2026-11-08）：

- `services/api/src/cost/platform-markets.ts` → 平台已开通市场、币种、跨境/本土/邀请制
- `services/api/src/business-context/marketplace-country-fees.registry.ts` → 综合扣点 `typicalTotalPct`
- `services/api/src/cost/shipping-rules.ts` → 跨境首重参考运费 `CB_FIRST_WEIGHT`
- `services/api/src/market-research/currency-reference.ts` → 参考汇率（带日期，非实时）
- `services/api/src/products/market-first-selection.service.ts` → 利润公式与 ≥30% / ≥15% 判定阈值

三条硬规则（照抄后端红线）：

1. **能自己填就自己填。** 运费、扣点只要商家动过手，插件永不覆盖，并在来源行标「已改用您填写的值」。
2. **没填的才按规则库算。** 店型未知时，本土行与跨境行**取更高**的那条（宁可压低利润，绝不虚高）。
3. **缺就说缺，绝不冒充。** 规则库没收录的平台×国家（如 Shopee 墨西哥、Amazon、Temu）返回 null + 原因，利润结论自动降级为「信息不足」，不回落成 0 或默认值。

## 配置
- **登录**：打开插件（或选品库）先看到登录框，用 ShopSage 官网的同一个邮箱密码登录即可——没有单独的「连接设置」这一步。
  密码只在点击瞬间使用，不落盘；落盘的只有官网签发的 15 分钟 access token，临期由插件拿官网刷新令牌静默续期。
  退出登录会调官网 `/api/auth/logout` 让服务端会话即时作废，插件与官网后台同步掉线。
- **AI 分析**：由 ShopSage 服务端代跑（`QWEN_API_KEY`/`DASHSCOPE_API_KEY`，配在服务端），浏览器不接触任何模型 key。
- 没登录时插件正文不放开（登录做到最前端）；「同步到后台」和「AI 分析」要登录后才可用，失败会给可操作的中文原因，不会假装成功。

## 后台 API 契约（0.6.0 起用官网账号）
同步 `POST /extension/products`，`Authorization: Bearer <官网登录签发的 access token>`：

```json
{"product":{"title":"…","price":124.9,"visiblePrice":116,"currency":"CNY","url":"…","platform":"拼多多","image":"…","salesTip":"…","capturePath":"数据块 + DOM 卡片桥接","priceNeedsReview":true},
 "source":"拼多多",
 "market":{"country":"泰国","countryCode":"TH","marketplace":"SHOPEE","currency":"THB","targetPrice":199,"sellerType":null,"weightBand":"0-1"},
 "costs":{"purchasePrice":124.9,"shipping":8,"platformFeeRate":22.5,"otherCostRate":10,
          "shippingSource":"RULE_OR_MISSING","feeRateSource":"RULE_OR_MISSING"}}
```

分析 `POST /extension/analyze` 请求体同上（去掉外层 `source`）。建议返回 `{"result":"分析报告…","creditsCharged":10,"balance":120,"sources":[{"title":"…","url":"https://…"}]}`。

`costs.*Source` 告诉后台这个数是商家填的还是我们算的，便于按可信度分档。

## 已知边界（截至 0.4.0）
- **`POST /extension/products` 和 `/extension/analyze` 在 ShopSage 后端还不存在**（全仓检索零命中）。现有的 `plugin-relay` 只白名单转发 Supabase，不是这两个口。所以「同步到后台」和「点数扣除」目前是空跑，必须先把后端补上。
- 拼多多详情页、1688 详情页只取首条商品，多规格/变体价没展开。
- 下滑加载靠 `page-hook.js` 的接口钩子累积；页面结构或接口字段改名会退化（归一化键名已能扛驼峰/下划线互换，扛不住整体换字段）。
- 运费是 0–1 / 1–2 / 2–5 kg 三档粗估（`MARKET_REFERENCE`，低置信），精确值要商家上传真实运价单覆盖。
- 汇率是带日期的参考快照，不是实时价。
- 市场销量、热搜词、竞品价依赖联网搜索或后台数据源；正式版应接可靠供应商并记录来源、地区、日期、统计口径。

## 本次实测记录（2026-11-08，Chrome/156 内核）
- 拼多多搜索页 `search_key=玩具狗`：点「采集本页」→ toast「已采集 20 个商品，选品库共 21 个」；19/20 张卡片挂上独立「采集商品」按钮。
- 逐条价格核对与页面一致：¥437.90 / ¥124.90 / ¥78.98（数据价），页面可见 ¥421.9 / ¥116.9 / ¥70.98（券后价），两个都留存。
- 选品库面板：平台 Shopee + 泰国 → 自动填 综合扣点 22.5%、运费 ¥8、币种 THB；填预期售价 199 THB → 收入 ¥39.78、扣点 ¥8.95、其他 ¥3.98、净利 ¥14.25、毛利率 35.8%、ROI 113.1%、保本 93.59 THB、30% 建议价 168.1 THB，判定「值得测试」。算术已逐项复核自洽。
- 未填售价时结论为「信息不足」，不硬出利润数。
