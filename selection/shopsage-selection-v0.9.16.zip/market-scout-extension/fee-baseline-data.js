/* 自动生成，别手改：node scripts/gen-plugin-fee-baseline.cjs
 * 来源：services/api/src/cost/fee-baseline.ts + fee-calculator.ts（版本 2026-11-13.v1）
 * 共 34 行（平台×国家×店型），其中未知 1 行、含待后台核实项(LOW) 9 行。
 * 插件只读这里的 compositePct，不再自己算基数 —— 数字由服务端同一段代码产出，这才叫闭环。
 */
(function (root) {
  'use strict';
  root.MS_FEE_BASELINE = {
  "version": "2026-11-13.v1",
  "generatedAt": "2026-11-14T00:37:52.778Z",
  "rows": [
    {
      "platform": "TIKTOK_SHOP",
      "market": "US",
      "shopType": "cb_pop",
      "currency": "USD",
      "available": true,
      "compositePct": 6,
      "totalPer100": 6,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.06,
          "status": "C"
        }
      ],
      "freight": {
        "overseasWarehouseLastMile": {
          "perTicket": 3.5,
          "currency": "USD",
          "status": "E",
          "source": "tiktok费用表（2026-11）",
          "note": "海外仓一件代发尾程 $3–4/包裹"
        },
        "seaLcl": {
          "pricePerCbm": 3000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（行情中值，待真实运价覆盖）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "UK",
      "shopType": "cb_pop",
      "currency": "GBP",
      "available": true,
      "compositePct": 11.3,
      "totalPer100": 11.3,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.99,
          "currency": "GBP",
          "status": "P",
          "source": "tiktok费用表（2026-11）",
          "note": "买家端标准配送 £3.99（含 VAT，原 £2）；卖家端成本以后台价卡为准"
        },
        "seaLcl": {
          "pricePerCbm": 3000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "DE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.71,
      "totalPer100": 10.71,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "FR",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.8,
      "totalPer100": 10.8,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "IT",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.98,
      "totalPer100": 10.98,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ES",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "totalPer100": 10.89,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "IE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 11.07,
      "totalPer100": 11.07,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "AT",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.8,
      "totalPer100": 10.8,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "BE",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "totalPer100": 10.89,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "NL",
      "shopType": "cb_pop",
      "currency": "EUR",
      "available": true,
      "compositePct": 10.89,
      "totalPer100": 10.89,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "PL",
      "shopType": "cb_pop",
      "currency": "PLN",
      "available": true,
      "compositePct": 11.07,
      "totalPer100": 11.07,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "order_total_incl_ship_tax",
          "rate": 0.09,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 3.15,
          "stepG": 1000,
          "additionalPrice": 7.6,
          "currency": "EUR",
          "firstWeightG": 50,
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "法国示例 €3.15/包裹 + €7.60/kg；50g 首重不足按 50g；单包 ≤30kg、≤60×40×40cm。其余欧盟国按同价卡，需后台核实"
        },
        "seaLcl": {
          "pricePerCbm": 3100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "JP",
      "shopType": "cb_pop",
      "currency": "JPY",
      "available": true,
      "compositePct": 8.7,
      "totalPer100": 8.7,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.077,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "官方面单轻小件 0–5kg 普货 98/kg、含电 102/kg、处理费 10/票；无统一公开分重价卡，须对接雅玛多末端"
        },
        "seaLcl": {
          "pricePerCbm": 1100,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（到门口径）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "MX",
      "shopType": "cb_pop",
      "currency": "MXN",
      "available": true,
      "compositePct": 28,
      "totalPer100": 28,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstPrice": 2.3,
          "currency": "USD",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "跨境 POP 需备货墨西哥仓，本地仓头程首重约 $2.3 起；不是中国直邮"
        },
        "seaLcl": {
          "pricePerCbm": 4800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "BR",
      "shopType": "cb_pop",
      "currency": "BRL",
      "available": true,
      "compositePct": 16,
      "totalPer100": 16,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 102,
          "currency": "CNY",
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "以官方价卡为准"
        },
        "seaLcl": {
          "pricePerCbm": 2300,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（原值 4800 约为行情两倍，已修正）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "MY",
      "shopType": "cb_pop",
      "currency": "MYR",
      "available": true,
      "compositePct": 21.06,
      "totalPer100": 21.06,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1674,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0432,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "官方面单轻小件参考价；2026-09 直邮价卡下调，马来 86.7% 降幅，200g 以下最大"
        },
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "TH",
      "shopType": "cb_pop",
      "currency": "THB",
      "available": true,
      "compositePct": 11.99,
      "totalPer100": 11.99,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.0856,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.0321,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "2026-09 泰国各重量段约降 60%"
        },
        "seaLcl": {
          "pricePerCbm": 800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "VN",
      "shopType": "cb_pop",
      "currency": "VND",
      "available": true,
      "compositePct": 23,
      "totalPer100": 23,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "2026-09 越南降幅最高 88.2%"
        },
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "PH",
      "shopType": "cb_pop",
      "currency": "PHP",
      "available": true,
      "compositePct": 16.34,
      "totalPer100": 16.34,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.091,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0224,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）"
        },
        "seaLcl": {
          "pricePerCbm": 950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "SG",
      "shopType": "cb_pop",
      "currency": "SGD",
      "available": true,
      "compositePct": 11.45,
      "totalPer100": 11.45,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.08175,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0327,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "perTicket": 10,
          "currency": "CNY",
          "status": "E",
          "source": "老板数据包 v1.0（2026-11）"
        },
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ID",
      "shopType": "cb_pop",
      "currency": "IDR",
      "available": false,
      "compositePct": null,
      "totalPer100": 0,
      "confidence": "LOW",
      "unknown": true,
      "reason": "该平台在此国家没有这个店型通道（例：TikTok 印尼无跨境 POP），必须换店型或按本土店重算",
      "lines": [],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM（原值 950 约为行情一半，已修正）"
        }
      }
    },
    {
      "platform": "TIKTOK_SHOP",
      "market": "ID",
      "shopType": "local",
      "currency": "IDR",
      "available": true,
      "compositePct": 1276.71,
      "totalPer100": 1276.71,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.145,
          "status": "P"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "order_total_incl_ship_tax",
          "rate": 0.11,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "SG",
      "shopType": "cb_sls",
      "currency": "SGD",
      "available": true,
      "compositePct": 24.45,
      "totalPer100": 24.45,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.03,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 15,
          "stepG": 10,
          "additionalPrice": 1.5,
          "currency": "SGD",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "虾皮费用表（2026-11）",
          "note": "2026-06 藏价上调；以前我们硬编码 SGD 4，低估 73%"
        },
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "SG",
      "shopType": "cb_overseas_warehouse",
      "currency": "SGD",
      "available": true,
      "compositePct": 19.45,
      "totalPer100": 19.45,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.11,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.03,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 600,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "cb_sls",
      "currency": "MYR",
      "available": true,
      "compositePct": 15.28,
      "totalPer100": 15.28,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.06,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0378,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 20,
          "firstPrice": 8.5,
          "stepG": 10,
          "additionalPrice": 0.7,
          "currency": "MYR",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "虾皮费用表（2026-11）",
          "note": "首重前 20g RM8.5；轻小件有阶段性优惠费率"
        },
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "cb_overseas_warehouse",
      "currency": "MYR",
      "available": true,
      "compositePct": 24.4,
      "totalPer100": 24.4,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1512,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0378,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.05,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MY",
      "shopType": "local",
      "currency": "MYR",
      "available": true,
      "compositePct": 3.54,
      "totalPer100": 3.54,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.03,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 710,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "TH",
      "shopType": "cb_sls",
      "currency": "THB",
      "available": true,
      "compositePct": 34.54,
      "totalPer100": 34.54,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.2461,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0321,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.0535,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 65,
          "stepG": 10,
          "additionalPrice": 5,
          "currency": "THB",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "虾皮费用表（2026-11）",
          "note": "以前我们硬编码 THB 40，低估 38%"
        },
        "seaLcl": {
          "pricePerCbm": 800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "VN",
      "shopType": "cb_sls",
      "currency": "VND",
      "available": true,
      "compositePct": 25.46,
      "totalPer100": 25.46,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1533,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.033,
          "status": "C"
        },
        {
          "key": "techSupport",
          "label": "技术支持费",
          "base": "order_total_incl_ship_tax",
          "rate": 0.054,
          "status": "P"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.01,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 55000,
          "stepG": 10,
          "additionalPrice": 4000,
          "currency": "VND",
          "volumetricDivisor": 5000,
          "status": "C",
          "source": "虾皮费用表（2026-11）"
        },
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "VN",
      "shopType": "local",
      "currency": "VND",
      "available": true,
      "compositePct": 6,
      "totalPer100": 6,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.06,
          "status": "C"
        }
      ],
      "freight": {
        "seaLcl": {
          "pricePerCbm": 550,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "PH",
      "shopType": "cb_sls",
      "currency": "PHP",
      "available": true,
      "compositePct": 14.15,
      "totalPer100": 14.15,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.12,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.0215,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 90,
          "stepG": 10,
          "additionalPrice": 7,
          "currency": "PHP",
          "volumetricDivisor": 5000,
          "status": "C",
          "source": "虾皮费用表（2026-11）",
          "note": "以前我们硬编码 PHP 150，高估 67%"
        },
        "seaLcl": {
          "pricePerCbm": 950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "ID",
      "shopType": "cb_sls",
      "currency": "IDR",
      "available": true,
      "compositePct": 1260.5,
      "totalPer100": 1260.5,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1,
          "status": "C"
        },
        {
          "key": "fixedPerOrder",
          "label": "按单固定费",
          "base": "per_order",
          "rate": 0,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.005,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "perKg": 98,
          "currency": "CNY",
          "status": "P",
          "source": "老板数据包 v1.0（2026-11）",
          "note": "印尼 SLS 首重/续重未在那两份表里单列，待后台价卡"
        },
        "seaLcl": {
          "pricePerCbm": 1950,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "TW",
      "shopType": "cb_sls",
      "currency": "TWD",
      "available": true,
      "compositePct": 16.5,
      "totalPer100": 16.5,
      "confidence": "HIGH",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.14,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.025,
          "status": "C"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 140,
          "stepG": 10,
          "additionalPrice": 8,
          "currency": "TWD",
          "volumetricDivisor": 5000,
          "status": "P",
          "source": "虾皮费用表（2026-11）",
          "note": "TODO-10：另有「首重 0.5kg」口径（插件按 45 TWD 算），两套差约 3 倍，待后台价卡定一"
        },
        "seaLcl": {
          "pricePerCbm": 1000,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "BR",
      "shopType": "cb_sls",
      "currency": "BRL",
      "available": true,
      "compositePct": 14,
      "totalPer100": 14,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.1,
          "status": "C"
        },
        {
          "key": "fixedPerItem",
          "label": "按件固定费",
          "base": "per_unit",
          "rate": 0,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 45,
          "stepG": 10,
          "additionalPrice": 5,
          "currency": "BRL",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "虾皮费用表（2026-11）"
        },
        "seaLcl": {
          "pricePerCbm": 2300,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    },
    {
      "platform": "SHOPEE",
      "market": "MX",
      "shopType": "cb_sls",
      "currency": "MXN",
      "available": true,
      "compositePct": 51.5,
      "totalPer100": 51.5,
      "confidence": "LOW",
      "unknown": false,
      "reason": null,
      "lines": [
        {
          "key": "commission",
          "label": "平台佣金",
          "base": "product_price_excl_ship_tax",
          "rate": 0.16,
          "status": "C"
        },
        {
          "key": "transaction",
          "label": "交易手续费",
          "base": "order_total_incl_ship",
          "rate": 0.02,
          "status": "C"
        },
        {
          "key": "taxWithholding",
          "label": "税费代扣",
          "base": "product_price_excl_ship_tax",
          "rate": 0.335,
          "status": "P"
        }
      ],
      "freight": {
        "crossBorderDirect": {
          "firstWeightG": 10,
          "firstPrice": 120,
          "stepG": 10,
          "additionalPrice": 8,
          "currency": "MXN",
          "volumetricDivisor": 6000,
          "status": "C",
          "source": "虾皮费用表（2026-11）"
        },
        "seaLcl": {
          "pricePerCbm": 4800,
          "currency": "CNY",
          "status": "E",
          "source": "插件 rules.js SEA_PER_CBM"
        }
      }
    }
  ]
};
})(typeof window !== 'undefined' ? window : this);
