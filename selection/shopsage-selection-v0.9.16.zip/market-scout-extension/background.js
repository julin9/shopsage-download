/* ShopSage MV3 service worker：仅提供打开选品库的轻量入口。 */
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'OPEN_LIBRARY') {
    chrome.tabs.create({ url: chrome.runtime.getURL('library.html') });
  }
});
