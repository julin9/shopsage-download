/* ShopSage 选品助手 · 账号页（Chrome 扩展详情页进得来）
 *
 * 2026-11-09：这里不再自己实现登录，所有动作都转给 auth.js 的 SSAuth——
 * 和 popup / 选品库共用同一份官方账号逻辑，避免出现第二套登录代码。
 * 密码只在点击瞬间使用，绝不落盘；大模型 key 全在服务端。
 */

const $ = (id) => document.getElementById(id);
const DEFAULT_BASE = "https://www.shopsage.cc";

function say(msg, ok = false) {
  const e = $("saved");
  e.textContent = msg;
  e.className = "saved" + (ok ? " ok" : " err");
  if (msg) setTimeout(() => { if (e.textContent === msg) e.textContent = ""; }, 6000);
}

async function renderState() {
  const s = await window.SSAuth.state();
  const box = $("acctState");
  if (s.accessToken) {
    box.textContent = `已登录：${s.userName || s.email || "（未记录邮箱）"} · ${s.backendUrl || DEFAULT_BASE}`;
    box.className = "conn-state ok";
  } else {
    box.textContent = "未登录";
    box.className = "conn-state";
  }
  $("email").value = s.email || "";
  $("backendUrl").value = s.backendUrl || DEFAULT_BASE;
  $("password").value = "";
}

async function login() {
  const base = String($("backendUrl").value || "").trim().replace(/\/+$/, "") || DEFAULT_BASE;
  await chrome.storage.local.set({ backendUrl: base });
  const btn = $("login");
  btn.disabled = true;
  say("正在登录…");
  try {
    const r = await window.SSAuth.login($("email").value, $("password").value);
    say(`已用官网账号登录：${r.email}`, true);
    if (!r.autoRenew) {
      say("已登录，但浏览器拦住了官网的续期 Cookie，约 15 分钟后需重新登录一次", false);
    }
  } catch (e) {
    say(window.SSAuth.friendlyError(e.message), false);
  } finally {
    btn.disabled = false;
    await renderState();
  }
}

async function logout() {
  await window.SSAuth.logout();
  say("已退出登录", true);
  await renderState();
}

document.addEventListener("DOMContentLoaded", async () => {
  const s = await window.SSAuth.state();
  $("backendUrl").value = s.backendUrl || DEFAULT_BASE;
  await renderState();
  $("login").onclick = login;
  $("logout").onclick = logout;
  $("password").addEventListener("keydown", (e) => { if (e.key === "Enter") void login(); });
});
