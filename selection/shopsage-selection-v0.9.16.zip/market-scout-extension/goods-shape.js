/**
 * ShopSage 选品助手 · 商品对象识别（MAIN world 与 ISOLATED world 共用同一份）
 *
 * 为什么要单独一个文件：两个世界必须用同一套判定口径，否则页面里看到的和插件算出来的会不一样。
 *
 * 2026-11-08 实测拼多多 mobile.yangkeduo.com 搜索页的真实结构：
 *   window.rawData.stores.store.data.ssrListData.list[] 共 20 条，
 *   字段是 goodsID / goodsName / price / priceAreaInfo / tagList / itemType ...
 *   —— 键名是 goodsID（大写 ID），不是接口常见的 goods_id，也不是 goodsId。
 *   第一版只认 goods_id / goodsId，所以整页 0 命中。
 *
 * 因此这里不认具体拼法：把键名统一小写并去掉下划线再比对，
 * goods_id / goodsId / goodsID / GoodsID 全部命中同一个归一化键 goodsid。
 * 平台再改驼峰还是下划线，都不用改代码。
 */
(function (root) {
  'use strict';

  var norm = function (k) { return String(k).toLowerCase().replace(/[_\s-]+/g, ''); };

  /** 把对象的键归一化后建一张 归一化名 -> 原始键名 的表（同名冲突时保留第一个有值的）。 */
  function keyMap(o) {
    var m = Object.create(null);
    for (var k in o) {
      if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
      var n = norm(k);
      if (!(n in m)) m[n] = k;
    }
    return m;
  }

  function readStr(o, km, names) {
    for (var i = 0; i < names.length; i++) {
      var raw = km[names[i]];
      if (raw == null) continue;
      var v = o[raw];
      if (typeof v === 'string' && v.trim()) return v.trim();
      if (typeof v === 'number' && Number.isFinite(v)) return String(v);
    }
    return '';
  }

  function readNum(o, km, names) {
    for (var i = 0; i < names.length; i++) {
      var raw = km[names[i]];
      if (raw == null) continue;
      var v = o[raw];
      var n = typeof v === 'number' ? v : Number(typeof v === 'string' ? v.replace(/[^\d.]/g, '') : NaN);
      if (Number.isFinite(n) && n > 0) return n;
    }
    return null;
  }

  var ID_KEYS = ['goodsid', 'goodssn', 'goodssnid', 'productid', 'itemid'];
  var TITLE_KEYS = ['goodsname', 'goodspost', 'productname', 'title', 'name'];
  var PRICE_KEYS = ['price', 'onsaleprice', 'groupprice', 'saleprice', 'normalprice', 'marketprice'];
  var IMAGE_KEYS = ['imageurl', 'imgurl', 'thumburl', 'picurl', 'pictureurl', 'hdurl'];
  var LINK_KEYS = ['linkurl', 'goodsurl', 'detailurl', 'url'];
  var SALES_KEYS = ['salestip', 'soldtext', 'soldquantity', 'sales', 'soldcount'];

  /** 从 goods_id=xxx 这种链接里兜底抠 ID（PDD 列表项里 link_url 带 40 次 goods_id=）。 */
  function idFromUrl(s) {
    var m = String(s || '').match(/[?&]goods_?id=(\d{5,})/i);
    return m ? m[1] : '';
  }

  function looksLikeImage(s) {
    return /^https?:\/\//.test(s) || s.indexOf('//') === 0;
  }

  /** 单个对象 -> 商品条目；不像商品就返回 null。 */
  function itemFrom(o) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
    var km = keyMap(o);
    var id = readStr(o, km, ID_KEYS);
    var title = readStr(o, km, TITLE_KEYS);
    var link = readStr(o, km, LINK_KEYS);
    if (!id) id = idFromUrl(link) || idFromUrl(o.href) || idFromUrl(o.jumpUrl);
    if (!id || !title || title.length < 4) return null;

    var image = readStr(o, km, IMAGE_KEYS);
    if (!image || !looksLikeImage(image)) {
      var lists = o.urlList || o.url_list || o.images || o.pics;
      image = Array.isArray(lists) && typeof lists[0] === 'string' ? lists[0] : '';
    }
    if (image.indexOf('//') === 0) image = 'https:' + image;

    var rawPrice = readNum(o, km, PRICE_KEYS);
    if (rawPrice == null) {
      var pi = o.priceInfo || o.price_info || o.priceAreaInfo || o.priceArea;
      if (pi && typeof pi === 'object') rawPrice = readNum(pi, keyMap(pi), PRICE_KEYS);
    }

    return {
      goodsId: String(id),
      title: title.replace(/\s+/g, ' ').trim().slice(0, 240),
      image: image.slice(0, 500),
      rawPrice: rawPrice,
      linkUrl: link.slice(0, 400),
      salesTip: readStr(o, km, SALES_KEYS).slice(0, 60),
      marketPrice: readNum(o, km, ['marketprice', 'normalprice'])
    };
  }

  /**
   * 在任意数据结构里找出所有商品条目。
   * maxItems 封顶，深度封顶，重复对象跳过 —— 拼多多 rawData 很大，不设限会把页面拖慢。
   */
  function findItems(node, maxItems) {
    var cap = maxItems || 120;
    var sink = [], seen = [], guard = 0;
    (function walk(n, depth) {
      if (!n || depth > 10 || sink.length >= cap || guard > 20000) return;
      guard++;
      if (Array.isArray(n)) {
        for (var i = 0; i < n.length; i++) walk(n[i], depth + 1);
        return;
      }
      if (typeof n !== 'object') return;
      if (seen.indexOf(n) >= 0) return;
      seen.push(n);
      var it = itemFrom(n);
      if (it) {
        var dup = false;
        for (var j = 0; j < sink.length; j++) if (sink[j].goodsId === it.goodsId) { dup = true; break; }
        if (!dup) sink.push(it);
      }
      for (var k in n) {
        if (!Object.prototype.hasOwnProperty.call(n, k)) continue;
        try { walk(n[k], depth + 1); } catch (e) { /* 某些 getter 会抛，跳过这个键 */ }
      }
    })(node, 0);
    return sink;
  }

  /** 拼多多价格字段是「分」；这里只做单位判断，不猜值。 */
  function toYuan(rawPrice, visibleYuan) {
    if (rawPrice == null) return null;
    if (visibleYuan != null && visibleYuan > 0) {
      if (Math.abs(rawPrice / 100 - visibleYuan) < 0.02) return visibleYuan;   // 分，已和页面可见价互证
      if (Math.abs(rawPrice - visibleYuan) < 0.02) return visibleYuan;          // 本来就是元
    }
    if (Number.isInteger(rawPrice) && rawPrice >= 100) return Math.round(rawPrice) / 100;
    return rawPrice;
  }

  root.MS_SHAPE = { findItems: findItems, itemFrom: itemFrom, toYuan: toYuan, norm: norm, idFromUrl: idFromUrl };
})(typeof window !== 'undefined' ? window : this);
